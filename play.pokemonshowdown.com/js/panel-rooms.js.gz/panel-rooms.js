"use strict";function _inheritsLoose(t,o){t.prototype=Object.create(o.prototype),t.prototype.constructor=t,_setPrototypeOf(t,o);}function _setPrototypeOf(t,e){return _setPrototypeOf=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(t,e){return t.__proto__=e,t;},_setPrototypeOf(t,e);}/**
 * Room-list panel (default right-panel)
 *
 * @author Guangcong Luo <guangcongluo@gmail.com>
 * @license AGPLv3
 */






var ROOM_ALIASES={
tmg:'toursminigames',
tours:'tournaments'
};

var LANGUAGE_ROOM_IDS={
it:['italiano'],
es:['espanol','espaol'],
'zh-cn':['chinese'],
'zh-tw':['chinese'],
hi:['hindi'],
fr:['franais','francais'],
pt:['portugus','portugues'],
ja:['japanese'],
nl:['nederlands'],
de:['deutsche'],
ko:['korean']
};var

RoomsRoom=function(_PSRoom){

function RoomsRoom(options){var _this;
_this=_PSRoom.call(this,options)||this;_this.classType='rooms';
var settings=Object.assign({},PS.prefs.serversettings);
settings.language||(settings.language=Dex.text.getBrowserLanguage());
PS.send("/updatesettings "+JSON.stringify(settings));
PS.send("/cmd rooms");return _this;
}_inheritsLoose(RoomsRoom,_PSRoom);return RoomsRoom;}(PSRoom);var



RoomsPanel=function(_PSRoomPanel){function RoomsPanel(){var _this2;for(var _len=arguments.length,args=new Array(_len),_key=0;_key<_len;_key++){args[_key]=arguments[_key];}_this2=_PSRoomPanel.call.apply(_PSRoomPanel,[this].concat(args))||this;_this2.






hidden=false;_this2.
search='';_this2.
section='';_this2.
lastKeyCode=0;_this2.
roomList=[];_this2.
roomListFocusIndex=-1;_this2.
roomListLength=0;_this2.













hide=function(ev){
ev.stopImmediatePropagation();
PS.hideRightRoom();
};_this2.
changeSearch=function(ev){
var target=ev.currentTarget;
if(target.selectionStart!==target.selectionEnd)return;
if(target.value.startsWith('/')){
_this2.updateRoomList(target.value);
_this2.forceUpdate();
return;
}
_this2.updateRoomList(target.value);
_this2.forceUpdate();
};_this2.
changeSection=function(ev){
var target=ev.currentTarget;
_this2.section=target.value;
_this2.forceUpdate();
};_this2.
handleOnBlur=function(ev){
_this2.roomListFocusIndex=-1;
_this2.forceUpdate();
};_this2.
keyDownSearch=function(ev){
_this2.lastKeyCode=ev.keyCode;
if(ev.shiftKey||ev.ctrlKey||ev.altKey||ev.metaKey)return;
if(ev.keyCode===38){
_this2.roomListFocusIndex=Math.max(_this2.roomListFocusIndex-1,_this2.search?0:-1);
_this2.forceUpdate();
ev.preventDefault();
}else if(ev.keyCode===40){
_this2.roomListFocusIndex=Math.min(_this2.roomListFocusIndex+1,_this2.roomListLength-1);
_this2.forceUpdate();
ev.preventDefault();
}else if(ev.keyCode===13){
var target=ev.currentTarget;
var value=target.value.startsWith('/')?target.value:_this2.getRoomListFocusTitle()||target.value;
ev.preventDefault();
ev.stopImmediatePropagation();
target.value='';
_this2.updateRoomList('');
if(value.startsWith('/')){var _PS$rooms$dm;
PS.join('dm-');
(_PS$rooms$dm=PS.rooms['dm-'])==null||_PS$rooms$dm.send(value,target);
return;
}

var arrowIndex=value.indexOf(" \u21D2 ");
if(arrowIndex>=0)value=value.slice(arrowIndex+3);
if(!/^[a-z0-9-]$/.test(value))value=toID(value);

PS.join(value);
}
};return _this2;}_inheritsLoose(RoomsPanel,_PSRoomPanel);var _proto=RoomsPanel.prototype;_proto.componentDidMount=function componentDidMount(){var _Config$includes;_PSRoomPanel.prototype.componentDidMount.call(this);this.subscriptions.push(PS.user.subscribe(function(update){if(!update&&PS.user.named)PS.send("/cmd rooms");}));(_Config$includes=Config.includes)==null||_Config$includes.htmlDidMount==null||_Config$includes.htmlDidMount();};_proto.componentDidUpdate=function componentDidUpdate(){var _this$base;_PSRoomPanel.prototype.componentDidUpdate.call(this);var el=(_this$base=this.base)==null?void 0:_this$base.querySelector('a.blocklink.cur');if(!this.roomListFocusIndex)return;el==null||el.scrollIntoView({behavior:'auto',block:'center'});};_proto.
updateRoomList=function updateRoomList(search){
if(search&&!search.startsWith('/'))search=toID(search);
var forceNoAutocomplete=this.search===(search||'')+"-";
if(search||this.search){
if(search===undefined||search===this.search)return;
this.search=search;
this.roomListFocusIndex=this.search?0:-1;
}
this.roomList=this.getRoomList(forceNoAutocomplete);
if(!this.search){for(var _i2=0,_this$roomList2=
this.roomList;_i2<_this$roomList2.length;_i2++){var _ref=_this$roomList2[_i2];var rooms=_ref[1];
rooms.sort(function(a,b){return(b.userCount||0)-(a.userCount||0);});
}
}
};_proto.
getRoomList=function getRoomList(forceNoAutocomplete){
if(this.search.startsWith('/')){
return[[TL(["Command"]),[{
title:TL(["Console"]),id:'dm-',desc:TL(["Enter = run command ",""],this.search)
}]]];
}
var searchid=toID(this.search);

if(!searchid){
var roomsCache=PS.mainmenu.roomsCache;
var spotLightLabel='';
var languageRooms=[],officialRooms=[],chatRooms=[],hiddenRooms=[],spotLightRooms=[];
var languageRoomIDs=LANGUAGE_ROOM_IDS[Dex.text.getLanguage()]||[];
var languageRoom=languageRoomIDs.map(function(roomid){var _roomsCache$chat;return(_roomsCache$chat=
roomsCache.chat)==null?void 0:_roomsCache$chat.find(function(room){return room.id===roomid||toID(room.title)===roomid;});}
).find(function(room){return!!room&&room.privacy!=='hidden';});for(var _i4=0,_ref3=
roomsCache.chat||[];_i4<_ref3.length;_i4++){var room=_ref3[_i4];
if(room.section!==this.section&&this.section!=='')continue;
if(room===languageRoom){
languageRooms.push(room);
}else if(room.privacy==='hidden'){
hiddenRooms.push(room);
}else if(room.spotlight){
spotLightLabel=room.spotlight;
spotLightRooms.push(room);
}else if(room.section==='Official'){
officialRooms.push(room);
}else{
chatRooms.push(room);
}
}
return[
[TL(["Language room"]),languageRooms],
[TL(["Official chat rooms"]),officialRooms],
[spotLightLabel,spotLightRooms],
[TL(["Chat rooms"]),chatRooms],
[TL(["Hidden rooms"]),hiddenRooms]];

}

var rooms=PS.mainmenu.roomsCache;
var roomList=[].concat(rooms.chat||[]);for(var _i6=0,_roomList2=
roomList;_i6<_roomList2.length;_i6++){var _room=_roomList2[_i6];
if(!_room.subRooms)continue;for(var _i8=0,_room$subRooms2=
_room.subRooms;_i8<_room$subRooms2.length;_i8++){var title=_room$subRooms2[_i8];
roomList.push({
title:title,
desc:TL(["(Subroom of ",")"],_room.title)
});
}
}

roomList.sort(function(a,b){return(b.userCount||0)-(a.userCount||0);});
var exactMatch=roomList.some(function(room){return toID(room.title)===searchid;});


var results=roomList.filter(function(room){return(
toID(room.title)===ROOM_ALIASES[searchid]||
toID(room.title.toLowerCase().replace(/\b([a-z0-9])[a-z0-9]*\b/g,'$1'))===searchid||
room.title.replace(/[^A-Z0-9]+/g,'').toLowerCase()===searchid);}
);
roomList=roomList.filter(function(room){return!results.includes(room);});

results=results.concat(roomList.filter(function(room){return(
toID(room.title).startsWith(searchid)||
toID(room.title.replace(/^The /,'')).startsWith(searchid)||
toID(room.title.toLowerCase().replace(/\b([a-z0-9])[a-z0-9]*\b/g,'$1')).startsWith(searchid)||
room.title.replace(/[^A-Z0-9]+/g,'').toLowerCase().startsWith(searchid));}
));

var hidden=!exactMatch?
[[TL(["Possible secret room"]),[{title:this.search,desc:TL(["(Private room?)"])}]]]:[];

var autoFill=this.lastKeyCode!==127&&this.lastKeyCode>=32;
if(autoFill&&!forceNoAutocomplete){
var firstTitle=(results[0]||hidden[0][1][0]).title;
var firstTitleOffset=0;
while(
searchid!==toID(firstTitle.slice(0,firstTitleOffset))&&
firstTitleOffset<firstTitle.length)
{
firstTitleOffset++;
}
var autoFillValue=firstTitle.slice(firstTitleOffset);
if(!autoFillValue&&toID(firstTitle)!==searchid){
autoFillValue=" \u21D2 "+firstTitle;
}
var oldSearch=this.search;
var searchElem=this.base.querySelector('input[type=search]');
if(autoFillValue){
searchElem.value=oldSearch+autoFillValue;
searchElem.setSelectionRange(oldSearch.length,oldSearch.length+autoFillValue.length);
this.search+='-';
}

return[[TL(["Search results"]),results]].concat(hidden);
}

return[].concat(hidden,[[TL(["Search results"]),results]]);
};_proto.
render=function render(){var _Config$includes2,_rooms$sectionTitles;
if(this.hidden&&PS.isVisiblePanel(this.props.room))this.hidden=false;
if(this.hidden){
return preact.h(PSPanelWrapper,{room:this.props.room},null);
}
var rooms=PS.mainmenu.roomsCache;
this.updateRoomList();

return preact.h(PSPanelWrapper,{room:this.props.room},preact.h("div",{"class":"pad"},
preact.h("button",{"class":"button",style:"float:right;font-size:10pt;margin-top:3px",onClick:this.hide},
preact.h("i",{"class":"fa fa-caret-right","aria-hidden":true})," ",TL(["[Hide]"])
),
preact.h("div",{"class":"roomcounters"},
preact.h("a",{"class":"button",href:"users",title:TL(["Find an online user"])},
preact.h("span",{
"class":"pixelated usercount"+(Dex.afdMode===true?' afd':''),
title:TL(["Meloetta is PS's mascot! The Aria forme is about using its voice, and represents our chatrooms."])}
),
preact.h("strong",null,rooms.userCount||'-')," ",TL(["users online"])
)," ",
preact.h("a",{"class":"button",href:"battles",title:TL(["Watch an active battle"])},
preact.h("span",{
"class":"pixelated battlecount"+(Dex.afdMode?' afd':''),
title:TL(["Meloetta is PS's mascot! The Pirouette forme is Fighting-type, and represents our battles."])}
),
preact.h("strong",null,rooms.battleCount||'-')," ",TL(["active battles"])
)
),
!!PS.leftPanelWidth&&((_Config$includes2=Config.includes)==null?void 0:_Config$includes2.roomlistTopHTML)&&
preact.h("div",{dangerouslySetInnerHTML:{__html:Config.includes.roomlistTopHTML}}),

preact.h("div",null,
preact.h("select",{name:"sections","class":"select",onChange:this.changeSection},
preact.h("option",{value:""},TL(["(All rooms)"])),(_rooms$sectionTitles=
rooms.sectionTitles)==null?void 0:_rooms$sectionTitles.map(function(title){
return preact.h("option",{value:title}," ",title," ");
})
),
preact.h("p",null,preact.h("input",{
type:"search",name:"roomsearch","class":"textbox autofocus",style:"width: 100%; max-width: 480px",
placeholder:TL(["Join or search for rooms"]),autocomplete:"off",
onInput:this.changeSearch,onKeyDown:this.keyDownSearch,onBlur:this.handleOnBlur}
))
),
this.renderRoomList()
));
};_proto.
getRoomListFocusTitle=function getRoomListFocusTitle(){var _this$roomList$map$re;
return(_this$roomList$map$re=this.roomList.map(function(_ref4){var rooms=_ref4[1];return rooms;}).reduce(function(a,b){return a.concat(b);})[this.roomListFocusIndex])==null?void 0:_this$roomList$map$re.title;
};_proto.
renderRoomList=function renderRoomList(){var _this3=this;
var roomsCache=PS.mainmenu.roomsCache;
if(roomsCache.userCount===undefined){
return preact.h("div",{"class":"roomlist"},preact.h("h2",null,TL(["Official chat rooms"])),preact.h("p",null,preact.h("em",null,TL(["Connecting..."]))));
}
if(this.search){

}else if(PS.isOffline){
return preact.h("div",{"class":"roomlist"},preact.h("h2",null,TL(["Offline"])));
}else if(roomsCache.userCount===undefined){
return preact.h("div",{"class":"roomlist"},preact.h("h2",null,TL(["Official chat rooms"])),preact.h("p",null,preact.h("em",null,TL(["Connecting..."]))));
}

var nextOffset=0;
return this.roomList.filter(function(_ref5){var rooms=_ref5[1];return rooms.length>0;}).map(function(_ref6,sectionCount){var _Config$includes3;var title=_ref6[0],rooms=_ref6[1];
var offset=nextOffset;
nextOffset+=rooms.length;
_this3.roomListLength=nextOffset;

var index=_this3.roomListFocusIndex>=offset&&_this3.roomListFocusIndex<nextOffset?
_this3.roomListFocusIndex-offset:-1;

return preact.h(preact.Fragment,null,
preact.h("div",{"class":"roomlist"},
preact.h("h2",null,title),
rooms.map(function(roomInfo,i){return preact.h("div",{key:roomInfo.title},
preact.h("a",{href:"/"+(roomInfo.id||toID(roomInfo.title)),"class":"blocklink"+(i===index?" cur":'')},
roomInfo.userCount!==undefined&&preact.h("small",{style:"float:right"},"(",TL([""," users"],roomInfo.userCount),")"),
preact.h("strong",null,preact.h("i",{"class":"fa fa-comment-o","aria-hidden":true})," ",roomInfo.title,preact.h("br",null)),
preact.h("small",null,roomInfo.desc||'')
),
roomInfo.subRooms&&preact.h("div",{"class":"subrooms"},
preact.h("i",{"class":"fa fa-level-up fa-rotate-90","aria-hidden":true})," ",TL.label(TL(["Subrooms"])),
roomInfo.subRooms.map(function(roomName){return[preact.h("a",{href:"/"+toID(roomName),"class":"blocklink"},
preact.h("i",{"class":"fa fa-comment-o","aria-hidden":true})," ",preact.h("strong",null,roomName)
),' '];})
)
);})
),
sectionCount===0&&!!PS.leftPanelWidth&&((_Config$includes3=Config.includes)==null?void 0:_Config$includes3.roomlistAfterFirstHTML)&&
preact.h("div",{dangerouslySetInnerHTML:{__html:Config.includes.roomlistAfterFirstHTML}})

);
});
};return RoomsPanel;}(PSRoomPanel);RoomsPanel.id='rooms';RoomsPanel.routes=['rooms'];RoomsPanel.Model=RoomsRoom;RoomsPanel.location='right';RoomsPanel.icon=preact.h("i",{"class":"fa fa-plus rooms-plus","aria-hidden":true});RoomsPanel.title="Chat Rooms";


PS.addRoomType(RoomsPanel);
//# sourceMappingURL=panel-rooms.js.map