"use strict";function _inheritsLoose(t,o){t.prototype=Object.create(o.prototype),t.prototype.constructor=t,_setPrototypeOf(t,o);}function _setPrototypeOf(t,e){return _setPrototypeOf=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(t,e){return t.__proto__=e,t;},_setPrototypeOf(t,e);}var








ResourcePanel=function(_PSRoomPanel){function ResourcePanel(){var _this;for(var _len=arguments.length,args=new Array(_len),_key=0;_key<_len;_key++){args[_key]=arguments[_key];}_this=_PSRoomPanel.call.apply(_PSRoomPanel,[this].concat(args))||this;_this.





state={search:''};_this.
onChangeSearch=function(e){
_this.setState({search:e.currentTarget.value});
};_this.





onToggleDetails=function(e){
var someOpen=false;
var allOpen=true;for(var _i2=0,_this$getDetailsEleme2=
_this.getDetailsElements();_i2<_this$getDetailsEleme2.length;_i2++){var detail=_this$getDetailsEleme2[_i2];
if(detail.open){
someOpen=true;
}else{
allOpen=false;
}
}

var collapseAll=_this.base.querySelector('input[name=collapseall]');
if(!collapseAll)return;
collapseAll.checked=!allOpen;
collapseAll.indeterminate=someOpen&&!allOpen;
};_this.

onToggleCollapseAll=function(e){
var checked=e.currentTarget.checked;for(var _i4=0,_this$getDetailsEleme4=
_this.getDetailsElements();_i4<_this$getDetailsEleme4.length;_i4++){var detail=_this$getDetailsEleme4[_i4];
detail.open=!checked;
}
};return _this;}_inheritsLoose(ResourcePanel,_PSRoomPanel);var _proto=ResourcePanel.prototype;_proto.getDetailsElements=function getDetailsElements(){return this.base.querySelectorAll('details.commandlist');};_proto.
render=function render(){
var room=this.props.room;

return preact.h(PSPanelWrapper,{room:room},
preact.h("div",{className:"pad"},
preact.h("h2",null,"PS! Informational Resources"),
preact.h("hr",null),
preact.h("p",null,"PS! is a wide and varied site, with more facets than can be covered here easily.",

preact.h("br",null),"While this page chiefly documents the ever-shifting set of commands available to PS! users, ",
"here are some useful resources for newcomers:"

),
preact.h("ul",null,
preact.h("li",null,
preact.h("a",{href:"https://www.smogon.com/forums/threads/3676132/"},"Beginner's Guide to Pok\xE9mon Showdown")
),
preact.h("li",null,
preact.h("a",{href:"https://www.smogon.com/dp/articles/intro_comp_pokemon"},"An introduction to competitive Pok\xE9mon")
),
preact.h("li",null,
preact.h("a",{href:"https://www.smogon.com/sm/articles/sm_tiers"},"What do 'OU', 'UU', etc mean?")
),
preact.h("li",null,
preact.h("a",{href:"https://www.smogon.com/dex/sv/formats/"},"What are the rules for each format?")
),
preact.h("li",null,
preact.h("a",{href:"https://www.smogon.com/sv/articles/clauses"},"What is 'Sleep Clause' and other clauses?")
),
preact.h("li",null,
preact.h("a",{href:"https://www.smogon.com/articles/getting-started"},"Next Steps for Competitive Battling")
),
preact.h("li",null,
preact.h("button",{className:"button","data-cmd":"/report"},TL(["[Report a user]"]))
),
preact.h("li",null,
preact.h("button",{className:"button","data-cmd":"/join help"},TL(["[Join the Help room for live help]"]))
)
),
preact.h("hr",null),
preact.h("h3",null,"Commands"),
preact.h("p",null,"Within any of the chats, and in private messages, ",
"it is possible to type in commands (messages beginning with ",
preact.h("code",null,"/"),") ","to perform a particular action. A great number of these commands exist,  ",
"with some only available to certain users. For instance, you can broadcast commands to others with the ",

preact.h("code",null,"!")," prefix, but only when you're a player in a battle or a Voice (+) user.",
preact.h("br",null),"For more information on ranks, type ",
preact.h("code",null,"/groups")," in any chat. ","You can also use the \"chat self\" button on your username in the top right  ",
"if you need a place to send these commands without joining a room."

),

preact.h("details",{"class":"readmore"},
preact.h("summary",null,"Here's a list of the most useful commands for the average Pok\xE9mon Showdown experience:"),
preact.h("p",null,"COMMANDS: /report, /msg, /reply, /logout, ",
"/challenge, /search, /rating, /whois, /user, /join, /leave, /userauth, /roomauth"

),
preact.h("p",null,"BATTLE ROOM COMMANDS: /savereplay, /hideroom, /inviteonly, /invite, ",
"/timer, /forfeit"

),
preact.h("p",null,"OPTION COMMANDS: /nick, /avatar, /ignore, /status, /away, /busy, /back, /timestamps, ",
"/highlight, /showjoins, /hidejoins, /blockchallenges, /blockpms"

),
preact.h("p",null,"INFORMATIONAL/RESOURCE COMMANDS: /groups, /faq, /rules, /intro, /formatshelp, ",
"/othermetas, /analysis, /punishments, /calc, /git, /cap, /roomhelp, /roomfaq ",
"(replace / with ! to broadcast. Broadcasting requires: + % @ # ~)"

),
preact.h("p",null,"DATA COMMANDS: /data, /dexsearch, /movesearch, /itemsearch, /learn, ",
"/statcalc, /effectiveness, /weakness, /coverage, /randommove, /randompokemon"
),
preact.h("p",null,"For an overview of room commands, use ",preact.h("code",null,"/roomhelp")),
preact.h("p",null,"For details of a specific command, you can use ",preact.h("code",null,"/help [command]"),", for example ",preact.h("code",null,"/help data"),".")
),

preact.h("br",null),
preact.h("p",null,"A complete list of commands available to regular users is provided below. Use  ",

preact.h("code",null,"/help [commandname]")," for more in-depth information on how to use them."
),
preact.h("hr",null),
preact.h("h3",null,"Search"),
preact.h("p",null,
preact.h("label",{"class":"checkbox",style:{"float":'right'}},
preact.h("input",{
type:"checkbox",name:"collapseall",
onChange:this.onToggleCollapseAll}
)," Collapse all"
),
preact.h("input",{
type:"search",name:"command-search","class":"textbox",style:{width:"50%"},
value:this.state.search,placeholder:"Filter by command name",
onInput:this.onChangeSearch}
)
),
preact.h("br",null),
this.getCommandList()
)
);
};_proto.
getCommandList=function getCommandList(){var _this2=this;
if(typeof BattleChatCommands!=='object'){
document.addEventListener('ready',function(){return _this2.setState({commandsLoaded:true});});
return preact.h(preact.Fragment,null,"Loading command data, please try again in a few moments...");
}
var buf=[];
var search=this.state.search;
var keys=Object.keys(BattleChatCommands).filter(function(plugin){return!plugin.endsWith('admin');});
PSUtils.sortBy(keys,function(key){return[
key.endsWith('info')?0:
key.includes('chat-commands')?1:
2,

BattleChatCommands[key].filter(function(x){return toID(x).includes(search);}).length,
key];}
);for(var _i6=0;_i6<

keys.length;_i6++){var pluginName=keys[_i6];
var cmdTable=BattleChatCommands[pluginName];
if(!cmdTable.length)continue;
var pluginSection=null;
if(pluginName.startsWith('chat-plugins/')){
pluginSection='Chat plugin';
pluginName=pluginName.slice('chat-plugins/'.length);
}else if(pluginName.startsWith('chat-commands/')){
pluginSection='Core commands';
pluginName=pluginName.slice('chat-commands/'.length);
}
var matchedCmds=[];for(var _i8=0;_i8<
cmdTable.length;_i8++){var cmd=cmdTable[_i8];
if(search.length&&!toID(cmd).includes(search)){
continue;
}
matchedCmds.push(preact.h("li",null,cmd));
}

if(!matchedCmds.length){
buf.push(null);
buf.push(null);
continue;
}
buf.push(
preact.h("details",{"class":"readmore commandlist",open:true,onToggle:this.onToggleDetails},
preact.h("summary",null,
preact.h("strong",null,pluginName)," ",search.length?preact.h(preact.Fragment,null,"(",matchedCmds.length,")"):''," ",
pluginSection&&preact.h("small",null,"[",pluginSection,"]")
),
preact.h("ul",null,matchedCmds)
)
);
buf.push(preact.h("br",null));
}
return buf;
};return ResourcePanel;}(PSRoomPanel);ResourcePanel.id='resources';ResourcePanel.routes=['resources'];ResourcePanel.icon=preact.h("i",{"class":"fa fa-question-circle","aria-hidden":true});ResourcePanel.title='Resources';


PS.addRoomType(ResourcePanel);
//# sourceMappingURL=panel-resources.js.map