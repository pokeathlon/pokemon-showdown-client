"use strict";function _inheritsLoose(t,o){t.prototype=Object.create(o.prototype),t.prototype.constructor=t,_setPrototypeOf(t,o);}function _setPrototypeOf(t,e){return _setPrototypeOf=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(t,e){return t.__proto__=e,t;},_setPrototypeOf(t,e);}/**
 * Battle panel
 *
 * @author Guangcong Luo <guangcongluo@gmail.com>
 * @license AGPLv3
 */var




























BattlesRoom=function(_PSRoom){





function BattlesRoom(options){var _this;
_this=_PSRoom.call(this,options)||this;_this.classType='battles';_this.format='';_this.filters='';_this.battles=null;
_this.refresh();

if(PS.prefs.bwgfx){
Dex.loadSpriteData('bw');
}return _this;
}_inheritsLoose(BattlesRoom,_PSRoom);var _proto=BattlesRoom.prototype;_proto.
setFormat=function setFormat(format){
if(format===this.format)return this.refresh();
this.battles=null;
this.format=format;
this.update(null);
this.refresh();
};_proto.
refresh=function refresh(){
PS.send("/cmd roomlist "+toID(this.format)+", "+this.filters);
};return BattlesRoom;}(PSRoom);var


BattlesPanel=function(_PSRoomPanel){function BattlesPanel(){var _this2;for(var _len=arguments.length,args=new Array(_len),_key=0;_key<_len;_key++){args[_key]=arguments[_key];}_this2=_PSRoomPanel.call.apply(_PSRoomPanel,[this].concat(args))||this;_this2.









refresh=function(){
_this2.props.room.refresh();
};_this2.
changeFormat=function(e){
var value=e.target.value;
_this2.props.room.setFormat(value);
};_this2.
applyFilters=function(e){var _this2$base,_this2$base2;
e.preventDefault();
var minElo=(_this2$base=_this2.base)==null||(_this2$base=_this2$base.querySelector("select[name=elofilter]"))==null?void 0:_this2$base.value;
var searchPrefix=(_this2$base2=_this2.base)==null||(_this2$base2=_this2$base2.querySelector("input[name=prefixsearch]"))==null?void 0:_this2$base2.value;
_this2.props.room.filters=(minElo||'')+","+(searchPrefix||'');
_this2.refresh();
};return _this2;}_inheritsLoose(BattlesPanel,_PSRoomPanel);BattlesPanel.getTitle=function getTitle(){return TL(["Battles"]);};var _proto2=BattlesPanel.prototype;_proto2.
renderBattleLink=function renderBattleLink(battle){
var format=battle.id.split('-')[1];
var minEloMessage=typeof battle.minElo==='number'?TL(["rated ",""],battle.minElo):battle.minElo;
var players=TL([""," vs. ",""],battle.p1,battle.p2);
return preact.h("div",{key:battle.id},preact.h("a",{href:"/"+battle.id,"class":"blocklink"},
minEloMessage&&preact.h("small",{style:"float:right"},"(",minEloMessage,")"),
preact.h("small",null,"[",format,"]"),preact.h("br",null),
preact.h("em",null,players)
));
};_proto2.
render=function render(){var _this3=this;
var room=this.props.room;
return preact.h(PSPanelWrapper,{room:room},preact.h("div",{"class":"pad"},
preact.h("button",{"class":"button",style:"float:right;font-size:10pt;margin-top:3px",name:"closeRoom"},
preact.h("i",{"class":"fa fa-times","aria-hidden":true})," ",TL(["[Close]"])
),
preact.h("div",{"class":"roomlist"},
preact.h("p",null,
preact.h("button",{"class":"button",name:"refresh",onClick:this.refresh},
preact.h("i",{"class":"fa fa-refresh","aria-hidden":true})," ",TL(["[Refresh]"])
)," ",
preact.h("span",{
style:Dex.getPokemonIcon('meloetta-pirouette')+';display:inline-block;vertical-align:middle',"class":"picon",
title:TL(["Meloetta is PS's mascot! The Pirouette forme is Fighting-type, and represents our battles."])}
)
),

preact.h("p",null,
preact.h("label",{"class":"label"},TL.label(TL(["Format"]))),
preact.h(FormatDropdown,{onChange:this.changeFormat,placeholder:TL(["(All formats)"])})
),
preact.h("label",{"class":"label"},
TL.label(TL(["Minimum Elo"])),preact.h("select",{name:"elofilter","class":"select",onChange:this.applyFilters},
preact.h("option",{value:"none"},TL(["None"])),preact.h("option",{value:"1100"},"1100"),preact.h("option",{value:"1300"},"1300"),
preact.h("option",{value:"1500"},"1500"),preact.h("option",{value:"1700"},"1700"),preact.h("option",{value:"1900"},"1900")
)
),

preact.h("form",{"class":"search",onSubmit:this.applyFilters},
preact.h("p",null,
preact.h("input",{type:"text",name:"prefixsearch","class":"textbox",placeholder:TL(["Username prefix"]),autocomplete:"off"}),
preact.h("button",{type:"submit","class":"button"},TL(["[Search]"]))
)
),
preact.h("div",{"class":"list"},!room.battles?
preact.h("p",null,TL(["Loading..."])):
!room.battles.length?
preact.h("p",null,TL(["No battles are going on"])):
preact.h(preact.Fragment,null,
preact.h("p",null,room.battles.length===1?
TL([""," battle"],1):

TL([""," battles"],room.battles.length===100?'100+':room.battles.length)
),
room.battles.map(function(battle){return _this3.renderBattleLink(battle);})
)
)
)
));
};return BattlesPanel;}(PSRoomPanel);BattlesPanel.id='battles';BattlesPanel.routes=['battles'];BattlesPanel.Model=BattlesRoom;BattlesPanel.location='right';BattlesPanel.icon=preact.h("i",{"class":"fa fa-caret-square-o-right","aria-hidden":true});BattlesPanel.title='Battles';var


BattleRoom=function(_ChatRoom){function BattleRoom(){var _this4;for(var _len2=arguments.length,args=new Array(_len2),_key2=0;_key2<_len2;_key2++){args[_key2]=arguments[_key2];}_this4=_ChatRoom.call.apply(_ChatRoom,[this].concat(args))||this;_this4.
classType='battle';_this4.





battle=null;_this4.

side=null;_this4.
request=null;_this4.
choices=null;_this4.
autoTimerActivated=null;_this4.
requireForfeit=false;_this4.



rejoining=null;_this4.
overlayActive=null;_this4.

pendingLines=[];_this4.

onRequest=null;return _this4;}_inheritsLoose(BattleRoom,_ChatRoom);var _proto3=BattleRoom.prototype;_proto3.

receiveBatch=function receiveBatch(batch){for(var _i2=0,_batch2=
batch;_i2<_batch2.length;_i2++){var args=_batch2[_i2];this.receiveLine(args);}
if(!this.battle){var _this$pendingLines;
(_this$pendingLines=this.pendingLines).push.apply(_this$pendingLines,batch);
this.update(null);
return;
}
if(this.pendingLines.length){
batch=[].concat(this.pendingLines,batch);
this.pendingLines=[];
}
if(!batch.length){
this.update(null);
return;
}

var battleLines=[];
var controlLines=[];for(var _i4=0,_batch4=
batch;_i4<_batch4.length;_i4++){var _args=_batch4[_i4];
if(this.handleLine(_args))continue;
switch(_args[0]){
case'request':case'sentchoice':case'initdone':
controlLines.push(_args);
continue;
case'win':case'tie':case'error':
controlLines.push(_args);
break;
}
battleLines.push('|'+_args.join('|'));
}
this.battle.addBatch(battleLines);for(var _i6=0;_i6<

controlLines.length;_i6++){var _args2=controlLines[_i6];this.handleLineAfterBattleUpdate(_args2);}
if(PS.prefs.noanim||this.rejoining&&this.side){
this.battle.seekTurn(Infinity);
}
if(this.side)this.rejoining=false;

this.updateChoiceNotification();
this.update(null);
};_proto3.
handleLine=function handleLine(args){
if(_ChatRoom.prototype.handleLine.call(this,args))return true;
switch(args[0]){
case'cantleave':
this.requireForfeit=true;
return true;
case'allowleave':
this.requireForfeit=false;
return true;
}
return false;
};_proto3.
handleLineAfterBattleUpdate=function handleLineAfterBattleUpdate(args){
switch(args[0]){
case'initdone':
if(!PS.prefs.spectatefromstart)this.battle.seekTurn(Infinity);
break;
case'request':case'win':case'tie':{var _this$onRequest;
var request=args[0]==='request'&&args[1]?JSON.parse(args[1]):null;
this.receiveRequest(request);
(_this$onRequest=this.onRequest)==null||_this$onRequest.call(this,request);
break;
}
case'error':
if(args[1].startsWith('[Invalid choice]')&&this.request){
this.choices=new BattleChoiceBuilder(this.request);
}
break;
case'sentchoice':
if(this.request){
var choices=new BattleChoiceBuilder(this.request);
var possibleError=choices.addChoices(args[1]);
if(possibleError||!choices.isDone()){
choices=new BattleChoiceBuilder(this.request);
choices.serializedChoice=args[1];
}
this.choices=choices;
}
break;
}
};_proto3.
receiveRequest=function receiveRequest(request){
if(!request){
this.request=null;
this.choices=null;
return;
}

if(PS.prefs.autotimer&&!this.battle.kickingInactive&&!this.autoTimerActivated){
this.send('/timer on');
this.autoTimerActivated=true;
}

BattleChoiceBuilder.fixRequest(request,this.battle);

if(request.side){
this.battle.myPokemon=request.side.pokemon;
this.battle.setViewpoint(request.side.id);
this.side=request.side;
}
if(request.ally){
this.battle.myAllyPokemon=request.ally.pokemon;
}

this.request=request;
this.choices=new BattleChoiceBuilder(request);
};_proto3.

interruptClose=function interruptClose(explicit,elem){
if(this.isPlaying()||this.requireForfeit){
PS.join('forfeitbattle',{parentElem:elem,parentRoomid:this.id});
return TL(["You are still in ",""],this.title);
}
return _ChatRoom.prototype.interruptClose.call(this,explicit,elem);
};_proto3.
isPlaying=function isPlaying(){
return this.battle&&!this.battle.ended&&this.request&&this.connectMode!=='deleted';
};_proto3.
updateChoiceNotification=function updateChoiceNotification(){var _this$battle,_this$request;
var oName=(_this$battle=this.battle)==null?void 0:_this$battle.farSide.name;
var title='';
var body='';
switch((_this$request=this.request)==null?void 0:_this$request.requestType){
case'move':
title=BattleTextParser.ui('notifyMoveTitle');
body=oName?BattleTextParser.ui('notifyMoveAgainst',{OPPONENT:oName}):BattleTextParser.ui('notifyMove');
break;
case'switch':
title=BattleTextParser.ui('notifySwitchTitle');
body=oName?BattleTextParser.ui('notifySwitchAgainst',{OPPONENT:oName}):BattleTextParser.ui('notifySwitch');
break;
case'team':
title=BattleTextParser.ui('notifyTeamTitle');
body=oName?BattleTextParser.ui('notifyTeamAgainst',{OPPONENT:oName}):BattleTextParser.ui('notifyTeam');
break;
}

if(!this.choices||this.choices.isDone())body='';

var current=this.notifications.find(function(notification){return notification.id==='choice';});
if(((current==null?void 0:current.body)||'')===body)return;

if(!body){
this.dismissNotification('choice');
}else{
this.notify({title:title,body:body,id:'choice',noAutoDismiss:true});
}
};_proto3.

handleReconnect=function handleReconnect(){
this.pendingLines=[];
if(this.battle){
this.battle.stepQueue=[];
this.battle.preemptStepQueue=[];
this.battle.resetStep();
}
this.side=null;
this.request=null;
this.choices=null;
this.updateChoiceNotification();
return false;
};_proto3.

destroy=function destroy(){
this.request=null;
this.choices=null;
_ChatRoom.prototype.destroy.call(this);
};_proto3.

loadReplay=function loadReplay(){var _this5=this;
var replayid=this.id.slice(7);
Net("https://replay.pokemonshowdown.com/"+replayid+".json").get()["catch"](function(){return'';}).then(function(data){
try{
var replay=JSON.parse(data);
var _replay$players=replay.players,player1=_replay$players[0],player2=_replay$players[1];
var players=replay.players.length===2?TL([""," vs. ",""],player1,player2):replay.players.join(' vs. ');
_this5.title="["+replay.format+"] "+players;
_this5.battle.stepQueue=replay.log.split('\n');
_this5.battle.atQueueEnd=false;
_this5.battle.pause();
_this5.battle.seekTurn(0);
_this5.connectMode=null;
_this5.connectError=null;
_this5.update(null);
}catch(_unused){
_this5.connectError=TL(["Battle \"","\" not found"],replayid);
if(!_this5.battle.stepQueue.length){
_this5.battle.scene.message(
"<div class=\"broadcast-red pad\"><strong>"+BattleLog.escapeHTML(_this5.connectError)+"</strong></div><br />"+(
TL(["The battle you're looking for has expired. Battles expire after 15 minutes of inactivity unless they're saved."])+"<br /><br />")+
TL(["In the future, remember to click \"Save replay\" to save a replay permanently."])
);
}
_this5.update(null);
}
});
};return BattleRoom;}(ChatRoom);var


BattleDiv=function(_preact$Component){function BattleDiv(){return _preact$Component.apply(this,arguments)||this;}_inheritsLoose(BattleDiv,_preact$Component);var _proto4=BattleDiv.prototype;_proto4.
shouldComponentUpdate=function shouldComponentUpdate(){
return false;
};_proto4.
componentDidMount=function componentDidMount(){
var room=this.props.room;
if(room.battle){
this.base.replaceChild(room.battle.scene.$frame[0],this.base.firstChild);
}
};_proto4.
render=function render(){
return preact.h("div",null,preact.h("div",{"class":"battle"}));
};return BattleDiv;}(preact.Component);var


TimerButton=function(_preact$Component2){function TimerButton(){var _this6;for(var _len3=arguments.length,args=new Array(_len3),_key3=0;_key3<_len3;_key3++){args[_key3]=arguments[_key3];}_this6=_preact$Component2.call.apply(_preact$Component2,[this].concat(args))||this;_this6.
timerInterval=null;return _this6;}_inheritsLoose(TimerButton,_preact$Component2);var _proto5=TimerButton.prototype;_proto5.
componentWillUnmount=function componentWillUnmount(){
if(this.timerInterval){
clearInterval(this.timerInterval);
this.timerInterval=null;
}
};_proto5.
secondsToTime=function secondsToTime(seconds){
if(seconds===true)return'-:--';
var minutes=Math.floor(seconds/60);
seconds-=minutes*60;
return minutes+":"+(seconds<10?'0':'')+seconds;
};_proto5.
render=function render(){var _this7=this;
var time=TL(["Timer"]);
var room=this.props.room;
if(!this.timerInterval&&room.battle.kickingInactive){
this.timerInterval=setInterval(function(){var _room$choices;
if((_room$choices=room.choices)!=null&&_room$choices.isDone())return;
if(typeof room.battle.kickingInactive==='number'&&room.battle.kickingInactive>1){
room.battle.kickingInactive--;
if(room.battle.graceTimeLeft)room.battle.graceTimeLeft--;else
if(room.battle.totalTimeLeft)room.battle.totalTimeLeft--;
}
_this7.forceUpdate();
},1000);
}else if(this.timerInterval&&!room.battle.kickingInactive){
clearInterval(this.timerInterval);
this.timerInterval=null;
}

var timerTicking=room.battle.kickingInactive&&
room.request&&room.request.requestType!=="wait"&&room.choices&&!room.choices.isDone()?
' timerbutton-on':'';

if(room.battle.kickingInactive){
var secondsLeft=room.battle.kickingInactive;
time=this.secondsToTime(secondsLeft);
if(secondsLeft!==true){
if(secondsLeft<=10&&timerTicking){
timerTicking=' timerbutton-critical';
}

if(room.battle.totalTimeLeft){
var totalTime=this.secondsToTime(room.battle.totalTimeLeft);
time+=" |  "+totalTime+" total";
}
}
}

return preact.h("button",{
style:{position:"absolute",right:'10px',top:this.props.top+"px"},
"data-href":"battletimer","class":"button"+timerTicking,role:"timer"},

preact.h("i",{"class":"fa fa-hourglass-start","aria-hidden":true})," ",time
);
};return TimerButton;}(preact.Component);
;var

BattlePanel=function(_PSRoomPanel2){function BattlePanel(){var _this8;for(var _len4=arguments.length,args=new Array(_len4),_key4=0;_key4<_len4;_key4++){args[_key4]=arguments[_key4];}_this8=_PSRoomPanel2.call.apply(_PSRoomPanel2,[this].concat(args))||this;_this8.














































































team=null;_this8.
mobileChatShown=false;_this8.
showMobileChat=function(){
_this8.mobileChatShown=true;
_this8.forceUpdate();
};_this8.
showMobileBattle=function(){
_this8.mobileChatShown=false;
_this8.forceUpdate();
};_this8.
send=function(text,elem){
_this8.props.room.send(text,elem);
};_this8.
focusIfNoSelection=function(){var _window$getSelection;
if((window.getSelection==null||(_window$getSelection=window.getSelection())==null?void 0:_window$getSelection.type)==='Range')return;
_this8.focus();
};_this8.
onKey=function(e){
if(e.keyCode===33){
var chatLog=_this8.base.getElementsByClassName('chat-log')[0];
chatLog.scrollTop=chatLog.scrollTop-chatLog.offsetHeight+60;
return true;
}else if(e.keyCode===34){
var _chatLog=_this8.base.getElementsByClassName('chat-log')[0];
_chatLog.scrollTop=_chatLog.scrollTop+_chatLog.offsetHeight-60;
return true;
}
return false;
};_this8.
toggleBoostedMove=function(e){
var checkbox=e.currentTarget;
var choices=_this8.props.room.choices;
if(!choices)return;
switch(checkbox.name){
case'mega':
choices.current.mega=checkbox.checked;
break;
case'megax':
choices.current.megax=checkbox.checked;
choices.current.megay=false;
break;
case'megay':
choices.current.megay=checkbox.checked;
choices.current.megax=false;
break;
case'ultra':
choices.current.ultra=checkbox.checked;
break;
case'z':
choices.current.z=checkbox.checked;
break;
case'max':
choices.current.max=checkbox.checked;
break;
case'tera':
choices.current.tera=checkbox.checked;
break;
}
_this8.props.room.update(null);
};_this8.






























battleHeight=360;_this8.












































































































































































































































































































































































































































































































































































































































































































































































































handleDownloadReplay=function(e){
var room=_this8.props.room;
var target=e.currentTarget;

var filename=(room.battle.tier||'Battle').replace(/[^A-Za-z0-9]/g,'');
var date=new Date();
filename+="-"+date.getFullYear();
filename+="-"+(date.getMonth()>=9?'':'0')+(date.getMonth()+1);
filename+="-"+(date.getDate()>=10?'':'0')+date.getDate();
filename+='-'+toID(room.battle.p1.name);
filename+='-'+toID(room.battle.p2.name);
target.href=window.BattleLog.createReplayFileHref(room);
target.download=filename+'.html';
e.stopPropagation();
};return _this8;}_inheritsLoose(BattlePanel,_PSRoomPanel2);BattlePanel.getTitle=function getTitle(room){var _battle$sides$,_battle$sides$2;var _ref=room,battle=_ref.battle,title=_ref.title;if(title==='Uploaded replay')return TL(["Uploaded replay"]);var p1=battle==null||(_battle$sides$=battle.sides[0])==null?void 0:_battle$sides$.name;var p2=battle==null||(_battle$sides$2=battle.sides[1])==null?void 0:_battle$sides$2.name;if(!p1||!p2)return title;var _ref2=/^(\[[^\]]*\] )?([^]*)$/.exec(title),_ref2$=_ref2[1],prefix=_ref2$===void 0?'':_ref2$,mainTitle=_ref2[2];if(battle.gameType==='multi'&&mainTitle==="Team "+p1+" vs. Team "+p2){var player1=TL(["Team ",""],p1);var player2=TL(["Team ",""],p2);return prefix+TL([""," vs. ",""],player1,player2);}else if(battle.gameType==='freeforall'&&mainTitle===p1+" and friends"){return prefix+TL([""," and friends"],p1);}else if(mainTitle===p1+" vs. "+p2){return prefix+TL([""," vs. ",""],p1,p2);}return title;};BattlePanel.handleDrop=function handleDrop(ev){var _ev$dataTransfer;var file=(_ev$dataTransfer=ev.dataTransfer)==null||(_ev$dataTransfer=_ev$dataTransfer.files)==null?void 0:_ev$dataTransfer[0];if((file==null?void 0:file.type)==='text/html'){var roomNum=1;for(;roomNum<100;roomNum++){if(!PS.rooms["battle-uploaded-"+roomNum])break;}file.text().then(function(html){var titleStart=html.indexOf('<title>');var titleEnd=html.indexOf('</title>');var title='Uploaded replay';if(titleStart>=0&&titleEnd>titleStart){title=html.slice(titleStart+7,titleEnd-1);var colonIndex=title.indexOf(':');var hyphenIndex=title.lastIndexOf('-');if(hyphenIndex>colonIndex+2){title=title.substring(colonIndex+2,hyphenIndex-1);}else{title=title.substring(colonIndex+2);}}var index1=html.indexOf('<script type="text/plain" class="battle-log-data">');var index2=html.indexOf('<script type="text/plain" class="log">');if(index1<0&&index2<0){PS.alert(TL(["Unrecognized HTML file: Only replay files are supported."]));return;}if(index1>=0){html=html.slice(index1+50);}else if(index2>=0){html=html.slice(index2+38);}var index3=html.indexOf('</script>');html=html.slice(0,index3);html=html.replace(/\\\//g,'/');PS.join("battle-uploaded-"+roomNum);var room=PS.rooms["battle-uploaded-"+roomNum];if(!room)return;room.title=title;room.connectMode=null;PS.receive(">battle-uploaded-"+roomNum+"\n"+html);});return true;}};var _proto6=BattlePanel.prototype;_proto6.renderUIText=function renderUIText(id,values){return preact.h("span",{dangerouslySetInnerHTML:{__html:BattleLog.parseLogMessage(BattleTextParser.ui(id,values))[0]}});};_proto6.componentDidMount=function componentDidMount(){var _this9=this;var room=this.props.room;var $elem=$(this.base);var battle=room.battle||(room.battle=new Battle({id:room.id,$frame:$elem.find('.battle'),$logFrame:$elem.find('.battle-log')}));var scene=battle.scene;room.log=scene.log;room.log.getHighlight=room.handleHighlight;room.log.isIgnored=room.isIgnored;scene.tooltips.unlisten(scene.$frame);scene.tooltips.listen(this.base);battle.subscribe(function(){return _this9.forceUpdate();});room.onRequest=function(request){return _this9.receiveRequest(request);};room.receiveBatch([]);_PSRoomPanel2.prototype.componentDidMount.call(this);this.forceUpdate();if(!PS.prefs.spectatefromstart)battle.seekTurn(Infinity);if(PS.prefs.autohardcore){battle.setHardcoreMode(true);}};_proto6.componentWillUnmount=function componentWillUnmount(){var _this$props$room$batt;this.props.room.onRequest=null;var scene=(_this$props$room$batt=this.props.room.battle)==null?void 0:_this$props$room$batt.scene;if(this.base)scene==null||scene.tooltips.unlisten(this.base);_PSRoomPanel2.prototype.componentWillUnmount.call(this);};_proto6.updateLayout=function updateLayout(){if(!this.base)return;var room=this.props.room;if(!room.width)return;var _this$chooseLayout=this.chooseLayout(),battleHeight=_this$chooseLayout.battleHeight;this.battleHeight=battleHeight;if(battleHeight!==360){var _room$battle;(_room$battle=room.battle)==null||_room$battle.scene.$frame.css('transform',"scale("+battleHeight/360+")");}else{var _room$battle2;(_room$battle2=room.battle)==null||_room$battle2.scene.$frame.css('transform','none');}};_proto6.chooseLayout=function chooseLayout(){var room=this.props.room;return PS.chooseBattleLayout(room.width,room.height,PS.prefs.battlelayout);};_proto6.receiveRequest=function receiveRequest(request){};_proto6.renderConnectError=function renderConnectError(){var room=this.props.room;if(room.connectMode!=='deleted'&&room.connectMode!=='not-found'){return null;}return preact.h("div",{"class":"pad"},preact.h("div",{"class":"broadcast-red pad"},preact.h("h3",null,room.connectError||TL(["Error"])),preact.h("p",{"class":"buttonbar"},preact.h("button",{"class":"button","data-cmd":"/close"},preact.h("strong",null,TL(["[Close]"]))))));};_proto6.renderControls=function renderControls(){var overlayVersion=arguments.length>0&&arguments[0]!==undefined?arguments[0]:false;var hidePlayerControls=arguments.length>1&&arguments[1]!==undefined?arguments[1]:false;var room=this.props.room;if(!room.battle)return null;if(overlayVersion){if(!room.side||!room.request||room.battle.ended)return null;return this.renderPlayerControls(room.request,true);}if(room.battle.ended)return this.renderAfterBattleControls();if(room.side&&room.request){if(hidePlayerControls)return null;return this.renderPlayerControls(room.request);}if(room.battle.stepQueue.length===0)return null;var atStart=!room.battle.started;var atEnd=room.battle.atQueueEnd;return preact.h("div",{"class":"inline-controls"},preact.h("p",null,atEnd?preact.h("button",{"class":"button disabled","aria-disabled":true,"data-cmd":"/play",style:"min-width:4.5em"},preact.h("i",{"class":"fa fa-play","aria-hidden":true}),preact.h("br",null),TL(["[Play]"])):room.battle.paused?preact.h("button",{"class":"button","data-cmd":"/play",style:"min-width:4.5em"},preact.h("i",{"class":"fa fa-play","aria-hidden":true}),preact.h("br",null),TL(["[Play]"])):preact.h("button",{"class":"button","data-cmd":"/pause",style:"min-width:4.5em"},preact.h("i",{"class":"fa fa-pause","aria-hidden":true}),preact.h("br",null),TL(["[Pause]"]))," ",!room.battle.hardcoreMode&&preact.h(preact.Fragment,null,preact.h("button",{"class":"button button-first"+(atStart?" disabled":""),"data-cmd":"/ffto 0",style:"margin-right:2px"},preact.h("i",{"class":"fa fa-undo","aria-hidden":true}),preact.h("br",null),TL(["[First turn]"])),preact.h("button",{"class":"button button-first"+(atStart?" disabled":""),"data-cmd":"/ffto -1"},preact.h("i",{"class":"fa fa-step-backward","aria-hidden":true}),preact.h("br",null),TL(["[Prev turn]"])),preact.h("button",{"class":"button button-last"+(atEnd?" disabled":""),"data-cmd":"/ffto +1",style:"margin-right:2px"},preact.h("i",{"class":"fa fa-step-forward","aria-hidden":true}),preact.h("br",null),TL(["[Skip turn]"])),preact.h("button",{"class":"button button-last"+(atEnd?" disabled":""),"data-cmd":"/ffto end"},preact.h("i",{"class":"fa fa-fast-forward","aria-hidden":true}),preact.h("br",null),TL(["[Skip to end]"])))),preact.h("p",null,preact.h("button",{"class":"button","data-cmd":"/switchsides"},preact.h("i",{"class":"fa fa-random","aria-hidden":true})," ",TL(["[Switch viewpoint]"]))," ",!room.battle.hardcoreMode&&preact.h("button",{"class":"button","data-cmd":"/ffto"},preact.h("i",{"class":"fa fa-random","aria-hidden":true})," ",TL(["[Go to turn]"]))));};_proto6.renderMoveButton=function renderMoveButton(props){if(!props){return preact.h("button",{"class":"movebutton",disabled:true},"\xA0");}var pp=props.moveData.maxpp?props.moveData.pp+"/"+props.moveData.maxpp:"\u2014";return preact.h("button",{"data-cmd":props.cmd,"data-tooltip":props.tooltip,"class":"movebutton has-tooltip "+(props.moveData.disabled?'disabled':"type-"+props.type),"aria-disabled":props.moveData.disabled},props.name,preact.h("br",null),preact.h("small",{"class":"type"},props.type," ",preact.h("span",{"class":"effectiveness-icon"},props.tags))," ",preact.h("small",{"class":"pp"},pp),"\xA0");};_proto6.renderPokemonButton=function renderPokemonButton(props){var pokemon=props.pokemon;if(!pokemon){return preact.h("button",{"data-cmd":props.cmd,"class":(props.disabled?'disabled ':'')+"has-tooltip","aria-disabled":props.disabled,style:props.disabled==='fade'?'opacity: 0.5':'',"data-tooltip":props.tooltip},TL(["(empty slot)"]));}var hpColorClass;switch(BattleScene.getHPColor(pokemon)){case'y':hpColorClass='hpbar hpbar-yellow';break;case'r':hpColorClass='hpbar hpbar-red';break;default:hpColorClass='hpbar';break;}return preact.h("button",{"data-cmd":props.cmd,"class":(props.disabled?'disabled ':'')+"has-tooltip","aria-disabled":props.disabled,style:props.disabled==='fade'?'opacity: 0.5':'',"data-tooltip":props.tooltip},PSIcon({pokemon:pokemon}),pokemon.name,!props.noHPBar&&!pokemon.fainted&&preact.h("span",{"class":hpColorClass},preact.h("span",{style:{width:Math.round(pokemon.hp*92/pokemon.maxhp)||1}})),!props.noHPBar&&pokemon.status&&preact.h("span",{"class":"status "+pokemon.status}));};_proto6.renderMoveMenu=function renderMoveMenu(choices,overlayVersion){var moveRequest=choices.currentMoveRequest();var canDynamax=moveRequest.canDynamax&&!choices.alreadyMax;var alreadyMega=choices.alreadyMega&&!this.props.room.battle.format.allowMultipleMegas;var canMegaEvo=moveRequest.canMegaEvo&&!alreadyMega;var canMegaEvoX=moveRequest.canMegaEvoX&&!alreadyMega;var canMegaEvoY=moveRequest.canMegaEvoY&&!alreadyMega;var canZMove=moveRequest.zMoves&&!choices.alreadyZ;var canUltraBurst=moveRequest.canUltraBurst;var canTerastallize=moveRequest.canTerastallize;var maybeDisabled=moveRequest.maybeDisabled;var maybeLocked=moveRequest.maybeLocked;return preact.h("div",{"class":"movemenu"},maybeDisabled&&preact.h("p",null,preact.h("em",{"class":"movewarning"},this.renderUIText('mightBeDisabled'))),maybeLocked&&preact.h("p",null,preact.h("em",{"class":"movewarning"},this.renderUIText('mightBeLocked')," ",preact.h("button",{"class":"button","data-cmd":"/choose testfight"},TL(["[Try Fight button]"]))," ",this.renderUIText('lockedExplanation'))),!overlayVersion&&this.renderMoveControls(moveRequest,choices),preact.h("div",{"class":"megaevo-box"},canDynamax&&preact.h("label",{"class":"megaevo"+(choices.current.max?' cur':'')},preact.h("input",{type:"checkbox",name:"max",checked:choices.current.max,onChange:this.toggleBoostedMove})," ",moveRequest.gigantamax?TL.tag.gigantamax:TL(["Dynamax"])),canMegaEvo&&preact.h("label",{"class":"megaevo"+(choices.current.mega?' cur':'')},preact.h("input",{type:"checkbox",name:"mega",checked:choices.current.mega,onChange:this.toggleBoostedMove})," ",TL(["Mega Evolution"])),canMegaEvoX&&preact.h("label",{"class":"megaevo"+(choices.current.mega?' cur':'')},preact.h("input",{type:"checkbox",name:"megax",checked:choices.current.megax,onChange:this.toggleBoostedMove})," ",TL(["Mega Evolution"])," X"),canMegaEvoY&&preact.h("label",{"class":"megaevo"+(choices.current.mega?' cur':'')},preact.h("input",{type:"checkbox",name:"megay",checked:choices.current.megay,onChange:this.toggleBoostedMove})," ",TL(["Mega Evolution"])," Y"),canUltraBurst&&preact.h("label",{"class":"megaevo"+(choices.current.ultra?' cur':'')},preact.h("input",{type:"checkbox",name:"ultra",checked:choices.current.ultra,onChange:this.toggleBoostedMove})," ",TL(["Ultra Burst"])),canZMove&&preact.h("label",{"class":"megaevo"+(choices.current.z?' cur':'')},preact.h("input",{type:"checkbox",name:"z",checked:choices.current.z,onChange:this.toggleBoostedMove})," ",TL(["Z-Power"])),canTerastallize&&preact.h("label",{"class":"megaevo"+(choices.current.tera?' cur':'')},preact.h("input",{type:"checkbox",name:"tera",checked:choices.current.tera,onChange:this.toggleBoostedMove})," ",TL(["Tera ",""],'{TYPE}').split(/(\{TYPE\})/).map(function(part){return part==='{TYPE}'?PSIcon({type:canTerastallize,"new":true,tera:true}):part;}))),overlayVersion&&this.renderMoveControls(moveRequest,choices));};_proto6.renderMoveControls=function renderMoveControls(active,choices){var _this10=this;var battle=this.props.room.battle;var dex=battle.dex;var pokemonIndex=choices.index();var activeIndex=battle.mySide.n>1?pokemonIndex+battle.pokemonControlled:pokemonIndex;var serverPokemon=choices.request.side.pokemon[pokemonIndex];var valueTracker=new ModifiableValue(battle,battle.nearSide.active[activeIndex],serverPokemon);var tooltips=battle.scene.tooltips;if(choices.current.max||active.maxMoves&&!active.canDynamax){if(!active.maxMoves){return preact.h("div",{"class":"message-error"},TL(["Maxed with no max moves"]));}var gmax=active.gigantamax&&dex.moves.get(active.gigantamax);return active.moves.map(function(moveData,i){var move=dex.moves.get(moveData.name);var _tooltips$getMoveType=tooltips.getMoveTypeText(move,valueTracker,gmax||true),moveType=_tooltips$getMoveType[0],tags=_tooltips$getMoveType[1];var maxMoveData=active.maxMoves[i];if(maxMoveData.name!=='Max Guard'){maxMoveData=tooltips.getMaxMoveFromType(moveType,gmax);}var gmaxTooltip=maxMoveData.id.startsWith('gmax')?"|"+maxMoveData.id:"";var tooltip="maxmove|"+moveData.name+"|"+pokemonIndex+gmaxTooltip;return _this10.renderMoveButton({name:TL(dex.moves.get(maxMoveData.name)),cmd:"/move "+(i+1)+" max",type:moveType,tags:tags,tooltip:tooltip,moveData:Object.assign({},moveData,{disabled:active.maxMoves[i].disabled})});});}if(choices.current.z){if(!active.zMoves){return preact.h("div",{"class":"message-error"},TL(["No Z moves"]));}return active.moves.map(function(moveData,i){var zMoveData=active.zMoves[i];if(!zMoveData){return _this10.renderMoveButton(null);}var specialMove=dex.moves.get(zMoveData.name);var move=specialMove.exists?specialMove:dex.moves.get(moveData.name);var moveName=TL(move);if(zMoveData.name.startsWith('Z-')&&!moveName.startsWith('Z-'))moveName="Z-"+moveName;var _tooltips$getMoveType2=tooltips.getMoveTypeText(move,valueTracker),moveType=_tooltips$getMoveType2[0],tags=_tooltips$getMoveType2[1];var tooltip="zmove|"+moveData.name+"|"+pokemonIndex;return _this10.renderMoveButton({name:moveName,cmd:"/move "+(i+1)+" zmove",type:moveType,tags:tags,tooltip:tooltip,moveData:{pp:1,maxpp:1}});});}var special=choices.moveSpecial(choices.current);return active.moves.map(function(moveData,i){var move=dex.moves.get(moveData.name);var _tooltips$getMoveType3=tooltips.getMoveTypeText(move,valueTracker),moveType=_tooltips$getMoveType3[0],tags=_tooltips$getMoveType3[1];var tooltip="move|"+moveData.name+"|"+pokemonIndex;return _this10.renderMoveButton({name:TL(move),cmd:"/move "+(i+1)+special,type:moveType,tags:tags,tooltip:tooltip,moveData:moveData});});};_proto6.renderMoveTargetControls=function renderMoveTargetControls(request,choices){var _choices$currentMove,_this11=this;var battle=this.props.room.battle;var moveTarget=(_choices$currentMove=choices.currentMove())==null?void 0:_choices$currentMove.target;if((moveTarget==='adjacentAlly'||moveTarget==='adjacentFoe')&&battle.gameType==='freeforall'){moveTarget='normal';}var moveChoice=choices.stringChoice(choices.current);var userSlot=choices.index()+Math.floor(battle.mySide.n/2)*battle.pokemonControlled;var userSlotCross=battle.farSide.active.length-1-userSlot;return preact.h(preact.Fragment,null,battle.farSide.active.map(function(pokemon,i){var _pokemon;var disabled=false;if(moveTarget==='adjacentAlly'||moveTarget==='adjacentAllyOrSelf'){disabled=true;}else if(moveTarget==='normal'||moveTarget==='adjacentFoe'){if(Math.abs(userSlotCross-i)>1)disabled=true;}if((_pokemon=pokemon)!=null&&_pokemon.fainted)pokemon=null;return _this11.renderPokemonButton({pokemon:pokemon,cmd:disabled?"":"/"+moveChoice+" +"+(i+1),disabled:disabled&&'fade',tooltip:"activepokemon|1|"+i});}).reverse(),preact.h("div",{style:{clear:'left'}}),battle.nearSide.active.map(function(pokemon,i){var _pokemon2;var disabled=false;if(moveTarget==='adjacentFoe'){disabled=true;}else if(moveTarget==='normal'||moveTarget==='adjacentAlly'||moveTarget==='adjacentAllyOrSelf'){if(Math.abs(userSlot-i)>1)disabled=true;}if(moveTarget!=='adjacentAllyOrSelf'&&userSlot===i)disabled=true;if((_pokemon2=pokemon)!=null&&_pokemon2.fainted)pokemon=null;return _this11.renderPokemonButton({pokemon:pokemon,cmd:disabled?"":"/"+moveChoice+" -"+(i+1),disabled:disabled&&'fade',tooltip:"activepokemon|0|"+i});}));};_proto6.renderSwitchMenu=function renderSwitchMenu(request,choices,ignoreTrapping){var _choices$currentMoveR,_choices$currentMoveR2,_this12=this,_request$ally;var numActive=choices.requestLength();var maybeTrapped=!ignoreTrapping&&((_choices$currentMoveR=choices.currentMoveRequest())==null?void 0:_choices$currentMoveR.maybeTrapped);var trapped=!ignoreTrapping&&!maybeTrapped&&((_choices$currentMoveR2=choices.currentMoveRequest())==null?void 0:_choices$currentMoveR2.trapped);var isReviving=choices.isReviving();return preact.h("div",{"class":"switchmenu"},maybeTrapped&&preact.h("em",{"class":"movewarning"},this.renderUIText('mightBeTrapped'),preact.h("br",null)),trapped&&preact.h("em",{"class":"movewarning"},this.renderUIText('cantSwitchTrapped'),preact.h("br",null)),request.side.pokemon.map(function(serverPokemon,i){var cantSwitch=trapped||i<numActive||choices.alreadySwitchingIn.includes(i+1)||serverPokemon.fainted;if(isReviving)cantSwitch=!serverPokemon.fainted||choices.alreadySwitchingIn.includes(i+1);return _this12.renderPokemonButton({pokemon:serverPokemon,cmd:"/switch "+(i+1),disabled:cantSwitch,tooltip:"switchpokemon|"+i});}),(_request$ally=request.ally)==null||(_request$ally=_request$ally.pokemon)==null?void 0:_request$ally.map(function(serverPokemon,i){return _this12.renderPokemonButton({pokemon:serverPokemon,cmd:"/switch notMine",disabled:true,tooltip:"allypokemon|"+i});}));};_proto6.renderTeamPreviewChooser=function renderTeamPreviewChooser(request,choices){var _this13=this;return request.side.pokemon.map(function(serverPokemon,i){var cantSwitch=choices.alreadySwitchingIn.includes(i+1);return _this13.renderPokemonButton({pokemon:serverPokemon,cmd:"/switch "+(i+1),disabled:cantSwitch&&'fade',tooltip:"switchpokemon|"+i});});};_proto6.renderTeamList=function renderTeamList(){var _this14=this;var overlayVersion=arguments.length>0&&arguments[0]!==undefined?arguments[0]:false;var team=this.team;if(!team)return;return preact.h("div",{"class":"switchcontrols"},!overlayVersion&&preact.h("h3",{"class":"switchselect"},TL(["[Team]"])),preact.h("div",{"class":"switchmenu"},team.map(function(serverPokemon,i){return _this14.renderPokemonButton({pokemon:serverPokemon,cmd:"",disabled:true,tooltip:"switchpokemon|"+i});})));};_proto6.renderChosenTeam=function renderChosenTeam(request,choices){var _this15=this;return choices.alreadySwitchingIn.map(function(slot){var serverPokemon=request.side.pokemon[slot-1];return _this15.renderPokemonButton({pokemon:serverPokemon,cmd:"/switch "+slot,tooltip:"switchpokemon|"+(slot-1)});});};_proto6.renderOldChoices=function renderOldChoices(request,choices){var overlayVersion=arguments.length>2&&arguments[2]!==undefined?arguments[2]:false;if(!choices)return null;if(request.requestType!=='move'&&request.requestType!=='switch'&&request.requestType!=='team'||choices.isEmpty()){return null;}var buf=[preact.h("button",{"data-cmd":"/cancelone","class":"button"},preact.h("i",{"class":"fa fa-chevron-left","aria-hidden":true})," ",TL(["[Back]"])),' '];if(choices.isDone()&&(choices.noCancel||this.props.room.battle.hardcoreMode||choices.choices.length<=1&&!overlayVersion)){buf=[];}if(choices.serializedChoice){if(choices.serializedChoice==='default'){return[BattleTextParser.ui('autoChoice'),preact.h("br",null)];}return[BattleTextParser.ui('unrecognizedChoice')+' ',preact.h("code",null,choices.serializedChoice),preact.h("br",null)];}var battle=this.props.room.battle;var pickedNames=[];for(var i=0;i<choices.choices.length;i++){var choiceString=choices.choices[i];if(choiceString==="testfight"){buf.push(this.renderUIText('lockedIntoMove',{POKEMON:request.side.pokemon[i].name}));return buf;}var choice=void 0;try{choice=choices.parseChoice(choiceString,i);}catch(err){buf.push(preact.h("span",{"class":"message-error"},err.message));}if(!choice)continue;var pokemon=request.side.pokemon[i];var active=request.requestType==='move'?request.active[i]:null;if(choice.choiceType==='move'){var _choices$currentMove2;var actions='';if(choice.mega)actions+=BattleTextParser.ui('actionMegaEvolve');if(choice.megax)actions+=BattleTextParser.ui('actionMegaEvolveX');if(choice.megay)actions+=BattleTextParser.ui('actionMegaEvolveY');if(choice.ultra)actions+=BattleTextParser.ui('actionUltraBurst');if(choice.tera)actions+=BattleTextParser.ui('actionTerastallize',{TYPE:(active==null?void 0:active.canTerastallize)||'???'});if(choice.max&&active!=null&&active.canDynamax){actions+=BattleTextParser.ui(active!=null&&active.gigantamax?'actionGigantamax':'actionDynamax');}var target='';if(choice.targetLoc>0){var targetPokemon=battle.farSide.active[choice.targetLoc-1];target=targetPokemon?BattleTextParser.ui('atTarget',{TARGET:targetPokemon.name}):BattleTextParser.ui('atSlot',{NUMBER:""+choice.targetLoc});}else if(choice.targetLoc<0){var _targetPokemon=battle.nearSide.active[-choice.targetLoc-1];var isAlly=battle.gameType!=='freeforall';if(_targetPokemon){target=BattleTextParser.ui(isAlly?'atAllyTarget':'atTarget',{TARGET:_targetPokemon.name});}else{target=BattleTextParser.ui(isAlly?'atAllySlot':'atSlot',{NUMBER:""+choice.targetLoc});}}buf.push(this.renderUIText('willUseMove',{POKEMON:pokemon.name,ACTIONS:actions,MOVE:((_choices$currentMove2=choices.currentMove(choice,i))==null?void 0:_choices$currentMove2.name)||'???',AT:target}));}else if(choice.choiceType==='switch'){var _target=request.side.pokemon[choice.targetPokemon-1];buf.push(this.renderUIText(choices.isReviving(i)?'willRevive':'willSwitch',{POKEMON:pokemon.name,TARGET:_target.name}));}else if(choice.choiceType==='shift'){buf.push(this.renderUIText('willShift',{POKEMON:pokemon.name}));}else if(choice.choiceType==='team'){var _target2=request.side.pokemon[choice.targetPokemon-1];pickedNames.push(_target2.name);}if(!pickedNames.length)buf.push(preact.h("br",null));}if(pickedNames.length){var pickedList=pickedNames.map(function(name){return"**"+name+"**";}).join(BattleTextParser.ui('listComma'));buf.push(this.renderUIText('youPicked',{POKEMON:pickedList}),preact.h("br",null));}return buf;};_proto6.overlayControlClass=function overlayControlClass(overlay){return"button "+overlay+"-button"+(this.props.room.overlayActive===overlay?' cur':'');};_proto6.renderPlayerAnimationControls=function renderPlayerAnimationControls(){var overlayVersion=arguments.length>0&&arguments[0]!==undefined?arguments[0]:false;var room=this.props.room;if(overlayVersion){var canSkip=!room.battle.hardcoreMode;return preact.h(preact.Fragment,null,canSkip&&preact.h("div",{"class":"overlay-controls-skip"},preact.h("button",{"class":"button","data-cmd":"/ffto end"},preact.h("i",{"class":"fa fa-fast-forward","aria-hidden":true}),preact.h("br",null),TL(["[Skip]"]))));}return preact.h("div",{"class":"inline-controls"},!room.battle.hardcoreMode&&preact.h("div",{"class":"whatdo",style:"padding-bottom:0"},preact.h("button",{"class":"button","data-cmd":"/ffto end"},preact.h("i",{"class":"fa fa-fast-forward","aria-hidden":true}),preact.h("br",null),TL(["[Skip animation]"]))),this.renderTeamList());};_proto6.renderPlayerMoveControls=function renderPlayerMoveControls(request,choices){var overlayVersion=arguments.length>2&&arguments[2]!==undefined?arguments[2]:false;var room=this.props.room;var index=choices.index();var pokemon=request.side.pokemon[index];if(choices.current.move){var _choices$currentMove3;var moveName=(_choices$currentMove3=choices.currentMove())==null?void 0:_choices$currentMove3.name;if(overlayVersion){return preact.h(preact.Fragment,null,preact.h("div",{"class":"overlay-controls-list"},preact.h("button",{"class":"button move-button cur"},preact.h("strong",null,TL(["[Battle]"])))," ",preact.h("button",{"class":"button switch-button disabled"},preact.h("strong",null,TL(["[Switch]"])))),preact.h("div",{"class":"targetcontrols"},preact.h("p",{"class":"overlay-message"},this.renderOldChoices(request,choices,true),this.renderUIText('moveTarget',{POKEMON:pokemon.name,MOVE:moveName})),preact.h("div",{"class":"switchmenu"},this.renderMoveTargetControls(request,choices))));}return preact.h("div",{"class":"inline-controls"},preact.h("div",{"class":"whatdo"},this.renderOldChoices(request,choices),this.renderUIText('moveTarget',{POKEMON:pokemon.name,MOVE:moveName})," "),preact.h("div",{"class":"switchcontrols"},preact.h("div",{"class":"switchmenu"},this.renderMoveTargetControls(request,choices))));}var canShift=room.battle.gameType==='triples'&&index!==1;if(overlayVersion){return preact.h(preact.Fragment,null,preact.h("div",{"class":"overlay-controls-list"},preact.h("button",{"class":this.overlayControlClass('move'),"data-cmd":"/movemenu"},preact.h("strong",null,TL(["[Battle]"])))," ",preact.h("button",{"class":this.overlayControlClass('switch'),"data-cmd":"/switchmenu"},preact.h("strong",null,TL(["[Switch]"])))),!room.overlayActive&&preact.h("div",{"class":"whatdo"},this.renderOldChoices(request,choices,true),this.renderUIText('whatDo',{POKEMON:pokemon.name})),room.overlayActive==='move'&&preact.h("div",{"class":"movecontrols"},this.renderMoveMenu(choices,true)),room.overlayActive==='switch'&&preact.h("div",{"class":"switchcontrols"},canShift&&preact.h("button",{"data-cmd":"/shift"},TL(["[Move to center]"])),this.renderSwitchMenu(request,choices)));}return preact.h("div",{"class":"inline-controls"},preact.h("div",{"class":"whatdo"},this.renderOldChoices(request,choices),this.renderUIText('whatDo',{POKEMON:pokemon.name})),preact.h("div",{"class":"movecontrols"},preact.h("h3",{"class":"moveselect"},TL(["[Battle]"])),this.renderMoveMenu(choices)),preact.h("div",{"class":"switchcontrols"},canShift&&[preact.h("h3",{"class":"shiftselect"},TL(["[Shift]"])),preact.h("button",{"data-cmd":"/shift"},TL(["[Move to center]"]))],preact.h("h3",{"class":"switchselect"},TL(["[Switch]"])),this.renderSwitchMenu(request,choices)));};_proto6.renderPlayerSwitchControls=function renderPlayerSwitchControls(request,choices){var overlayVersion=arguments.length>2&&arguments[2]!==undefined?arguments[2]:false;var pokemon=request.side.pokemon[choices.index()];var prompt=choices.isReviving()?this.renderUIText('reviveWho',{POKEMON:pokemon.name}):this.renderUIText('replaceWho',{POKEMON:pokemon.name});if(overlayVersion){return preact.h(preact.Fragment,null,preact.h("div",{"class":"overlay-controls-list"},preact.h("button",{"class":"button switch-button cur"},preact.h("strong",null,TL(["[Switch]"])))),preact.h("div",{"class":"switchcontrols"},preact.h("p",{"class":"overlay-message"},this.renderOldChoices(request,choices,true),prompt),this.renderSwitchMenu(request,choices,true)));}return preact.h("div",{"class":"inline-controls"},preact.h("div",{"class":"whatdo"},this.renderOldChoices(request,choices),prompt),preact.h("div",{"class":"switchcontrols"},preact.h("h3",{"class":"switchselect"},TL(["[Switch]"])),this.renderSwitchMenu(request,choices,true)));};_proto6.renderPlayerTeamPreviewControls=function renderPlayerTeamPreviewControls(request,choices){var overlayVersion=arguments.length>2&&arguments[2]!==undefined?arguments[2]:false;var prompt=choices.alreadySwitchingIn.length>0?[preact.h("button",{"data-cmd":"/cancelone","class":"button"},preact.h("i",{"class":"fa fa-chevron-left","aria-hidden":true})," ",TL(["[Back]"]))," ",this.renderUIText('teamRest')," "]:[this.renderUIText('teamStart')," "];var chosenTeamSizeLabel=(request.chosenTeamSize||0)>1?" / "+request.chosenTeamSize:'';var chooseLabel=(choices.alreadySwitchingIn.length<=0?BattleTextParser.ui('chooseLead'):BattleTextParser.ui('chooseSlot',{NUMBER:""+(choices.alreadySwitchingIn.length+1)}))+chosenTeamSizeLabel;if(overlayVersion){return preact.h(preact.Fragment,null,preact.h("div",{"class":"overlay-controls-list"},preact.h("button",{"class":"button switch-button cur"},preact.h("strong",null,TL(["[Team]"])))),preact.h("div",{"class":"teamcontrols"},preact.h("p",{"class":"overlay-message"},prompt),preact.h("h3",{"class":"switchselect"},chooseLabel),preact.h("div",{"class":"switchmenu"},this.renderTeamPreviewChooser(request,choices),preact.h("div",{style:"clear:left"})),choices.alreadySwitchingIn.length>0&&preact.h(preact.Fragment,null,preact.h("h3",{"class":"switchselect"},this.renderUIText('teamSoFar')),preact.h("div",{"class":"switchmenu"},this.renderChosenTeam(request,choices)))));}return preact.h("div",{"class":"inline-controls"},preact.h("div",{"class":"whatdo"},prompt),preact.h("div",{"class":"switchcontrols"},preact.h("h3",{"class":"switchselect"},chooseLabel),preact.h("div",{"class":"switchmenu"},this.renderTeamPreviewChooser(request,choices),preact.h("div",{style:"clear:left"}))),preact.h("div",{"class":"switchcontrols"},choices.alreadySwitchingIn.length>0&&preact.h("h3",{"class":"switchselect"},this.renderUIText('teamSoFar')),preact.h("div",{"class":"switchmenu"},this.renderChosenTeam(request,choices))));};_proto6.renderPlayerControls=function renderPlayerControls(request){var overlayVersion=arguments.length>1&&arguments[1]!==undefined?arguments[1]:false;var room=this.props.room;var atEnd=room.battle.atQueueEnd;if(!atEnd)return this.renderPlayerAnimationControls(overlayVersion);var choices=room.choices;if(!choices)return'Error: Missing BattleChoiceBuilder';if(choices.request!==request){choices=new BattleChoiceBuilder(request);room.choices=choices;room.overlayActive=null;}if(choices.isDone()){if(overlayVersion){return preact.h(preact.Fragment,null,preact.h("div",{"class":"overlay-controls-list"},preact.h("button",{"class":this.overlayControlClass('switch'),"data-cmd":"/switchmenu"},preact.h("strong",null,TL(["[Team]"])))),!room.overlayActive&&preact.h("div",{"class":"whatdo"},this.renderOldChoices(request,choices,true)),room.overlayActive==='switch'&&this.renderTeamList(true));}return preact.h("div",{"class":"inline-controls"},preact.h("div",{"class":"whatdo"},this.renderOldChoices(request,choices),preact.h("em",null,this.renderUIText('waitingOpponent'))," ",choices.noCancel||room.battle.hardcoreMode?null:preact.h("button",{"data-cmd":"/cancel","class":"button"},TL(["[Cancel]"]))),this.renderTeamList());}if(request.side){room.battle.myPokemon=request.side.pokemon;this.team=request.side.pokemon;}switch(request.requestType){case'move':return this.renderPlayerMoveControls(request,choices,overlayVersion);case'switch':return this.renderPlayerSwitchControls(request,choices,overlayVersion);case'team':return this.renderPlayerTeamPreviewControls(request,choices,overlayVersion);}return null;};_proto6.renderAfterBattleControls=function renderAfterBattleControls(){var room=this.props.room;var isNotTiny=room.width>700;return preact.h("div",{"class":"inline-controls"},preact.h("p",null,preact.h("span",{style:"float: right"},preact.h("a",{onClick:this.handleDownloadReplay,href:"//"+Config.routes.replays+"/download","class":"button replayDownloadButton"},preact.h("i",{"class":"fa fa-download","aria-hidden":true})," Download replay"),preact.h("br",null),preact.h("br",null),preact.h("button",{"class":"button","data-cmd":"/savereplay"},preact.h("i",{"class":"fa fa-upload","aria-hidden":true})," ",TL(["[Upload and share replay]"]))),preact.h("button",{"class":"button","data-cmd":"/play",style:"min-width:4.5em"},preact.h("i",{"class":"fa fa-undo","aria-hidden":true}),preact.h("br",null),TL(["[Replay]"]))," ",isNotTiny&&!room.battle.hardcoreMode&&preact.h(preact.Fragment,null,preact.h("button",{"class":"button button-first","data-cmd":"/ffto 0",style:"margin-right:2px"},preact.h("i",{"class":"fa fa-undo","aria-hidden":true}),preact.h("br",null),TL(["[First turn]"])),preact.h("button",{"class":"button button-first","data-cmd":"/ffto -1"},preact.h("i",{"class":"fa fa-step-backward","aria-hidden":true}),preact.h("br",null),TL(["[Prev turn]"])))),room.side?preact.h("p",null,preact.h("button",{"class":"button","data-cmd":"/close"},preact.h("strong",null,TL(["[Main menu]"])),preact.h("br",null),preact.h("small",null,TL(["(closes this battle)"])))," ",preact.h("button",{"class":"button","data-cmd":"/closeand /challenge "+room.battle.farSide.id+","+room.battle.tier},preact.h("strong",null,TL(["[Rematch]"])),preact.h("br",null),preact.h("small",null,TL(["(closes this battle)"])))):preact.h("p",null,preact.h("button",{"class":"button","data-cmd":"/switchsides"},preact.h("i",{"class":"fa fa-random","aria-hidden":true})," ",TL(["[Switch viewpoint]"]))," ",!room.battle.hardcoreMode&&preact.h("button",{"class":"button","data-cmd":"/ffto"},preact.h("i",{"class":"fa fa-random","aria-hidden":true})," ",TL(["[Go to turn]"]))));};_proto6.

render=function render(){var _room$battle3;
this.updateLayout();
var room=this.props.room;
var id="room-"+room.id;
var hardcoreStyle=(_room$battle3=room.battle)!=null&&_room$battle3.hardcoreMode?preact.h("style",{
dangerouslySetInnerHTML:{__html:"#"+id+" .battle .turn, #"+id+" .battle-history { display: none !important; }"}}
):null;
var _this$chooseLayout2=this.chooseLayout(),layout=_this$chooseLayout2.layout,battleHeight=_this$chooseLayout2.battleHeight,battleWidth=_this$chooseLayout2.battleWidth,overlayControls=_this$chooseLayout2.overlayControls;
var overlayVersion=overlayControls&&!!room.battle&&!!room.side&&!!room.request&&!room.battle.ended;

if(layout==='scrolling'){


return preact.h(PSPanelWrapper,{room:room,focusClick:true,noScroll:"hidden"},
hardcoreStyle,
preact.h(ChatLog,{
"class":"battle-log hasuserlist",room:room,noSubscription:true,hasPreempt:true,bottom:0},

preact.h("div",{style:"height:18px;position:relative"},
preact.h(ChatUserList,{room:room,top:0,minimized:true})
),
preact.h(ChatTextEntry,{room:room,onMessage:this.send,onKey:this.onKey,left:0,tinyLayout:room.width<400}),
preact.h("div",{style:"height:"+battleHeight+"px;width:"+battleWidth+"px;margin: 0 auto;position:relative"},
preact.h(BattleDiv,{room:room})
),
overlayVersion&&preact.h("div",{"class":"overlay-controls",style:"position:relative;height:0"},
this.renderControls(true)
),
preact.h("div",{
"class":"battle-controls inline-battle"+(room.width>660?' wide-controls':''),
role:"complementary","aria-label":TL(["Battle controls"])},

this.renderControls(false,overlayVersion),
this.renderConnectError()
)
),
room.battle&&!room.battle.ended&&room.request&&room.battle.mySide.id===PS.user.userid&&
preact.h(TimerButton,{room:room,top:7}),
preact.h("div",{"class":"battle-controls-container"})
);
}

if(layout==='top-and-bottom'){

return preact.h(PSPanelWrapper,{room:room,focusClick:true,noScroll:"hidden"},
hardcoreStyle,
preact.h("div",{style:"position:relative;height:"+battleHeight+"px;width:"+battleWidth+"px;margin:0 auto"},
preact.h(BattleDiv,{room:room})
),
overlayVersion&&preact.h("div",{
"class":"overlay-controls",
style:"position:absolute;left:0;top:"+battleHeight+"px;width:100%;height:0"},

this.renderControls(true)
),
preact.h(ChatLog,{
"class":"battle-log hasuserlist",room:room,top:battleHeight,noSubscription:true,hasPreempt:true},

preact.h("div",{
"class":"battle-controls"+(room.width>660?' wide-controls':''),
role:"complementary","aria-label":TL(["Battle controls"])},

this.renderControls(false,overlayVersion),
this.renderConnectError()
)
),
preact.h(ChatTextEntry,{room:room,onMessage:this.send,onKey:this.onKey,left:0,tinyLayout:room.width<400}),
preact.h(ChatUserList,{room:room,top:battleHeight,minimized:true}),
room.battle&&!room.battle.ended&&room.request&&room.battle.mySide.id===PS.user.userid&&
preact.h(TimerButton,{room:room,top:battleHeight+7}),
preact.h("div",{"class":"battle-controls-container"})
);
}

if(room.width<500){

var showingChat=this.mobileChatShown;
return preact.h(PSPanelWrapper,{room:room,focusClick:true,noScroll:"hidden"},
hardcoreStyle,
preact.h("div",{"class":"scrollable-battle-container",style:"width:"+battleWidth+"px;"+(showingChat?'display:none;':'')},
preact.h(BattleDiv,{room:room}),
overlayVersion&&preact.h("div",{
"class":"overlay-controls",
style:"position:absolute;left:0;top:"+battleHeight+"px;width:"+battleWidth+"px;height:0"},

this.renderControls(true)
),
preact.h("div",{"class":"battle-controls-container"},
preact.h("div",{
"class":"battle-controls"+(battleWidth>=639?' wide-controls':''),
role:"complementary","aria-label":TL(["Battle controls"]),
style:"top:"+(battleHeight+10)+"px;width:"+battleWidth+"px;"},

room.battle&&!room.battle.ended&&room.request&&
room.battle.mySide.id===PS.user.userid&&preact.h(TimerButton,{room:room,top:0}),
this.renderControls(false,overlayVersion),
this.renderConnectError()
)
)
),
preact.h("div",{style:!showingChat?'display:none;':''},
preact.h(ChatLog,{"class":"battle-log hasuserlist",room:room,noSubscription:true,hasPreempt:true}),
preact.h(ChatTextEntry,{room:room,onMessage:this.send,onKey:this.onKey,tinyLayout:true}),
preact.h(ChatUserList,{room:room,minimized:true})
),
showingChat?
preact.h("button",{"class":"battle-chat-toggle button",name:"hideChat",onClick:this.showMobileBattle},
TL(["Battle"])," ",preact.h("i",{"class":"fa fa-caret-right","aria-hidden":true})
):

preact.h("button",{"class":"battle-chat-toggle button",name:"showChat",onClick:this.showMobileChat},
preact.h("i",{"class":"fa fa-caret-left","aria-hidden":true})," ",TL(["Chat"])
)

);
}


return preact.h(PSPanelWrapper,{room:room,focusClick:true,noScroll:"hidden"},
hardcoreStyle,
preact.h("div",{"class":"scrollable-battle-container",style:"width:"+battleWidth+"px"},
preact.h(BattleDiv,{room:room}),
overlayVersion&&preact.h("div",{
"class":"overlay-controls",
style:"position:absolute;left:0;top:"+battleHeight+"px;width:"+battleWidth+"px;height:0"},

this.renderControls(true)
),
preact.h("div",{"class":"battle-controls-container"},
preact.h("div",{
"class":"battle-controls"+(battleWidth>=639?' wide-controls':''),
role:"complementary","aria-label":TL(["Battle controls"]),
style:"top:"+(battleHeight+10)+"px;width:"+battleWidth+"px;"},

room.battle&&!room.battle.ended&&room.request&&room.battle.mySide.id===PS.user.userid&&
preact.h(TimerButton,{room:room,top:0}),
this.renderControls(false,overlayVersion),
this.renderConnectError()
)
)
),
preact.h(ChatLog,{
"class":"battle-log hasuserlist",room:room,left:battleWidth,noSubscription:true,hasPreempt:true}


),
preact.h(ChatTextEntry,{
room:room,onMessage:this.send,onKey:this.onKey,left:battleWidth,tinyLayout:room.width<battleWidth+340}
),
preact.h(ChatUserList,{room:room,left:battleWidth,minimized:true})
);
};return BattlePanel;}(PSRoomPanel);BattlePanel.id='battle';BattlePanel.routes=['battle-*','game-*'];BattlePanel.Model=BattleRoom;


PS.addRoomType(BattlePanel,BattlesPanel);
//# sourceMappingURL=panel-battle.js.map