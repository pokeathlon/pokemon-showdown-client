"use strict";function _inheritsLoose(t,o){t.prototype=Object.create(o.prototype),t.prototype.constructor=t,_setPrototypeOf(t,o);}function _setPrototypeOf(t,e){return _setPrototypeOf=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(t,e){return t.__proto__=e,t;},_setPrototypeOf(t,e);}/**
 * Main menu panel
 *
 * @author Guangcong Luo <guangcongluo@gmail.com>
 * @license AGPLv3
 */var






















MainMenuRoom=function(_PSRoom){function MainMenuRoom(){var _this;for(var _len=arguments.length,args=new Array(_len),_key=0;_key<_len;_key++){args[_key]=arguments[_key];}_this=_PSRoom.call.apply(_PSRoom,[this].concat(args))||this;_this.
classType='mainmenu';_this.
listeners={};_this.
userdetailsCache=









{};_this.
roomsCache=




{};_this.
searchCountdown=

null;_this.

teamSent=null;_this.
search={searching:[],games:null};_this.
disallowSpectators=PS.prefs.disallowspectators;_this.
lastChallenged=null;_this.





startSearch=function(format,team,parentElem){
PS.requestNotifications();
if(_this.searchCountdown){
PS.alert(TL(["Wait for this countdown to finish first..."]),{parentElem:parentElem});
return;
}else if(_this.search.searching.includes(format)){
PS.alert(TL(["You're already searching for a "," battle..."],BattleLog.formatName(format)),{parentElem:parentElem});
return;
}
_this.searchCountdown={
format:format,
packedTeam:(team==null?void 0:team.packedTeam)||'',
countdown:3,
timer:setInterval(_this.doSearchCountdown,1000)
};
_this.update(null);
};_this.




cancelSearch=function(){var _this$search$searchin;
if(_this.searchCountdown){
clearTimeout(_this.searchCountdown.timer);
_this.searchCountdown=null;
_this.update(null);
return true;
}
if(_this.teamSent||(_this$search$searchin=_this.search.searching)!=null&&_this$search$searchin.length){
_this.teamSent=null;
PS.send("/cancelsearch");
_this.update(null);
return true;
}
return false;
};_this.
doSearchCountdown=function(){
if(!_this.searchCountdown)return;

_this.searchCountdown.countdown--;
if(_this.searchCountdown.countdown<=0){
_this.doSearch(_this.searchCountdown);
clearTimeout(_this.searchCountdown.timer);
_this.searchCountdown=null;
}
_this.update(null);
};_this.
doSearch=function(search){
_this.teamSent=search.format;
var privacy=_this.adjustPrivacy();
PS.send("/utm "+search.packedTeam);
PS.send(privacy+"/search "+search.format);
};return _this;}_inheritsLoose(MainMenuRoom,_PSRoom);var _proto=MainMenuRoom.prototype;_proto.adjustPrivacy=function adjustPrivacy(){PS.prefs.set('disallowspectators',this.disallowSpectators);if(this.disallowSpectators)return'/noreply /hidenext \n';return'';};_proto.searchingFormat=function searchingFormat(){var _this$searchCountdown,_this$search$searchin2;return((_this$searchCountdown=this.searchCountdown)==null?void 0:_this$searchCountdown.format)||this.teamSent||((_this$search$searchin2=this.search.searching)==null?void 0:_this$search$searchin2[this.search.searching.length-1])||null;};_proto.
handleLine=function handleLine(args){
if(_PSRoom.prototype.handleLine.call(this,args))return true;
var cmd=args[0];
switch(cmd){
case'challstr':{
var challstr=args[1];
PS.user.challstr=challstr;
PSLoginServer.query(
'upkeep',{challstr:challstr}
).then(function(res){
if(!(res!=null&&res.username)){
PS.user.initializing=false;
return;
}

res.username=res.username.replace(/[|,;]+/g,'');
if(res.loggedin){
PS.user.registered={name:res.username,userid:toID(res.username)};
}
PS.user.handleAssertion(res.username,res.assertion);
});
return true;
}case'updateuser':{
var fullName=args[1],namedCode=args[2],avatar=args[3],settingsJSON=args[4];
var named=namedCode==='1';
if(named)PS.user.initializing=false;
if(settingsJSON){
var serverSettings=JSON.parse(settingsJSON);

delete serverSettings.language;
PS.prefs.set('serversettings',Object.assign({},PS.prefs.serversettings,serverSettings));
}
void Dex.loadTextData().then(function(){return PS.updateTranslatedText();});
PS.user.setName(fullName,named,avatar);
PS.teams.loadRemoteTeams();
return true;
}case'updatechallenges':{
var challengesBuf=args[1];
this.receiveChallenges(challengesBuf);
return true;
}case'updatesearch':{
var searchBuf=args[1];
this.receiveSearch(searchBuf);
return true;
}case'queryresponse':{
var queryId=args[1],responseJSON=args[2];
this.handleQueryResponse(queryId,JSON.parse(responseJSON));
return true;
}case'pm':{
var user1=args[1],user2=args[2],message=args[3];
this.handlePM(user1,user2,message);
var sideRoom=PS.rightPanel;
if((sideRoom==null?void 0:sideRoom.type)==="chat"&&PS.prefs.inchatpm){var _sideRoom$log;
(_sideRoom$log=sideRoom.log)==null||_sideRoom$log.add(args,undefined,undefined,PS.prefs.timestamps.chatrooms);
}
return true;
}case'customgroups':{
var groupsList=args[1];
PS.server.parseGroups(groupsList);
return true;
}case'formats':{
this.parseFormats(args);
return true;
}case'popup':{
var _message=args[1];
for(var roomid in PS.rooms){
var room=PS.rooms[roomid];
if(room.teamSent){
room.teamSent=null;
room.update(null);
}
if(room.type==='team')room.cancelUpload();
}
var width;
if(_message.startsWith('|wide|')){
_message=_message.slice(6);
width=960;
}
PS.alert(_message.replace(/\|\|/g,'\n'),{width:width});
return true;
}
}
var lobby=PS.rooms['lobby'];
if(lobby)lobby.receiveBatch([args]);
return true;
};_proto.
receiveChallenges=function receiveChallenges(dataBuf){
var json;
try{
json=JSON.parse(dataBuf);
}catch(_unused){}
for(var userid in json.challengesFrom){
PS.getPMRoom(toID(userid));
}
if(json.challengeTo){
PS.getPMRoom(toID(json.challengeTo.to));
}
for(var roomid in PS.rooms){var _json$challengeTo,_json$challengeTo2;
var room=PS.rooms[roomid];
if(!room.pmTarget)continue;
var targetUserid=toID(room.pmTarget);
if(!room.challenged&&!(targetUserid in json.challengesFrom)&&
!room.challenging&&((_json$challengeTo=json.challengeTo)==null?void 0:_json$challengeTo.to)!==targetUserid){
continue;
}
room.challenged=room.parseChallenge(json.challengesFrom[targetUserid]);
room.challenging=((_json$challengeTo2=json.challengeTo)==null?void 0:_json$challengeTo2.to)===targetUserid?room.parseChallenge(json.challengeTo.format):null;
room.update(null);
}
};_proto.
receiveSearch=function receiveSearch(dataBuf){
var json;
this.teamSent=null;
try{
json=JSON.parse(dataBuf);
}catch(_unused2){}
this.search=json;
this.update(null);
};_proto.
parseFormats=function parseFormats(formatsList){
var isSection=false;
var section='';

var column=0;

window.NonBattleGames={rps:'Rock Paper Scissors'};
for(var i=3;i<=9;i+=2){
window.NonBattleGames["bestof"+i]="Best-of-"+i;
}
window.BattleFormats={};
for(var j=1;j<formatsList.length;j++){
var entry=formatsList[j];
if(isSection){
section=entry;
isSection=false;
}else if(entry===',LL'){
PS.teams.usesLocalLadder=true;
}else if(entry===''||entry.startsWith(',')&&!isNaN(Number(entry.slice(1)))){
isSection=true;

if(entry){
column=parseInt(entry.slice(1),10)||0;
}
}else{var _BattleFormats$id;
var name=entry;
var searchShow=true;
var challengeShow=true;
var tournamentShow=true;
var partner=false;
var bestOfDefault=false;
var teraPreviewDefault=false;
var itemClauseDefault=false;
var team=null;
var teambuilderLevel=null;
var lastCommaIndex=name.lastIndexOf(',');
var code=lastCommaIndex>=0?parseInt(name.substr(lastCommaIndex+1),16):NaN;
if(!isNaN(code)){
name=name.substr(0,lastCommaIndex);
if(code&1)team='preset';
if(!(code&2))searchShow=false;
if(!(code&4))challengeShow=false;
if(!(code&8))tournamentShow=false;
if(code&16)teambuilderLevel=50;
if(code&32)partner=true;
if(code&64)bestOfDefault=true;
if(code&128)teraPreviewDefault=true;
if(code&256)itemClauseDefault=true;
}else{

if(name.substr(name.length-2)===',#'){
team='preset';
name=name.substr(0,name.length-2);
}
if(name.substr(name.length-2)===',,'){
challengeShow=false;
name=name.substr(0,name.length-2);
}else if(name.substr(name.length-1)===','){
searchShow=false;
name=name.substr(0,name.length-1);
}
}
var id=toID(name);
var isTeambuilderFormat=!team&&!name.endsWith('Custom Game');
var teambuilderFormat='';
var teambuilderFormatName='';
if(isTeambuilderFormat){
teambuilderFormatName=name;
if(!id.startsWith('gen')){
teambuilderFormatName='[Gen 6] '+name;
}
var parenPos=teambuilderFormatName.indexOf('(');
if(parenPos>0&&name.endsWith(')')){

teambuilderFormatName=teambuilderFormatName.slice(0,parenPos).trim();
}
if(teambuilderFormatName!==name){
teambuilderFormat=toID(teambuilderFormatName);
if(BattleFormats[teambuilderFormat]){
BattleFormats[teambuilderFormat].isTeambuilderFormat=true;
}else{
BattleFormats[teambuilderFormat]={
id:teambuilderFormat,
name:teambuilderFormatName,
team:team,
section:section,
column:column,
rated:false,
isTeambuilderFormat:true,
effectType:'Format'
};
}
isTeambuilderFormat=false;
}
}
if((_BattleFormats$id=BattleFormats[id])!=null&&_BattleFormats$id.isTeambuilderFormat){
isTeambuilderFormat=true;
}

if(BattleFormats[id])delete BattleFormats[id];
BattleFormats[id]={
id:id,
name:name,
team:team,
section:section,
column:column,
searchShow:searchShow,
challengeShow:challengeShow,
tournamentShow:tournamentShow,
bestOfDefault:bestOfDefault,
teraPreviewDefault:teraPreviewDefault,
itemClauseDefault:itemClauseDefault,
rated:searchShow&&id.substr(4,7)!=='unrated',
teambuilderLevel:teambuilderLevel,
partner:partner,
teambuilderFormat:teambuilderFormat,
isTeambuilderFormat:isTeambuilderFormat,
effectType:'Format'
};
}
}


var multivariantFormats={};
for(var _id in BattleFormats){
var _teambuilderFormat=BattleFormats[BattleFormats[_id].teambuilderFormat];
if(!_teambuilderFormat||multivariantFormats[_teambuilderFormat.id])continue;
if(!_teambuilderFormat.searchShow&&!_teambuilderFormat.challengeShow&&!_teambuilderFormat.tournamentShow){

if(_teambuilderFormat.battleFormat){
multivariantFormats[_teambuilderFormat.id]=1;
_teambuilderFormat.battleFormat='';
}else{
_teambuilderFormat.battleFormat=_id;
}
}
}
window.BattleFormats=Dex.formats.load(BattleFormats);
PS.teams.update('format');
};_proto.
handlePM=function handlePM(user1,user2,message){
var userid1=toID(user1);
var userid2=toID(user2);
var pmTarget=PS.user.userid===userid1?user2:user1;
var pmTargetid=PS.user.userid===userid1?userid2:userid1;
var roomid="dm-"+pmTargetid;
if(pmTargetid===PS.user.userid)roomid='dm-';
var room=PS.rooms[roomid];
if(!room){
PS.addRoom({
id:roomid,
args:{pmTarget:pmTarget},
autofocus:false
});
room=PS.rooms[roomid];
}else{
room.updateTarget(pmTarget);
}
if(message)room.receiveBatch([["c",user1,message]]);
PS.update();
};_proto.






makeQuery=function makeQuery(id,param,excludeParamFromListener){var _this2=this;
var fullid=id;
if(param&&!excludeParamFromListener)fullid+=" "+toID(param);
return new Promise(function(resolve){
if(!_this2.listeners[fullid]){
_this2.listeners[fullid]=[];
PS.send("/cmd "+id+" "+(param||''));
}
_this2.listeners[fullid].push(resolve);
});
};_proto.
handleQueryResponse=function handleQueryResponse(id,response){var _PS$rooms,_PS$rooms2,_PS$rooms3;
var fullid=id;
switch(id){
case'userdetails':
var userid=response.userid;
fullid+=" "+userid;
var userdetails=this.userdetailsCache[userid];
if(!userdetails){
this.userdetailsCache[userid]=response;
}else{
response.status||(response.status='');
Object.assign(userdetails,response);
}
if(userid===PS.user.userid){
if(response.avatar!==undefined&&PS.user.avatar!==""+response.avatar){
PS.user.avatar=""+response.avatar;
PS.user.update(null);
}
}
(_PS$rooms=PS.rooms["user-"+userid])==null||_PS$rooms.update(null);
(_PS$rooms2=PS.rooms["viewuser-"+userid])==null||_PS$rooms2.update(null);
(_PS$rooms3=PS.rooms["users"])==null||_PS$rooms3.update(null);
break;
case'rooms':
if(response.pspl){for(var _i2=0,_response$pspl2=
response.pspl;_i2<_response$pspl2.length;_i2++){var roomInfo=_response$pspl2[_i2];roomInfo.spotlight="Spotlight";}
response.chat=[].concat(response.pspl,response.chat);
response.pspl=null;
}
if(response.official){for(var _i4=0,_response$official2=
response.official;_i4<_response$official2.length;_i4++){var _roomInfo=_response$official2[_i4];_roomInfo.section="Official";}
response.chat=[].concat(response.official,response.chat);
response.official=null;
}
this.roomsCache=response;
var roomsRoom=PS.rooms["rooms"];
if(roomsRoom)roomsRoom.update(null);
break;
case'roomlist':
var battlesRoom=PS.rooms["battles"];
if(battlesRoom){
var battleTable=response.rooms;
var battles=[];
for(var battleid in battleTable){
battleTable[battleid].id=battleid;
battles.push(battleTable[battleid]);
}
battlesRoom.battles=battles;
battlesRoom.update(null);
}
break;
case'laddertop':for(var _i6=0,_Object$entries2=
Object.entries(PS.rooms);_i6<_Object$entries2.length;_i6++){var _ref=_Object$entries2[_i6];var roomid=_ref[0];var ladderRoom=_ref[1];
if(roomid.startsWith('ladder-')){
ladderRoom.update(response);
}
}
break;
case'teamupload':
if(PS.teams.uploading){var _PS$rooms4,_PS$rooms$teambuilder;
var team=PS.teams.uploading;
team.teamid=response.teamid;
team.uploaded={
teamid:response.teamid,
notLoaded:false,
"private":response.privacy
};
(_PS$rooms4=PS.rooms["team-"+team.key])==null||_PS$rooms4.update(null);
(_PS$rooms$teambuilder=PS.rooms.teambuilder)==null||_PS$rooms$teambuilder.update(null);
PS.teams.uploading=null;
}
break;
case'teamupdate':for(var _i8=0,_PS$teams$list2=
PS.teams.list;_i8<_PS$teams$list2.length;_i8++){var _team=_PS$teams$list2[_i8];
if(_team.teamid===Number(response.teamid)){var _PS$rooms5,_PS$rooms$teambuilder2;
_team.uploaded={
teamid:_team.teamid,
notLoaded:false,
"private":response.privacy
};
(_PS$rooms5=PS.rooms["team-"+_team.key])==null||_PS$rooms5.update(null);
(_PS$rooms$teambuilder2=PS.rooms.teambuilder)==null||_PS$rooms$teambuilder2.update(null);
PS.teams.uploading=null;
break;
}
}
break;
}for(var _i10=0,_ref3=
this.listeners[fullid]||[];_i10<_ref3.length;_i10++){var callback=_ref3[_i10];callback(response);}
delete this.listeners[fullid];
};return MainMenuRoom;}(PSRoom);var


NewsPanel=function(_PSRoomPanel){function NewsPanel(){var _this3;for(var _len2=arguments.length,args=new Array(_len2),_key2=0;_key2<_len2;_key2++){args[_key2]=arguments[_key2];}_this3=_PSRoomPanel.call.apply(_PSRoomPanel,[this].concat(args))||this;_this3.
































markAsRead=function(e){var _window$getSelection;
if(e.shiftKey||e.metaKey||e.ctrlKey||!((_window$getSelection=window.getSelection())!=null&&_window$getSelection.isCollapsed))return;
if(!PS.newsId)return;
PS.prefs.set('newsid',Number(PS.newsId));for(var _i12=0,_querySelectorAll2=
_this3.base.querySelectorAll('.unread');_i12<_querySelectorAll2.length;_i12++){var entry=_querySelectorAll2[_i12];
entry.classList.remove('unread');
}
};return _this3;}_inheritsLoose(NewsPanel,_PSRoomPanel);NewsPanel.getTitle=function getTitle(){return TL(["News"]);};var _proto2=NewsPanel.prototype;_proto2.componentDidMount=function componentDidMount(){_PSRoomPanel.prototype.componentDidMount.call(this);this.startNewsMinimized();};_proto2.startNewsMinimized=function startNewsMinimized(){if(window.innerWidth<628){this.props.room.minimized=true;PS.mainmenu.update(null);return;}var readNewsId=Number(PS.prefs.newsid);if(!readNewsId)return;var hasUnread=false;for(var _i14=0,_querySelectorAll4=this.base.querySelectorAll('.newsentry');_i14<_querySelectorAll4.length;_i14++){var entry=_querySelectorAll4[_i14];var unread=Number(entry.getAttribute('data-newsid'))>readNewsId;entry.classList.toggle('unread',unread);if(unread)hasUnread=true;}if(!hasUnread){this.props.room.minimized=true;PS.mainmenu.update(null);}};_proto2.
render=function render(){
return preact.h(PSPanelWrapper,{room:this.props.room,fullSize:true},
preact.h("div",{"class":"readable-bg",onClick:this.markAsRead,dangerouslySetInnerHTML:{__html:PS.newsHTML}})
);
};return NewsPanel;}(PSRoomPanel);NewsPanel.id='news';NewsPanel.routes=['news'];NewsPanel.title='News';NewsPanel.location='mini-window';var


MainMenuPanel=function(_PSRoomPanel2){function MainMenuPanel(){var _this4;for(var _len3=arguments.length,args=new Array(_len3),_key3=0;_key3<_len3;_key3++){args[_key3]=arguments[_key3];}_this4=_PSRoomPanel2.call.apply(_PSRoomPanel2,[this].concat(args))||this;_this4.


















submitSearch=function(ev,format,team){
if(!PS.user.named){
PS.join('login',{
parentElem:_this4.base.querySelector('.big.button')
});
return;
}
PS.mainmenu.startSearch(format,team,ev.target);
};_this4.
handleDragStart=function(e){var _PS$rightPanel;
var room=PS.getRoom(e.currentTarget);
if(!room)return;
var foreground=PS.leftPanel.id===room.id||((_PS$rightPanel=PS.rightPanel)==null?void 0:_PS$rightPanel.id)===room.id;
PS.dragging={type:'room',roomid:room.id,foreground:foreground};
};_this4.
handleDragEnter=function(e){var _PS$dragging,_PS$rooms$draggingRoo;

e.preventDefault();
if(((_PS$dragging=PS.dragging)==null?void 0:_PS$dragging.type)!=='room')return;
var draggingRoom=PS.dragging.roomid;
if(draggingRoom===null)return;

var draggedOverRoom=PS.getRoom(e.target);
if(draggingRoom===(draggedOverRoom==null?void 0:draggedOverRoom.id))return;

var index=PS.miniRoomList.indexOf(draggedOverRoom==null?void 0:draggedOverRoom.id);
if(index>=0){
PS.dragOnto(PS.rooms[draggingRoom],'mini-window',index);
}else if(((_PS$rooms$draggingRoo=PS.rooms[draggingRoom])==null?void 0:_PS$rooms$draggingRoo.location)!=='mini-window'){
PS.dragOnto(PS.rooms[draggingRoom],'mini-window',0);
}




};_this4.



handleClickMinimize=function(e){var _e$target,_e$target2;
if((_e$target=e.target)!=null&&_e$target.getAttribute('data-cmd')){
return;
}
if((_e$target2=e.target)!=null&&(_e$target2=_e$target2.parentNode)!=null&&_e$target2.getAttribute('data-cmd')){
return;
}
var room=PS.getRoom(e.currentTarget);
if(room){
room.minimized=!room.minimized;
if(!room.minimized)PS.queueFocus(room);
_this4.forceUpdate();
}
};return _this4;}_inheritsLoose(MainMenuPanel,_PSRoomPanel2);MainMenuPanel.getTitle=function getTitle(){return TL(["Home"]);};var _proto3=MainMenuPanel.prototype;_proto3.componentDidMount=function componentDidMount(){var _Config$includes;_PSRoomPanel2.prototype.componentDidMount.call(this);this.subscribeTo(PSBackground);(_Config$includes=Config.includes)==null||_Config$includes.htmlDidMount==null||_Config$includes.htmlDidMount();};_proto3.focus=function focus(options){var _this$base;if(!(options!=null&&options.preventScroll))PSView.scrollToRoom();if(PSView.hasTapped)return;PSView.politeFocus((_this$base=this.base)==null?void 0:_this$base.querySelector('.formatselect'));};_proto3.renderMiniRoom=function renderMiniRoom(room){return preact.h(PSPanelErrorBoundary,{key:room.id,room:room});};_proto3.
renderMiniRooms=function renderMiniRooms(){var _this5=this;
return PS.miniRoomList.map(function(roomid){
var room=PS.rooms[roomid];
var notifying=room.notifications.length?' notifying':room.isSubtleNotifying?' subtle-notifying':'';
return preact.h("div",{
"class":"mini-window"+(room.minimized?' collapsed':'')+(room===PS.room?' focused':''),
key:roomid,"data-roomid":roomid},

preact.h("h3",{
"class":"mini-window-header"+notifying,draggable:true,onDragStart:_this5.handleDragStart,onClick:_this5.handleClickMinimize},

preact.h("button",{"class":"closebutton","data-cmd":"/close","aria-label":TL(["[Close]"]),tabIndex:-1},
preact.h("i",{"class":"fa fa-times-circle","aria-hidden":true})
),
preact.h("button",{"class":"maximizebutton","data-cmd":"/maximize",tabIndex:-1,"aria-label":TL(["[Maximize]"])},
preact.h("i",{"class":"fa fa-stop-circle","aria-hidden":true})
),
preact.h("button",{"class":"minimizebutton",tabIndex:-1,"aria-label":TL(["[Expand/collapse]"])},
preact.h("i",{"class":"fa fa-minus-circle","aria-hidden":true})
),
room.getTitle()
),
_this5.renderMiniRoom(room)
);
});
};_proto3.
renderGames=function renderGames(){
if(!PS.mainmenu.search.games)return null;


return preact.h("div",{"class":"menugroup"},
preact.h("p",{"class":"label"},TL(["You are in:"])),
Object.entries(PS.mainmenu.search.games).map(function(_ref4){var roomid=_ref4[0],gameName=_ref4[1];return preact.h("div",null,
preact.h("a",{"class":"blocklink",href:""+roomid},gameName)
);})
);
};_proto3.
renderSearchButton=function renderSearchButton(){
if(PS.down){
return preact.h("div",{"class":"menugroup",style:"background: rgba(10,10,10,.6)"},
PS.down==='ddos'?
preact.h("p",{"class":"error"},preact.h("strong",null,"Pok\xE9mon Showdown is offline due to a DDoS attack!")):

preact.h("p",{"class":"error"},preact.h("strong",null,"Pok\xE9mon Showdown is offline due to technical difficulties!")),

preact.h("p",null,
preact.h("div",{style:{textAlign:'center'}},
preact.h("img",{width:"96",height:"96",src:"//"+Config.routes.client+"/sprites/gen5/teddiursa.png",alt:""})
),"Bear with us as we freak out."

),
preact.h("p",null,"(We'll be back up in a few hours.)")
);
}

if(!PS.user.userid||PS.isOffline){
return preact.h(TeamForm,{"class":"menugroup",onSubmit:this.submitSearch,selectType:"search"},
preact.h("button",{"class":"mainmenu1 mainmenu big button disabled",disabled:true,name:"search"},
preact.h("em",null,PS.isOffline?[preact.h("span",{"class":"fa-stack fa-lg"},
preact.h("i",{"class":"fa fa-plug fa-flip-horizontal fa-stack-1x","aria-hidden":true}),
preact.h("i",{"class":"fa fa-ban fa-stack-2x text-danger","aria-hidden":true})
),' ',TL(["Disconnected"])]:TL(["Connecting..."]))
),
PS.isOffline&&preact.h("p",{"class":"buttonbar"},
preact.h("button",{"class":"button","data-cmd":"/reconnect"},
preact.h("i",{"class":"fa fa-plug","aria-hidden":true})," ",preact.h("strong",null,TL(["[Reconnect]"]))
)," ",
preact.h(ReconnectTimer,null)
)
);
}

return preact.h(TeamForm,{
"class":"menugroup",format:PS.mainmenu.searchingFormat()||undefined,
selectType:"search",onSubmit:this.submitSearch},

preact.h("p",null,
preact.h("button",{"class":"button small","data-href":"battleoptions"},
TL(["[Battle options]"])," ",preact.h("i",{"class":"fa fa-caret-down","aria-hidden":true})
)),
PS.mainmenu.searchCountdown?
preact.h(preact.Fragment,null,
preact.h("button",{"class":"mainmenu1 mainmenu big button disabled",disabled:true},preact.h("strong",null,
preact.h("i",{"class":"fa fa-refresh fa-spin","aria-hidden":true})," ",TL(["Searching in ","..."],PS.mainmenu.searchCountdown.countdown)
)),
preact.h("p",{"class":"buttonbar"},preact.h("button",{"class":"button","data-cmd":"/cancelsearch"},TL(["[Cancel]"])))
):
PS.mainmenu.searchingFormat()?
preact.h(preact.Fragment,null,
preact.h("button",{"class":"mainmenu1 mainmenu big button disabled",disabled:true},
preact.h("strong",null,preact.h("i",{"class":"fa fa-refresh fa-spin","aria-hidden":true})," ",TL(["Searching..."]))
),
preact.h("p",{"class":"buttonbar"},preact.h("button",{"class":"button","data-cmd":"/cancelsearch"},TL(["[Cancel]"])))
):

preact.h("button",{"class":"mainmenu1 mainmenu big button",type:"submit"},
preact.h("strong",null,TL(["[Battle!]"])),preact.h("br",null),
preact.h("small",null,TL(["Find a random opponent"]))
)

);
};_proto3.
renderBackgroundCredit=function renderBackgroundCredit(){
var attrib=PSBackground.attrib;
if(!attrib)return null;
return(
preact.h("small",null,
preact.h("a",{href:attrib.url,target:"_blank","class":"subtle"},"\"",
attrib.title,"\" ",preact.h("small",null,TL(["background by ",""],attrib.artist))
)
));

};_proto3.
render=function render(){var _Config$includes2;
var onlineButton=' button'+(PS.isOffline?' disabled':'');
var tinyLayout=this.props.room.width<620?' tiny-layout':'';
return preact.h(PSPanelWrapper,{room:this.props.room,onDragEnter:this.handleDragEnter},
preact.h("div",{"class":"mainmenu-mini-windows"+tinyLayout},
!PS.leftPanelWidth&&((_Config$includes2=Config.includes)==null?void 0:_Config$includes2.mainmenuHTML)&&
preact.h("div",{dangerouslySetInnerHTML:{__html:Config.includes.mainmenuHTML}}),

this.renderMiniRooms()
),
preact.h("div",{"class":"mainmenu"+tinyLayout},
preact.h("div",{"class":"mainmenu-left"},
this.renderGames(),

this.renderSearchButton(),

preact.h("div",{"class":"menugroup"},
preact.h("p",null,preact.h("a",{"class":"mainmenu2 mainmenu button",href:"teambuilder"},TL(["[Teambuilder]"]))),
preact.h("p",null,preact.h("a",{"class":"mainmenu3 mainmenu"+onlineButton,href:"ladder"},TL(["Ladder"]))),
preact.h("p",null,preact.h("a",{"class":"mainmenu4 mainmenu"+onlineButton,href:"view-tournaments-all"},TL(["Tournaments"])))
),

preact.h("div",{"class":"menugroup"},
preact.h("p",null,preact.h("a",{"class":"mainmenu4 mainmenu"+onlineButton,href:"battles"},TL(["Watch a battle"]))),
preact.h("p",null,preact.h("a",{"class":"mainmenu5 mainmenu"+onlineButton,href:"users"},TL(["Find a user"]))),
preact.h("p",null,preact.h("a",{"class":"mainmenu6 mainmenu"+onlineButton,href:"view-friends-all"},TL(["Friends"]))),
preact.h("p",null,preact.h("a",{"class":"mainmenu7 mainmenu"+onlineButton,href:"resources"},TL(["Info & Resources"])))
)
),
preact.h("div",{"class":"mainmenu-right",style:{display:PS.leftPanelWidth?'none':'block'}},
preact.h("div",{"class":"menugroup"},
preact.h("p",null,preact.h("a",{"class":"mainmenu1 mainmenu"+onlineButton,href:"rooms"},TL(["Chat rooms"]))),
PS.server.id!=='showdown'&&
preact.h("p",null,preact.h("a",{"class":"mainmenu2 mainmenu"+onlineButton,href:"lobby"},TL(["Lobby chat"])))

)
),
preact.h("div",{"class":"mainmenu-footer"},
preact.h("div",{"class":"bgcredit"},this.renderBackgroundCredit()),
preact.h("small",null,
preact.h("a",{href:"//"+Config.routes.dex+"/",target:"_blank"},TL(["Pok\xE9dex"]))," | ",
preact.h("a",{href:"//"+Config.routes.replays+"/",target:"_blank"},TL(["Replays"]))," | ",
preact.h("a",{href:"//smogon.com/forums/",target:"_blank"},TL(["Forum"]))," | ",
preact.h("a",{href:"//"+Config.routes.root+"/rules",target:"_blank"},TL(["Rules"]))," | ",
preact.h("a",{href:"//"+Config.routes.root+"/credits",target:"_blank"},TL(["Credits"]))," | ",
preact.h("a",{href:"//"+Config.routes.root+"/privacy",target:"_blank"},TL(["Privacy"]))
),
preact.h(CCPAIntercept,null)
)
)
);
};return MainMenuPanel;}(PSRoomPanel);MainMenuPanel.id='mainmenu';MainMenuPanel.routes=[''];MainMenuPanel.Model=MainMenuRoom;MainMenuPanel.icon=preact.h("i",{"class":"fa fa-home","aria-hidden":true});var


CCPAIntercept=function(_preact$Component){function CCPAIntercept(){var _this6;for(var _len4=arguments.length,args=new Array(_len4),_key4=0;_key4<_len4;_key4++){args[_key4]=arguments[_key4];}_this6=_preact$Component.call.apply(_preact$Component,[this].concat(args))||this;_this6.
intercepted=false;return _this6;}_inheritsLoose(CCPAIntercept,_preact$Component);var _proto4=CCPAIntercept.prototype;_proto4.
shouldComponentUpdate=function shouldComponentUpdate(){
this.intercept();
return false;
};_proto4.
componentDidMount=function componentDidMount(){var _this7=this;
this.intercept();
setTimeout(function(){return _this7.intercept();},500);
setTimeout(function(){return _this7.intercept();},1000);
setTimeout(function(){return _this7.intercept();},2000);
setTimeout(function(){return _this7.intercept();},3000);
setTimeout(function(){return _this7.intercept();},5000);
setTimeout(function(){return _this7.intercept();},10000);
};_proto4.
intercept=function intercept(){
if(this.intercepted||!window.$)return;
var $ccpa=$('.fc-dns-dialog');
if(!$ccpa.length)return;
$ccpa.appendTo(this.base);

this.intercepted=true;
};_proto4.
render=function render(){
return preact.h("div",null);
};return CCPAIntercept;}(preact.Component);var


FormatDropdown=function(_preact$Component2){function FormatDropdown(){var _this8;for(var _len5=arguments.length,args=new Array(_len5),_key5=0;_key5<_len5;_key5++){args[_key5]=arguments[_key5];}_this8=_preact$Component2.call.apply(_preact$Component2,[this].concat(args))||this;_this8.




format='';_this8.
change=function(e){
if(!_this8.base)return;
_this8.format=_this8.base.value;
_this8.forceUpdate();
if(_this8.props.onChange)_this8.props.onChange(e);
};return _this8;}_inheritsLoose(FormatDropdown,_preact$Component2);var _proto5=FormatDropdown.prototype;_proto5.
render=function render(){var _customRules;
this.format=this.props.format||this.format||this.props.defaultFormat||'';
var _this$format$split=this.format.split('@@@'),formatName=_this$format$split[0],customRules=_this$format$split[1];
customRules=(_customRules=customRules)==null?void 0:_customRules.replace(/,/g,', ');
if(window.BattleLog)formatName=BattleLog.formatName(formatName);
if(this.props.format&&!this.props.onChange){


return preact.h("button",{
name:"format",value:this.format,"class":"select formatselect preselected",disabled:true},

formatName,
!!customRules&&[preact.h("br",null),preact.h("small",null,TL.label(TL(["Custom rules"]),customRules))]
);
}
return preact.h("button",{
name:"format",value:this.format,"data-selecttype":this.props.selectType,
"class":"select formatselect","data-href":"/formatdropdown",onChange:this.change},

formatName||!!this.props.placeholder&&preact.h("em",null,this.props.placeholder)||null,
!!customRules&&[preact.h("br",null),preact.h("small",null,TL.label(TL(["Custom rules"]),customRules))]
);
};return FormatDropdown;}(preact.Component);var


TeamDropdown=function(_preact$Component3){function TeamDropdown(){var _this9;for(var _len6=arguments.length,args=new Array(_len6),_key6=0;_key6<_len6;_key6++){args[_key6]=arguments[_key6];}_this9=_preact$Component3.call.apply(_preact$Component3,[this].concat(args))||this;_this9.
teamFormat='';_this9.
teamKey='';_this9.
change=function(){
if(!_this9.base)return;
_this9.teamKey=_this9.base.value;
_this9.forceUpdate();
};return _this9;}_inheritsLoose(TeamDropdown,_preact$Component3);var _proto6=TeamDropdown.prototype;_proto6.
getDefaultTeam=function getDefaultTeam(teambuilderFormat){for(var _i16=0,_PS$teams$list4=
PS.teams.list;_i16<_PS$teams$list4.length;_i16++){var team=_PS$teams$list4[_i16];
if(!team.isBox&&team.format===teambuilderFormat)return team.key;
}
return'';
};_proto6.
render=function render(){var _window$BattleFormats;
var teamFormat=PS.teams.teambuilderFormat(this.props.format);
var formatData=(_window$BattleFormats=window.BattleFormats)==null?void 0:_window$BattleFormats[teamFormat];
if(formatData!=null&&formatData.team){
return preact.h("button",{"class":"select teamselect preselected",name:"team",value:"random",disabled:true},
preact.h("div",{"class":"team"},
preact.h("strong",null,TL(["Random team"])),
preact.h("small",null,
preact.h(PSIcon,{pokemon:null}),
preact.h(PSIcon,{pokemon:null}),
preact.h(PSIcon,{pokemon:null}),
preact.h(PSIcon,{pokemon:null}),
preact.h(PSIcon,{pokemon:null}),
preact.h(PSIcon,{pokemon:null})
)
)
);
}
if(teamFormat!==this.teamFormat){
this.teamFormat=teamFormat;
this.teamKey=this.getDefaultTeam(teamFormat);
}
var team=PS.teams.byKey[this.teamKey]||null;
return preact.h("button",{
name:"team",value:this.teamKey,
"class":"select teamselect","data-href":"/teamdropdown","data-format":teamFormat,onChange:this.change,
disabled:!!PS.mainmenu.searchingFormat()},

PS.roomTypes['teamdropdown']&&preact.h(TeamBox,{team:team,noLink:true})
);
};return TeamDropdown;}(preact.Component);var


TeamForm=function(_preact$Component4){function TeamForm(){var _this10;for(var _len7=arguments.length,args=new Array(_len7),_key7=0;_key7<_len7;_key7++){args[_key7]=arguments[_key7];}_this10=_preact$Component4.call.apply(_preact$Component4,[this].concat(args))||this;_this10.






format='';_this10.
teraPreview=false;_this10.
bestOf=false;_this10.
bestOfValue='3';_this10.
customRules=false;_this10.
customRuleText='';_this10.
itemClause=false;_this10.
changeFormat=function(ev){
_this10.setFormat(ev.target.value);
};_this10.



































changeBestOfValue=function(ev){
_this10.bestOfValue=ev.target.value;
};_this10.
changeCustomRules=function(ev){
_this10.customRuleText=ev.target.value;
};_this10.





submit=function(ev,validate){var _window$BattleFormats2;
ev.preventDefault();
var format=_this10.format;

var teambuilderFormat=PS.teams.teambuilderFormat(_this10.props.teamFormat||format);
var needsTeam=!((_window$BattleFormats2=window.BattleFormats[teambuilderFormat])!=null&&_window$BattleFormats2.team);
var teamElement=_this10.base.querySelector('button[name=team]');
var teamKey=teamElement.value;
var team=needsTeam&&teamKey?PS.teams.byKey[teamKey]:undefined;
if(needsTeam&&!team){
PS.alert(TL(["You need to go into the Teambuilder and build a team for this format."]),{
parentElem:teamElement
});
return;
}
var customRules=[];
if(_this10.customRules){
if(_this10.bestOf){
customRules.push("Best of = "+(_this10.bestOfValue||'3'));
}
if(_this10.teraPreview)customRules.push('Tera Type Preview');
customRules.push.apply(customRules,_this10.customRuleText.split('\n').map(function(rule){return rule.trim();}).filter(Boolean));
}
if(_this10.itemClause){
customRules.push('Item Clause = 1');
}
format=_this10.addCustomRules(format,customRules);
PS.teams.loadTeam(team).then(function(){var _ref5;
(_ref5=validate==='validate'?_this10.props.onValidate:_this10.props.onSubmit)==null||_ref5(ev,format,team);
});
};_this10.
toggleCustomRule=function(ev){var _ev$target,_ev$target2;
var checked=(_ev$target=ev.target)==null?void 0:_ev$target.checked;
var rule=(_ev$target2=ev.target)==null?void 0:_ev$target2.name;
if(rule==='terapreview')_this10.teraPreview=checked;
if(rule==='bestof')_this10.bestOf=checked;
if(rule==='customrules'){
_this10.customRules=checked;
if(!checked){
_this10.bestOf=false;
_this10.teraPreview=false;
}
_this10.forceUpdate();
}
if(rule==='itemclause')_this10.itemClause=checked;
};_this10.
handleClick=function(ev){
var target=ev.target;
while(target&&target!==_this10.base){
if(target.tagName==='BUTTON'&&target.name==='validate'){
_this10.submit(ev,'validate');
return;
}
target=target.parentNode;
}
};return _this10;}_inheritsLoose(TeamForm,_preact$Component4);var _proto7=TeamForm.prototype;_proto7.setFormat=function setFormat(format){var _format$split=format.split('@@@'),baseFormat=_format$split[0],customRules=_format$split[1];this.format=baseFormat;this.loadCustomRules(customRules);};_proto7.loadCustomRules=function loadCustomRules(customRules){this.bestOf=false;this.bestOfValue='3';this.teraPreview=false;this.itemClause=false;if(!customRules){this.customRules=false;this.customRuleText='';return;}this.customRules=true;var unknownRules=[];for(var _i18=0,_customRules$split2=customRules.split(',');_i18<_customRules$split2.length;_i18++){var rule=_customRules$split2[_i18];var trimmedRule=rule.trim();if(!trimmedRule)continue;var bestOfMatch=/^best[-\s]*of\s*=\s*(\d+)$/i.exec(trimmedRule);if(bestOfMatch){this.bestOf=true;this.bestOfValue=bestOfMatch[1];}else if(/^tera\s+type\s+preview$/i.test(trimmedRule)){this.teraPreview=true;}else if(/^item\s+clause\s*=\s*1$/i.test(trimmedRule)){this.itemClause=true;}else{unknownRules.push(trimmedRule);}}this.customRuleText=unknownRules.join('\n');};_proto7.addCustomRules=function addCustomRules(format,rules){if(!rules.length)return format;var hasCustomRules=format.includes('@@@');return""+format+(hasCustomRules?', ':'@@@ ')+rules.join(', ');};_proto7.
render=function render(){var _this$props$defaultFo;
if(window.BattleFormats){
this.format||(this.format=this.props.defaultFormat||'');
if(!this.format){
this.format="gen"+Dex.gen+"randombattle";

var starredPrefs=PS.prefs.starredformats||{};

var starred=Object.keys(starredPrefs).filter(function(id){return starredPrefs[id]===true;}).reverse();for(var _i20=0;_i20<
starred.length;_i20++){var id=starred[_i20];
var _format=window.BattleFormats[id];
if(!_format)continue;
if(this.props.selectType==='challenge'&&(_format==null?void 0:_format.challengeShow)===false)continue;
if(this.props.selectType==='search'&&(_format==null?void 0:_format.searchShow)===false)continue;
if(this.props.selectType==='teambuilder'&&_format!=null&&_format.team)continue;
this.format=id;
break;
}
}
}
if((_this$props$defaultFo=this.props.defaultFormat)!=null&&_this$props$defaultFo.startsWith('!!')){


this.setFormat(this.props.defaultFormat.slice(2));
}
if(this.props.format)this.format=this.props.format;
if(!this.props.format&&this.format.includes('@@@'))this.setFormat(this.format);
var formatId=toID(this.format.split('@@@')[0]);
var format=window.BattleFormats[formatId];
var showCustomRules=this.props.selectType==='challenge'&&!this.props.format;
return preact.h("form",{"class":this.props["class"],onSubmit:this.submit,onClick:this.handleClick},
!this.props.hideFormat&&preact.h("p",null,
preact.h("label",{"class":"label"},
TL.label(TL(["Format"])),preact.h("br",null),
preact.h(FormatDropdown,{
selectType:this.props.selectType,format:this.format,
onChange:this.props.format?undefined:this.changeFormat}
)
)
),
preact.h("p",null,
preact.h("label",{"class":"label"},
TL.label(TL(["Team"])),preact.h("br",null),
preact.h(TeamDropdown,{format:this.props.teamFormat||this.format})
)
),
showCustomRules&&(!this.customRules?preact.h("p",null,
preact.h("label",{"class":"checkbox"},preact.h("input",{
type:"checkbox",name:"customrules",checked:this.customRules,onChange:this.toggleCustomRule}
)," Custom rules")
):preact.h("fieldset",{"class":"fieldset"},
preact.h("legend",null,preact.h("label",{"class":"checkbox"},preact.h("input",{
type:"checkbox",name:"customrules",checked:this.customRules,onChange:this.toggleCustomRule}
)," Custom rules")),
((format==null?void 0:format.bestOfDefault)||this.bestOf)&&preact.h("p",null,
preact.h("label",{"class":"checkbox"},
preact.h("input",{
type:"checkbox",name:"bestof",checked:this.bestOf,onChange:this.toggleCustomRule}
),
preact.h("abbr",{title:"Start a team-locked best-of-n series"},"Best-of-",preact.h("input",{
name:"bestofvalue",type:"number",min:"3",max:"9",step:"2",value:this.bestOfValue,
onInput:this.changeBestOfValue,
style:"width: 28px; vertical-align: initial;"}
)))
),
((format==null?void 0:format.teraPreviewDefault)||this.teraPreview)&&preact.h("p",null,
preact.h("label",{"class":"checkbox"},preact.h("input",{
type:"checkbox",name:"terapreview",checked:this.teraPreview,onChange:this.toggleCustomRule}
)," Tera Type Preview")
),
((format==null?void 0:format.itemClauseDefault)||this.itemClause)&&preact.h("p",null,
preact.h("label",{"class":"checkbox"},preact.h("input",{
type:"checkbox",name:"itemclause",checked:this.itemClause,onChange:this.toggleCustomRule}
)," Item Clause")
),
preact.h("textarea",{
name:"customrules","class":"textbox",rows:3,placeholder:"Rules separated by commas or lines",
value:this.customRuleText,onInput:this.changeCustomRules,
style:"min-height:3em"}
),
preact.h("small",null,preact.h("a",{
href:"https://github.com/smogon/pokemon-showdown/blob/master/config/CUSTOM-RULES.md",target:"_blank"},
"Custom rules guide"))
)),
preact.h("p",null,this.props.children)
);
};return TeamForm;}(preact.Component);


PS.addRoomType(NewsPanel,MainMenuPanel);
//# sourceMappingURL=panel-mainmenu.js.map