"use strict";/**
 * Battle log
 *
 * An exercise in minimalism! This is a dependency of the client, which
 * requires IE9+ and uses Preact, and the replay player, which requires
 * IE7+ and uses jQuery. Therefore, this has to be compatible with IE7+
 * and use the DOM directly!
 *
 * Special thanks to PPK for QuirksMode.org, one of the few resources
 * available for how to do web development in these conditions.
 *
 * @author Guangcong Luo <guangcongluo@gmail.com>
 * @license MIT
 */var


















BattleLog=function(){



























function BattleLog(elem,scene,innerElem){var _this=this;this.elem=void 0;this.innerElem=void 0;this.scene=null;this.preemptElem=null;this.atBottom=true;this.skippedLines=false;this.className=void 0;this.battleParser=null;this.joinLeave=null;this.lastRename=null;this.perspective=-1;this.getHighlight=null;this.isIgnored=null;this.canRevealMessages=null;this.




























onClick=function(ev){
var target=ev.target;
while(target&&target!==_this.elem){
if(target.tagName==='SUMMARY'){var _window$getSelection;
if((window.getSelection==null||(_window$getSelection=window.getSelection())==null?void 0:_window$getSelection.type)==='Range'){


ev.preventDefault();
}else{
setTimeout(_this.updateScroll,0);
}
}
target=target.parentElement;
}
};this.
onScroll=function(){
var distanceFromBottom=_this.elem.scrollHeight-_this.elem.scrollTop-_this.elem.clientHeight;
_this.atBottom=distanceFromBottom<30;
};this.












































































































































































































































































































































































































































































































































































































































































































































































































































































































updateScroll=function(){
if(_this.atBottom){
_this.elem.scrollTop=_this.elem.scrollHeight;
}
};this.elem=elem;innerElem||(innerElem=elem.querySelector('.inner')||undefined);if(!innerElem){elem.setAttribute('role','log');elem.innerHTML='';innerElem=document.createElement('div');innerElem.className='inner message-log';elem.appendChild(innerElem);}this.innerElem=innerElem;if(scene){this.scene=scene;var preemptElem=elem.querySelector('.inner-preempt');if(!preemptElem){preemptElem=document.createElement('div');preemptElem.className='inner-preempt message-log';elem.appendChild(preemptElem);}this.preemptElem=preemptElem;this.battleParser=new BattleTextParser();}this.className=elem.className;elem.onscroll=this.onScroll;elem.onclick=this.onClick;}var _proto=BattleLog.prototype;_proto.reset=function reset(){if(this.battleParser){this.battleParser.language=Dex.text.getLanguage();this.battleParser.lowercaseRegExp=undefined;}this.innerElem.innerHTML='';if(this.preemptElem)this.preemptElem.innerHTML='';this.atBottom=true;this.skippedLines=false;this.joinLeave=null;this.lastRename=null;};_proto.destroy=function destroy(){this.elem.onscroll=null;this.elem.innerHTML='';};_proto.addSeekEarlierButton=function addSeekEarlierButton(){var _this2=this;if(this.skippedLines)return;this.skippedLines=true;var el=document.createElement('div');el.className='chat';el.innerHTML="<button class=\"button earlier-button\"><i class=\"fa fa-caret-up\" aria-hidden=\"true\"></i><br />"+TL(["[Earlier messages]"])+"</button>";var button=el.getElementsByTagName('button')[0];button==null||button.addEventListener==null||button.addEventListener('click',function(e){var _this2$scene;e.preventDefault();(_this2$scene=_this2.scene)==null||_this2$scene.battle.seekBy(-100);});this.addNode(el);};BattleLog.renderTimestamp=function renderTimestamp(timestamp,showTimestamps){if(!showTimestamps)return'';var date=timestamp&&!isNaN(timestamp)?new Date(timestamp*1000):new Date();var components=[date.getHours(),date.getMinutes()];if(showTimestamps==='seconds')components.push(date.getSeconds());return"<small class=\"gray\">["+components.map(function(x){return x<10?"0"+x:x;}).join(':')+"] </small>";};_proto.add=function add(args,kwArgs,preempt,showTimestamps){var _this$scene,_window$app2,_window$app3,_this$getHighlight,_this$scene2,_window$app5;if(kwArgs!=null&&kwArgs.silent)return;var battle=(_this$scene=this.scene)==null?void 0:_this$scene.battle;if(battle!=null&&battle.seeking){if(battle.stepQueue.length>2000){if(battle.seeking===Infinity?battle.currentStep<battle.stepQueue.length-2000:battle.turn<battle.seeking-100){this.addSeekEarlierButton();return;}}}var divClass='chat';var divHTML='';var noNotify;if(!['name','n'].includes(args[0]))this.lastRename=null;switch(args[0]){case'chat':case'c':case'c:':var name;var message;var timestamp=0;if(args[0]==='c:'){timestamp=parseInt(args[1]);name=args[2];message=args[3];}else{name=args[1];message=args[2];}var rank=name.charAt(0);if(battle!=null&&battle.ignoreSpects&&' +'.includes(rank))return;if(battle!=null&&battle.ignoreOpponent){var _window$app,_window$PS;if("\u2605\u2606".includes(rank)&&toUserid(name)!==(((_window$app=window.app)==null||(_window$app=_window$app.user)==null?void 0:_window$app.get('userid'))||((_window$PS=window.PS)==null||(_window$PS=_window$PS.user)==null?void 0:_window$PS.userid))){return;}}var isIgnored=this.isIgnored?this.isIgnored(name):((_window$app2=window.app)==null||(_window$app2=_window$app2.ignore)==null?void 0:_window$app2[toUserid(name)])&&" +^\u2605\u2606".includes(rank);if(isIgnored)return;var timestampHtml=BattleLog.renderTimestamp(timestamp,showTimestamps);var isHighlighted=((_window$app3=window.app)==null||(_window$app3=_window$app3.rooms)==null?void 0:_window$app3[battle.roomid].getHighlight(message))||((_this$getHighlight=this.getHighlight)==null?void 0:_this$getHighlight.call(this,args));var _this$parseChatMessag=this.parseChatMessage(message,name,timestampHtml,isHighlighted);divClass=_this$parseChatMessag[0];divHTML=_this$parseChatMessag[1];noNotify=_this$parseChatMessag[2];if(!noNotify&&isHighlighted){var _window$app4;var notifyTitle=TL(["Mentioned by "," in ",""],name,(battle==null?void 0:battle.roomid)||'');(_window$app4=window.app)==null||(_window$app4=_window$app4.rooms[(battle==null?void 0:battle.roomid)||''])==null||_window$app4.notifyOnce(notifyTitle,"\""+message+"\"",'highlight');}break;case'join':case'j':case'leave':case'l':{var user=BattleTextParser.parseNameParts(args[1]);if(battle!=null&&battle.ignoreSpects&&' +'.includes(user.group))return;var formattedUser=user.group+user.name;var isJoin=args[0].startsWith('j');if(!this.joinLeave){this.joinLeave={joins:[],leaves:[],element:document.createElement('div')};this.joinLeave.element.className='chat';}if(isJoin&&this.joinLeave.leaves.includes(formattedUser)){this.joinLeave.leaves.splice(this.joinLeave.leaves.indexOf(formattedUser),1);}else{this.joinLeave[isJoin?"joins":"leaves"].push(formattedUser);}var joins=this.joinLeave.joins.length?TL([""," joined"],this.textList(this.joinLeave.joins)):'';var leaves=this.joinLeave.leaves.length?TL([""," left"],this.textList(this.joinLeave.leaves)):'';var buf=joins&&leaves?TL(["","; ",""],joins,leaves):joins||leaves;this.joinLeave.element.innerHTML="<small class=\"gray\">"+BattleLog.escapeHTML(buf)+"</small>";(preempt?this.preemptElem:this.innerElem).appendChild(this.joinLeave.element);return;}case'name':case'n':{var _user=BattleTextParser.parseNameParts(args[1]);if(toID(args[2])===toID(_user.name))return;if(!this.lastRename||toID(this.lastRename.to)!==toID(_user.name)){this.lastRename={from:args[2],to:'',element:document.createElement('div')};this.lastRename.element.className='chat';}this.lastRename.to=_user.group+_user.name;var renameTo=BattleLog.escapeHTML(this.lastRename.to);var renameFrom=BattleLog.escapeHTML(this.lastRename.from);this.lastRename.element.innerHTML="<small class=\"gray\">"+TL([""," renamed from ","."],renameTo,renameFrom)+"</small>";(preempt?this.preemptElem:this.innerElem).appendChild(this.lastRename.element);return;}case'chatmsg':case'':divHTML=BattleLog.escapeHTML(args[1]);break;case'chatmsg-raw':case'raw':case'html':divHTML=BattleLog.sanitizeHTML(args[1]);break;case'uhtml':case'uhtmlchange':this.changeUhtml(args[1],args[2],args[0]==='uhtml');return['',''];case'error':case'inactive':case'inactiveoff':divClass='chat message-error';divHTML=BattleLog.escapeHTML(args[1]);break;case'bigerror':this.message('<div class="broadcast-red">'+BattleLog.escapeHTML(args[1]).replace(/\|/g,'<br />')+'</div>');return;case'pm':if(args[3].startsWith('/text '))args[3]=args[3].slice(6);if(args[3].startsWith('/raw')||args[3].startsWith('/html')||args[3].startsWith('/uhtml')||args[3].startsWith('/uhtmlchange')){return;}var colorStyle=" style=\"color:"+BattleLog.usernameColor(toID(args[1]))+"\"";var pmTarget=BattleLog.escapeHTML(args[2]);divHTML=BattleLog.renderTimestamp(null,showTimestamps)+("<strong"+colorStyle+"> "+this.renderName(args[1])+":</strong> <span class=\"message-pm\"><i style=\"cursor:pointer\" data-href=\"dm-"+toID(args[1])+"\">"+TL(["(Private to ",")"],pmTarget)+"</i> "+BattleLog.parseMessage(args[3])+" </span>");break;case'b':case'B':{var _window$PS2;var showBattlesPref=(_window$PS2=window.PS)==null||(_window$PS2=_window$PS2.prefs)==null?void 0:_window$PS2.showbattles;if(args[0]==='B'&&showBattlesPref===false)return;var id=args[1];var format=BattleLog.escapeFormat(BattleLog.roomidToFormat(id));var battleP1="<strong style=\"color:"+BattleLog.usernameColor(toUserid(args[2]))+"\">"+BattleLog.escapeHTML(args[2])+"</strong>";var battleP2="<strong style=\"color:"+BattleLog.usernameColor(toUserid(args[3]))+"\">"+BattleLog.escapeHTML(args[3])+"</strong>";var started;if(format&&format!=='Random Battle'){started=TL([""," battle started between "," and ","."],format,battleP1,battleP2);}else if(format){started=TL([""," started between "," and ","."],format,battleP1,battleP2);}else{started=TL(["Battle started between "," and ","."],battleP1,battleP2);}divClass='notice';divHTML="<a href=\"/"+BattleLog.escapeHTML(id)+"\" class=\"ilink\">"+started+"</a>";this.joinLeave=null;break;}case'askreg':this.addDiv('chat',"<div class=\"broadcast-blue\"><b>"+TL(["Register an account to protect your ladder rating!"])+"</b><br /><button name=\"register\" value=\""+BattleLog.escapeHTML(args[1])+"\"><b>"+TL(["[Register]"])+"</b></button></div>");return;case'unlink':{var _window$PS3,_window$Dex;if((_window$PS3=window.PS)!=null&&(_window$PS3=_window$PS3.prefs)!=null&&_window$PS3.nounlink||(_window$Dex=window.Dex)!=null&&(_window$Dex=_window$Dex.prefs)!=null&&_window$Dex.nounlink)return;var _user2=toID(args[2])||toID(args[1]);this.unlinkChatFrom(_user2);if(args[2]){var lineCount=parseInt(args[3],10);this.hideChatFrom(_user2,true,lineCount);}return;}case'hidelines':{var _window$PS4,_window$Dex2;if((_window$PS4=window.PS)!=null&&(_window$PS4=_window$PS4.prefs)!=null&&_window$PS4.nounlink||(_window$Dex2=window.Dex)!=null&&(_window$Dex2=_window$Dex2.prefs)!=null&&_window$Dex2.nounlink)return;var _user3=toID(args[2]);this.unlinkChatFrom(_user3);if(args[1]!=='unlink'){var _this$canRevealMessag;var _lineCount=parseInt(args[3],10);this.hideChatFrom(_user3,args[1]==='hide'||!!((_this$canRevealMessag=this.canRevealMessages)!=null&&_this$canRevealMessag.call(this)),_lineCount);}return;}case'debug':divClass='debug';divHTML='<div class="chat"><small style="color:#999">[DEBUG] '+BattleLog.escapeHTML(args[1])+'.</small></div>';break;case'notify':var title=args[1];var body=args[2];var roomid=(_this$scene2=this.scene)==null?void 0:_this$scene2.battle.roomid;if(!roomid)break;(_window$app5=window.app)==null||_window$app5.rooms[roomid].notifyOnce(title,body,'highlight');break;case'showteam':{if(!battle)return;var team=Teams.unpack(args[2]);if(!team.length)return;var side=battle.getSide(args[1]);var exportedTeam=team.map(function(set){var buf=Teams["export"]([set],battle.dex).replace(/\n/g,'<br />');if(set.name&&set.name!==set.species){buf=buf.replace(set.name,BattleLog.sanitizeHTML("<span class=\"picon\" style=\""+Dex.getPokemonIcon(set.species)+"\"></span><br />"+set.name));}else{buf=buf.replace(set.species,"<span class=\"picon\" style=\""+Dex.getPokemonIcon(set.species)+"\"></span><br />"+set.species);}if(set.item){buf=buf.replace(set.item,set.item+" <span class=\"itemicon\" style=\""+Dex.getItemIcon(set.item)+"\"></span>");}return buf;}).join('');divHTML="<div class=\"infobox\"><details class=\"details\"><summary>"+TL(["Open team sheet for ",""],side.name)+"</summary>"+exportedTeam+"</details></div>";break;}case'seed':case'choice':case':':case'timer':case't:':case'J':case'L':case'N':case'spectator':case'spectatorleave':case'initdone':return;default:this.addBattleMessage(args,kwArgs);this.joinLeave=null;return;}if(divHTML){this.addDiv(divClass,divHTML,preempt);this.joinLeave=null;}};_proto.addBattleMessage=function addBattleMessage(args,kwArgs){var _this$battleParser$pa,_this$battleParser;switch(args[0]){case'warning':this.message("<strong>"+TL.label(TL(["Warning"]))+"</strong>"+BattleLog.escapeHTML(args[1]));this.message("Bug? Report it to <a href=\"http://www.smogon.com/forums/showthread.php?t=3453192\">the replay viewer's Smogon thread</a>");if(this.scene)this.scene.wait(1000);return;case'variation':this.addDiv('',"<small>"+TL.label(TL(["Variation"]))+"<em>"+BattleLog.escapeHTML(args[1])+'</em></small>');break;case'rule':var ruleArgs=args[1].split(': ');this.addDiv('','<small><em>'+BattleLog.escapeHTML(ruleArgs[0])+(ruleArgs[1]?':':'')+'</em> '+BattleLog.escapeHTML(ruleArgs[1]||'')+'</small>');break;case'rated':this.addDiv('rated','<strong>'+(BattleLog.escapeHTML(args[1])||TL(["Rated battle"]))+'</strong>');break;case'tier':this.addDiv('',"<small>"+TL.label(TL(["Format"]))+"</small><br /><strong>"+BattleLog.escapeHTML(args[1])+'</strong>');break;case'turn':var h2elem=document.createElement('h2');h2elem.className='battle-history';h2elem.innerHTML=BattleLog.escapeHTML(this.turnText(args[1]));if(this.battleParser)this.battleParser.curLineSection='break';this.addSpacer();this.addNode(h2elem);break;default:if(this.addAFDMessage(args,kwArgs))return;var line=(_this$battleParser$pa=(_this$battleParser=this.battleParser)==null?void 0:_this$battleParser.parseArgs(args,kwArgs||{},true))!=null?_this$battleParser$pa:null;if(line===null){this.addDiv('chat message-error','Unrecognized: |'+BattleLog.escapeHTML(args.join('|')));return;}if(line)this.messageFromLog(line);break;}};_proto.addAFDMessage=function addAFDMessage(args){var _this3=this;var kwArgs=arguments.length>1&&arguments[1]!==undefined?arguments[1]:{};if(!Dex.afdMode)return;if(!this.battleParser||!this.scene)return;var messageFromArgs=function(args1){var kwArgs1=arguments.length>1&&arguments[1]!==undefined?arguments[1]:{};_this3.messageFromLog(_this3.battleParser.parseArgs(args1,kwArgs1,true));};if(args[0]==='move'){if(kwArgs.from)return false;var moveid=toID(args[2]);if(moveid==='taunt'){messageFromArgs(args,kwArgs);var quotes=["Yo mama so fat, she 4x resists Ice- and Fire-type attacks!","Yo mama so ugly, Captivate raises her opponent's Special Attack!","Yo mama so dumb, she lowers her Special Attack when she uses Nasty Plot!","Yo mama so fat, she eats her Aguav Berry at 50% HP!","Yo Mama so stupid, she tried to count clouds one through eight!","Yo Mama so stupid, she thought Sticky Hold meant she needed to grab a stick!","Yo Mama so old, her Paradox forme would be Great Grandma!","Yo Mama so stupid, she can't learn anything from the move tutor!","Yo Mama so rude, she got Kyogre and Groudon to team up against her!","Yo Mama so fat, Focus Blast never misses her!","Yo Mama so fat, the Darkest Day is when she's tanning!","Yo Mama so stinky, her damaging moves have a 10% chance to make the opponent flinch!","Yo Mama so old, she has the NPCs from Legends Arceus in her yearbook!","Yo Mama so stupid, she's still trying to find Rhydon!","Yo Mama so stupid, she asked if the Insect Plate comes with an appetizer!","Yo Mama so bad, she got her Stunfisk paralyzed!","Yo Mama so nasty, Black Sludge heals her 1/16th!","Yo Mama so stupid, she gave her Bisharp Black Sludge!","Yo Mama so stupid, she runs a suboptimal EV spread on her Tera Poison Calm Mind Chimecho, making it faint to a Choice Banded Dragonite Tera Normal Extreme Speed!","Yo Mama so casual, she mains NatDex AG!","Yo Mama so casual, she ladders with Red's team!","Yo Mama so dumb, she scouts teams in Randbats!","Yo Mama so lazy, she loafs around every turn!","Yo Mama so fat, she changes type when holding a Dinner Plate!","Yo Mama so slow, even Trick Room won't let her go first!","Yo Mama so dumb, not even Gummis can raise her IQ!","Show me your moves!","Yo Mama so nasty, thinking about her gives a +2 Special Attack boost!","Yo Mama so broke, her deck has no energy cards so she can save on electricity!","Yo Mama so dumb, she tried using Twitch Plays Pokemon as a walkthrough guide!","Yo Mama so dumb, Slowpoke finishes her sentences!","Yo Mama so old, she babysat AZ!","Yo Mama so stupid, not even Own Tempo could prevent her from being confused!","Yo Mama so ugly, even Brock wanted nothing to do with her!","Yo Mama so stupid, she drank antifreeze to cure her status condition!","Yo Mama so trashy, they named a Wormadam forme after her!","Yo Mama so broke, her Gholdengo is made out of checkers!","Yo Mama so ugly, she killed Mimikyu when it saw her!","Yo Mama so fat, she doesn't need a Wailord to meet the Regis!","Unfortunate doesn't even begin to describe Yo Mama!","Yo Mama so dumb, she brags about using a bot to get her opponent's teams!","Yo Mama so fat, her Wishes cause integer overflows!","Yo Mama so ugly, she makes Attract fail!","Yo Mama so dumb, she makes Dondozo look aware!","Yo Mama so smelly, she KOes Nosepass without making a single move!","Yo mama so fat, she doesn't know what the item Leftovers is!","Yo Mama so ugly, she gets OHKOed by Mirror Shot!","Yo Mama so smelly, her VGC analysis pairs her with Slaking!","Yo Mama so old, she has to be extracted in Cinnabar Lab!","Yo Mama so fat, she sets Gravity on switch-in!","Yo Mama so dumb, she's immune to this move!"];var battle=this.scene.battle;var quote=quotes[((battle.p1.name.charCodeAt(2)||0)+(battle.p2.name.charCodeAt(2)||0)*19+(battle.p1.name.charCodeAt(3)||0)*61+(battle.p2.name.charCodeAt(3)||0)+battle.turn+(args[1].charCodeAt(1)||0)*109+(args[1].charCodeAt(2)||0)*113)%quotes.length];this.messageFromLog(this.battleParser.fixLowercase(this.battleParser.pokemon(args[1])+" said, \""+quote+"\""));this.scene.wait(3*this.scene.battle.messageFadeTime/this.scene.acceleration);return true;}}else if(args[0]==='-prepare'){var _moveid=toID(args[2]);if(_moveid==='chillyreception'){var dadJokes=["This should be a Fire-type move, because I'm spitting flames.","Why didn't Vigoroth evolve? Because it was Slaking on its training!","I'm going snowwhere fast!","Don't Slack Off if you wanna beat me!","Where do you buy toys for a Ground-type? Land-R-Us!","I've got half a mind to just leave. The other half belongs to my Shellder.","Why did the Slowking cross the road?","What's the best Pokemon to get rid of bugs? Flygone!","What's the best Pokemon to get rid of bugs? Heatmor. What, were you expecting a pun?","I guess you could call Heatmor an Ant-heater.","Why do they call it Enamor-us when you can only have one of them on a team?","Cloyster? I hardly know 'er!","Why do they call Shedinja invincible when I can still see it?","Dondozo? I don't think I can, that seems really cumbersome.","Appletun? No, there's only one of them.","Drilbur? I hardly know 'er!","Iron Crown? I hardly know 'er!","Shellder? I hardly know 'er!","Magnemite? I sure hope it will!","Graveler? I hardly know 'er!","Grimer? I hardly know 'er!","Baxcalibur? I hardly know 'er!","Why do they call it Kyurem when it doesn't heal anybody?","Conkeldurr? I hardly know 'er!","Weavile? No, I don't think we are.","Dragapult? Doesn't seem very efficient, don't they usually have wheels?","Dragonite? Sounds like it'd be hard with all that heavy armor.","How do you play whack-a-mole with a Fighting-type? Hit 'm on top!","I don't know who made Pokemon Go, but I'm trying to figure out how to make them Pokemon Go to the polls!","Gholdengo? Yeah, it should gholden-go somewhere else.","Some folks call me Charming, but I still feel like I take plenty of physical damage. What gives?","I learned this move in South America, they called it a Chile Reception","I had a Canadian Tyrogue. It evolved into a Hitmontreal.","Why do Venusaur's roommates wear earplugs at night? Because Venus-snores!","I bought stock in my Charmander before it evolved. Now I'm a Charmeleonaire!","Charizard? I actually think char is pretty easy!","Why doesn't Squirtle's mom buy it action figures? Because it likes to blast toys!","Why does Caterpie like Margarine so much? Because it's butter-free!","What did the Alolan Raichu say to the surfer? Nothing, it just waved!","Clefable? What's Clef able to do?","Why did the Nidorans start a revolution? Because they didn't Nidoking!","Alolan Ninetales? More like Aurora Nine-veils!","Wigglytuff? Doesn't look that tough to me.","I dug up a weird vegetable yesterday. Well, it wasn't THAT weird, just a little Oddish!","Why was the Vileplume so happy? Because it wasn't Gloom-y anymore!","What do you call three guys named Doug? A Dugtrio!","Why is it called Golduck when it's blue?","What Rock-type is the best at soccer? Goal-em!","Why is Galarian Slowbro so good at art? Because it's Quick on the Draw!","Do you like my jokes? I've got a Magne-ton of them!","Where do three-headed birds go for Carnival? Dodrio de Janeiro!","What would Muk be called if it could rap? Slime Shady!","Kingler? I hardly know 'er!","Exeggutor? I hardly know 'er!","Have you heard that Trainers who use Hypno are hip? No?","What do ghosts build at Christmastime? Gengar-bread houses!","What street does Voltorb live on? Elect Road!","I told a Hitmonlee some of my jokes. He really got a kick out of them!","What's a Hitmonchan's favorite holiday? Boxing Day!","Did you know Galarian Weezing doesn't know how to drive? It always puts the car in Neutral before stepping on the Gas!","How can you tell if a Poison-type has asthma? See if it's Weezing!","What Pokémon loves to find you when you hide? Seaking!","If we Psychic-types made a movie, it would have to Starmie!","Scyther? I hardly know 'er!","Pinsir? I hardly know 'er!","What Pokémon does Aladdin ride? A Magikarpet!","What do you get if you cut a Gyarados in half? Gyara-uno!","What do you call a Lapras carrying a gun? The Glock Ness Monster!","What's a Ditto's favorite food? Impasta!","Flareon? They should turn the flare off!","Where does a 1000-pound Snorlax sleep? Anywhere it wants!","Zapdos? Zap those what?","My Grass-type friend has been losing weight recently. It's nice to see them losing a few pounds, but I hate to see Me-gaining-'em!","What does a Fire-type wear around its neck? A Tie-phlosion!","Why do they call Ledian the Five Star Pokémon? I'd give it two stars at best!","Ariados? That's impressive, most people can't even perform one aria.","Crobat? It doesn't look like a crow at all!","Why do web developers hire Xatu to predict their profits? Because it can see their Future Sites!","What superhero lives under the sea and has Volt Absorb? The Green Lanturn!","Why should you never play cards with the Cottonweed Pokémon? Because it always Jump-bluffs!","What Pokémon comes after Espeon? T-peon!","Why did the Kartana faint to Bullet Punch? Because Scizor beats paper!","Sometimes I put lava in my gas tank. It really makes Magcargo!","I wrote my Ice-type friend a letter. I hope it gets Delibird!","What's a Mantine's favorite type of cheese? Mantaray Jack!","What kind of bird is Skarmory? A Roost-er!","My friend caught a Porygon. I also did, but he got jealous when I told him I caught a Porygon too!","What do you name a Smeargle that can't use Sketch anymore? Drew!","Why couldn't the smart Chansey evolve? Because ignorance is Blissey!","The classic Suicune set has a Water move, Calm Mind, and Sleep Talk. That's only 3 moves, but I'm sure you can figure out the Rest!","I went to one of Lugia's parties once. It was an Aero-blast!","What do pseudo-Legendaries pave their roads with? Tyrani-tar!","What's Ho-Oh's favorite food? Hot wings!","How often does Celebi travel? From time to time!","What's on a Grass-type's bathroom floor? Scep-tiles!","What's Blaziken's favorite food? Fried chicken!","Why doesn't Swampert go outside? Because it can't touch grass!","How do I know my jokes are good? I told them to a Mightyena and it couldn't stop laughing!","What kind of Poké Ball do you catch Dustox in? A mothball!","Who are Shiftry's biggest fans? Its hands!","Why was the evolving Surskit brought before a court? It was Masqu-arraigned!","Gardevoir? What's a voir and why should I guard it?","I moved in with a Breloom, but the apartment didn't have mushroom!","What's a Hariyama's favorite Pokémon games? Ultra SuMo!","I took my Delcatty to the vet because I thought it was going blind, but it had Normal-eyes!","What's Sableye's zodiac sign? Gem-in-eye!","What do you call a Medicham that's lost its pants? Yogi Bare!","Why does Aggron plant trees after a disaster? That's part of its Aggro-culture!","What happened when the Plusle and Minun fell in love? They multiplied!","I once rode on a Wailord's back. It was a whale of a time!","That Anger Point Camerupt sure has a temper. Crit it once and it'll blow its top!","What season does Spoink like the best? Spring!","I'd tell you a joke about Grumpig, but you wouldn't appreciate it. I'd be casting pearls before swine!","It takes a human 5 minutes to walk a block, but for Spinda it takes half an hour. The difference is staggering!","That cloud Pokémon acts innocent, but I know it has an Altaria motive!","Zangoose? It doesn't look like a goose at all!","What are Solrock's favorite music genres? Soul and rock!","They hate on you when you're a Barboach, but everyone wants to be your friend when you pull up Whis-cash!","What does a Lileep get from Dairy Queen? A Cra-Dilly Bar!","I know a way you can see invisible Kecleons, but that's beyond the Scope of this joke!","What does a Tropius wear over its shirt? A Har-vest!","Why is it called Walrein if it's better in snow?","I've always been a fan of ball-shaped Pokémon, but one in particular Sphealed the deal!","I'd make a joke about Luvdisc, but it's already a joke!","Why is the Iron Leg Pokémon always covered in dirt and slime? Because it's Meta-gross!","Why is Regirock called the Rock Peak Pokémon when it's so mid?","Why is Clear Body Regice such a bad liar? Because you can see right through it!","Why was Registeel fired from the convenience store? Because it would always Steel from the Regi-ster!","I'd make a joke about Latias, but that would be just plane silly!","Did you know that Rayquaza has a certain smell that it takes wherever it goes? That's right, it's Draggin' A-scent!","Did you hear about the Deoxys who took a DNA test? It got 100%!","What would the tier leader of OU be called if he was a Jirachi? Flinchinator!","I had a company that sold Infernapes, until I was told to cut out the monkey business!","Kricketunes must be my biggest fans. Every time I tell a joke, they're all I hear!","What kind of Poké Ball is best for Luxray? A Luxuray Ball!","Where does Bastiodon make all its money? Wall Street!","What kind of mystery novels does Wormadam like to read? Cloak and dagger!","Remember when Pachirisu won the World Championships? That was nuts!","Cherrim? I hardly know 'im!","Mothim? I hardly know 'im!","I used to buy Drifblim by the dozen, but we got hit with inflation and the price ballooned!","I took directions from a Mismagius, but now I don't know witch way to go!","Someone asked me if I liked Chingling. I said that I don't know, I've never chingled!","What do you do with a Bronzong you're in love with? Give it a ring!","People say they removed Chatot's sound-recording function because of profanity, but I think that's just mindless Chatter!","I have 108 jokes about Spiritomb, but not a single soul wants to hear them!","My Garchomp friend gained a lot of weight recently. He said it was pretty rough to look at the scales!","Why does Carnivine get Levitate? Because it's a Venus flying trap!","Why did Weavile drive a truck with six wheels? Because it had Triple Axles!","I got yelled at by a Lickilicky once. Talk about a tongue-lashing!","Why do they call Yanmega a dragonfly when it isn't Dragon/Flying?","My local arcade had to kick out this Ground/Flying type. He kept getting the Gligh-score and he was really toxic about it!","Why don't you ever see Mamoswines hiding in trees? Because they're really good at it!","What happens when your Porygon-Z uses Signal Beam? Software bugs!","What do you call a Gallade in a tuxedo? Sharply dressed!","Why do they call Rotom-Heat an oven when you of in the cold food of out hot eat the food?","Why does no one tell Rotom-Wash their secrets? They don't want it to air out their dirty laundry!","I had a joke about Uxie, but I forgot it!","I had a joke about Mesprit, but I don't think you're emotionally ready for it!","I had a joke about Azelf, but I don't have the willpower to tell it!","I had a joke about Dialga and time travel, but you didn't like it!","I had a joke about Palkia, but there's no space for it here!","Why couldn't Arceus go to Planet Fitness? Because it's a Judgment-free zone!","I had a joke about the Azure Flute, but you wouldn't get it!","Why does Victini always win? Beats me!","Some people think Overgrow is viable on Serperior. On the Contrary!","Once Samurott got a regional form, its usage really Spiked!","Did you hear about the Watchog that won a battle? Yeah, me neither!","I could tell a joke about Musharna, but I wouldn't dream of it!","Why does Throh never win? Because it always throws!","Cofagrigus is so cool! Don't you *cough* agree, Gus?","I wouldn't use Zoroark in OU—I have no Illusion that it's any good!","Why is Reuniclus so good at marketing? It knows what cells!","Why didn't the Ducklett evolve? It didn't Swanna!","I fought a Beartic once. It was unbearable!","Did you know it's a crime to make a Braviary sick? It's ill-eagle!","I attract Volcaronas like a moth to a flame!","I'd make a joke about Cobalion, but it's un-Justified!","What did Zekrom do when it was unhappy with its working conditions? It went on Bolt Strike!","Everyone plays Meloetta in exactly the same way. It's always the same old song and dance!","What's a Chesnaught's favorite Nature? Naughty!","Which part of Doublade is most dangerous? Da blade!","I'd say I'm a Pyroar, but I'd be lion!","Why does Talonflame laugh in the face of danger? Because it's a Brave Bird!","I stole a Delphox's wand, but it got me in a stick-y situation!","What are Aegislash's favorite Pokémon games? Sword and Shield!","What do you call it when you do a favor for a Malamar and it wants one in return? Squid pro quo!","I'm making an 8-bit game featuring Sylveon. It looks cute when it's Pixilated!","Why did Tyrantrum get its license taken away? It kept getting in T-wrecks!","Why does Goodra have such good fashion sense? Because it's always got the drip!","What do you get when you cross a Kingambit with a Gourgeist? Supreme Overgourd!","What do you call a dead Klefki? A skeleton key!","I dated a Xerneas once, but we broke up. Now it's my X!","I've never met an Yveltal. I don't know Y!","Why does Zygarde-Complete work so hard? Because it always gives 100%!","Why does Diancie have such good synergy with Ghost-types? Because diamonds are a ghoul's best friend!","What's Hoopa's favorite video game? Portal!","Why did Hoopa-Unbound get put into the Prison Bottle? Because it was armed and dangerous!","What do you call a joke about Volcanion? A wisecrack-a-toa!","Why does no one make friends with Incineroar? It's too Intimidating!","Can a Toucannon win a Double Battle? No, but two can!","What do you call your Lycanroc when it goes missing? A where-wolf!","Why are Wishiwashi so smart? They swim in schools!","What do you call it when Ribombee gets a free turn? A sticky situation!","Why are Mudsdales so strong? They have horsepower!","What's Araquanid's favorite candy? Bubble gum!","I had a Salazzle girlfriend once, but I broke it off because she was too toxic!","Why do they call it Comfey when every time someone sends it out it becomes the most stressful game of my life?","Why did the Golisopod make an emergency exit from the job interview? It made a bad First Impression!","I'm making a first-person shooting game starring Pyukumuku. It's called Duke Pyukem!","Why should you never mimic a Mimikyu? Because you're risking your neck!","Where in Alaska can you find Dhelmise? Anchorage!","Did you know that Kommo-o's scales are falling off all across the globe? It's a problem on a worldwide scale!","A Tapu Lele walks into a bar. The bartender gets nervous because there's no counter!","Did you hear that Tapu Fini's terrain is gone? It'll be mist!","Did you hear Lunala opened up a barber shop? It's called Totally Clips!","If OU doesn't suspect test Solgaleo, I'm going to go on Sunsteel Strike!","I heard they buffed Buzzwole in Pokémon Unite. I don't know why they needed to, it was already buff!","I want to ask Pheromosa out, but it strikes me as unapp-roach-able!","What do you call a Xurkitree that's only 3 feet tall? A short circuit!","What does Celesteela order when it goes to a Chinese restaurant? One-ton soup!","Why should you never invite a Kartana to poker night? Because it always knows when to fold!","Why did the Guzzlord love doing difficult jobs? Because it was a glutton for punishment!","What happened to the Necrozma that robbed a bank? It was in-prismed!","Why does Ultra Necrozma weigh less that Dusk Mane or Dawn Wings form? Because it's more light!","What attack does Stakataka learn at Level 1? Stakatackle!","Why is Blacephalon's head spherical? Because it's clowning a-round!","What is Inteleon's secret agent number? Bubble-O-7!","I'll be here all Corvi-night, folks!","What Bug/Psychic Pokémon can be found deep underground embedded in stone? Ore-beetle!","Why should you never give a Drednaw the Infinity Gauntlet? Because it's a snapping turtle!","A Flapple a day keeps the doctor away, as long as its attacks don't miss!","Why are my jokes so popular on Galar's Route 8? Because Sandaconda don't want none unless you got puns, hun!","My Cramorant was about to win a match, but then it choked!","What's Toxtricity's favorite Tera type? Rock!","Why does Centiskorch hate wearing Heavy-Duty Boots? By the time it's finished putting them all on, the battle's already over!","I've heard a lot of gossip about Polteageist, but I don't want to spill the tea!","Who hosts tea parties in Wonderland and bounces back hazard moves? The Mad Hatterene!","What kind of fur do you get from Grimmsnarl? As fur away as possible!","Of all the crimes Obstagoon's done, which one finally put it behind bars for good? Obstruction of justice!","Where do Cursola keep their gravestones? At the Great Burial Reef!","How does Sirfetch'd pass along all the insider info it knows about new Pokémon games? It leeks it!","What did the Mr. Mime say to the Mr. Rime? Nothing, silly, mimes can't talk!","I'd tell a joke about Runerigus, but the real joke is its evolution method!","Plenty of Pokémon have ridiculous numbers of alternate forms, but Alcremie takes the cake!","Can any Pokémon besides Tapu Lele set Psychic Terrain? Yes Indeedee!","What's a Copperajah's favorite kind of music? Heavy Metal!","Why did Dracovish get evicted from OU? It wouldn't pay the Fishious Rent!","Have you seen Duraludon's Gigantamax form? It really towers over you!","What's Dragapult's favorite game to play at a bar? Dragon Darts!","I'd tell you a joke about Zamazenta, but I'm pressed for time!","Why should you always run Zacian-Crowned? Because it has great STAB!","Originally the Gen 8 designers weren't going to add a generational mechanic, but Eternatus convinced them to make Dynamax canon!","What does Regieleki do to lose weight? Fast!","What do you get when you cross a Regidrago and a Klefki? Lockjaw!","I'd make a joke about Spectrier, but that would be beating a dead horse!","Make sure to never insult Ursaluna—last time I burned it, it swept my whole team!","Don't go near Ursaluna-Bloodmoon—it's a total lunatic!","You'd think Basculegion would be uncomfortable traveling forward in time hundreds of years, but don't worry—it's adaptable!","You have to use Strong Style Barb Barrage 20 times to evolve Hisuian Qwilfish? That seems like Overqwil to me!","Did you know that Meowscarada is really good at baking bread? Apparently it has a special Flour Trick!","I've got a ton of Skeledirge jokes. A skele-ton!","What do you do if you see a Quaquaval getting ready to kick you in the head? Duck!","Lokix? No thanks, I don't like using weight-based moves!","Why did the baker get a Fidough? He kneaded one!","How do you know Dachsbun has a good pedigree? It's pure bread!","Why did the Garganacl ragequit while losing a battle? Because it was salty!","You're telling me Ceruledge has dark purple armor and blue flaming swords for hands? What an edgelord!","You should try using Electromorphosis Bellibolt—its damage output is shocking!","I tried using Klawf on a stall team, but it was Klawful!","Rabsca told me its true body was inside the ball it's holding. I thought that was a load of crap!","My Shellder once spent time with an Espathra. It came back with a new Ability just called Link because Espathra takes no skill!","Why is Corviknight's natural predator so smart? Because she Thinks-a-ton!","I asked a Finizen why it worked as a sidekick for Palafin. The Finizen said it was serving a greater porpoise!","If you run in front of a Revavroom you get tired, but if you run behind it you get exhausted!","Why couldn't the Cyclizar stand up? It was two-tired!","Why does Houndstone press F? To pay its Last Respects!","Those entry hazards are nice, why not put up Glim-more-a' them?","Why did Dondozo get demonetized on YouTube? It wouldn't stop cursing!","Have you heard the joke about Farigiraf's neck? It's a long one!","What do you call a Dudunsparce that gets faster when it's hit with a Dark move? A Rattled-snake!","What do you call a Dunsparce? No, really, I'm curious.","Why do people love Donphan so much? Because it has Great Tusks!","What do you get when you cross Kingambit and Ogerpon? The Supreme Ogrelord!","What did ancient Magneton economists invest in? Sandy Stocks!","I'm starting a band featuring Slither Wing. It's called Smash Moth!","Why does the Paldean alphabet go L, M, N, Flutter Mane, Q, R? Because Flutter Mane is OP!","What did Iron Bundle's mother say when it went out in the cold? Bundle up, and be sure to cover everything!","Iron Hands is a fantastic Pokémon. Let's all give it a great big hand!","What should you do if an Iron Treads uses Autotomize? Tread lightly!","What Paradox Pokémon do you like to run? Personally, I run Thorns!","What kind of computers does Wo-Chien like to use? Tablets!","Man, that Chien-Pao OHKOing me Sword of Ruined my day!","When I saw my special attacks doing 25% less damage than usual, I knew there was some-Ting wrong!","What do you call a really old Salamence telling a really dull story? Boring Moon!","I once visited Chi-Yu's home, but it had no walls!","I don't know what the Iron Valiant set is until I look inside the box, but I can't—it's impossible to check!","Why is Miraidon banned to AG? Because it's from the future, so it's not allowed to be present!","I once met a Koraidon, so I turned around and said that the past is behind me!","What's the opposite of Walking Wake? Sleepwalking!","What does Sinistcha wear on St. Patrick's Day? A green tea-shirt!","Why are the Loyal Three always male? Toxic masculinity!","One of Ogerpon's forms got banned, but it was pretty controversial on the Internet. It started a Hearth-flame war!","You don't like Archaludon? Too bad, build a bridge and get over it!","What move can only be used by a Hydrapple that's been fermented in brine? Pickle Beam!","Why is Raging Bolt so delusional? Because it's got its head in the clouds!","Iron Boulder? Boulders aren't made of iron, silly!","Iron Crown? But my crown isn't wrinkled!","I hear Terapagos got banned from OU in less than a day. It must've had a Stellar performance!","I'd make a joke about Pecharunt's poison, but it's too confusing!","How many Pokémon fans does it take to change a lightbulb? None, they just complain about how much better the last lightbulb was!","That's the last time I try to make a call in winter, I'm getting a Chilly Reception!","Maybe I should tell spicier jokes and go for a Chili Reception instead!","Did you hear the one about the Slowking who switched out?","You've heard of stand-up comedy, but have you heard of switch-out comedy?","You bought those fossils from Clay? Did you buy them on Clay-away?","How do you get a Trainer onto a bus? Poke 'em on!","U-Turn? No, YOU turn, I'm going straight!","Does Gen 1 have a Pokémon missing? No!"];var _battle=this.scene.battle;var joke=dadJokes[((_battle.p1.name.charCodeAt(2)||0)+(_battle.p2.name.charCodeAt(2)||0)*19+(_battle.p1.name.charCodeAt(3)||0)*61+(_battle.p2.name.charCodeAt(3)||0)+_battle.turn+(args[1].charCodeAt(1)||0)*109+(args[1].charCodeAt(2)||0)*113)%dadJokes.length];messageFromArgs(args,kwArgs);this.messageFromLog("\""+joke+"\"");this.scene.wait(3*this.scene.battle.messageFadeTime/this.scene.acceleration);return true;}}if(Dex.afdMode!==true)return;if(args[0]==='faint'){if(!Dex.afdFaint){messageFromArgs(args,kwArgs);this.message('<div class="broadcast-red" style="font-size:10pt">Needed that one alive? Buy <strong>Max Revive DLC</strong>, yours for only $9.99!<br /> <a href="/trustworthy-dlc-link">CLICK HERE!</a></div>');Dex.afdFaint=true;return true;}}else if(args[0]==='-crit'){if(!Dex.afdCrit){messageFromArgs(args,kwArgs);this.message('<div class="broadcast-red" style="font-size:10pt">Crit mattered? Buy <strong>Crit Insurance DLC</strong>, yours for only $4.99!<br /> <a href="/trustworthy-dlc-link">CLICK HERE!</a></div>');Dex.afdCrit=true;return true;}}else if(args[0]==='move'){if(kwArgs.from)return false;var _moveid2=toID(args[2]);if(_moveid2==='earthquake'){if(this.scene.animating&&window.$){$('body').css({position:'absolute',left:0,right:0,top:0,bottom:0}).animate({left:-30,right:30},75).animate({left:30,right:-30},100).animate({left:-30,right:30},100).animate({left:30,right:-30},100).animate({left:0,right:0},100,function(){$('body').css({position:'static'});});}messageFromArgs(['move',args[1],'Fissure']);this.messageFromLog('Just kidding! It was **Earthquake**!');return true;}else if(_moveid2==='stealthrock'){var srNames=['Sneaky Pebbles','Sly Rubble','Subtle Sediment','Buried Bedrock','Camouflaged Cinnabar','Clandestine Cobblestones','Cloaked Clay','Concealed Ore','Covert Crags','Crafty Coal','Discreet Bricks','Disguised Debris','Espionage Pebbles','Furtive Fortress','Hush-Hush Hardware','Incognito Boulders','Invisible Quartz','Masked Minerals','Mischievous Masonry','Obscure Ornaments','Private Paragon','Secret Solitaire','Sheltered Sand','Surreptitious Sapphire','Undercover Ultramarine'];messageFromArgs(['move',args[1],srNames[Math.floor(Math.random()*srNames.length)]]);return true;}else if(_moveid2==='extremespeed'){messageFromArgs(args,kwArgs);var fastWords=['H-Hayai','Masaka','Its fast'];this.messageFromLog("**"+fastWords[Math.floor(Math.random()*fastWords.length)]+"**");return true;}else if(_moveid2==='aerialace'){messageFromArgs(['move',args[1],'Tsubame Gaeshi']);return true;}}return false;};_proto.messageFromLog=function messageFromLog(line){this.message.apply(this,BattleLog.parseLogMessage(line));};_proto.turnText=function turnText(turnNum){var _this$battleParser2;var turnMessage=(_this$battleParser2=this.battleParser)==null?void 0:_this$battleParser2.parseArgs(['turn',turnNum],{},true).trim();if(!(turnMessage!=null&&turnMessage.startsWith('=='))||!turnMessage.endsWith('==')){return"Turn "+turnNum;}return turnMessage.slice(2,-2).trim();};_proto.textList=function textList(list){var listNoDuplicates=[];for(var _i2=0;_i2<list.length;_i2++){var user=list[_i2];if(!listNoDuplicates.includes(user))listNoDuplicates.push(user);}return TL.cappedUserList(listNoDuplicates,5);};BattleLog.parseLogMessage=function parseLogMessage(message){var messages=message.split('\n').map(function(line){line=BattleLog.escapeHTML(line);line=line.replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>');line=line.replace(/\|\|([^|]*)\|\|([^|]*)\|\|/,'<abbr title="$1">$2</abbr>');if(line.startsWith('  '))line='<small>'+line.trim()+'</small>';return line;});return[messages.join('<br />'),messages.filter(function(line){return!line.startsWith('<small>[');}).join('<br />')];};_proto.message=function message(_message){var _this$scene3;var sceneMessage=arguments.length>1&&arguments[1]!==undefined?arguments[1]:_message;(_this$scene3=this.scene)==null||_this$scene3.message(sceneMessage);this.addDiv('battle-history',_message);};_proto.addNode=function addNode(node,preempt){(preempt?this.preemptElem:this.innerElem).appendChild(node);if(this.atBottom){this.elem.scrollTop=this.elem.scrollHeight;}};_proto.
addDiv=function addDiv(className,innerHTML,preempt){
var el=document.createElement('div');
el.className=className;
el.innerHTML=innerHTML;
this.addNode(el,preempt);
};_proto.
prependDiv=function prependDiv(className,innerHTML,preempt){
var el=document.createElement('div');
el.className=className;
el.innerHTML=innerHTML;
if(this.innerElem.childNodes.length){
this.innerElem.insertBefore(el,this.innerElem.childNodes[0]);
}else{
this.innerElem.appendChild(el);
}
this.updateScroll();
};_proto.
addSpacer=function addSpacer(){
this.addDiv('spacer battle-history','<br />');
};_proto.
changeUhtml=function changeUhtml(id,htmlSrc,forceAdd){
id=toID(id);
var classContains=' uhtml-'+id+' ';
var elements=[];for(var _i4=0,_this$innerElem$child2=
this.innerElem.childNodes;_i4<_this$innerElem$child2.length;_i4++){var node=_this$innerElem$child2[_i4];
if(node.className&&(' '+node.className+' ').includes(classContains)){
elements.push(node);
}
}
if(this.preemptElem){for(var _i6=0,_this$preemptElem$chi2=
this.preemptElem.childNodes;_i6<_this$preemptElem$chi2.length;_i6++){var _node=_this$preemptElem$chi2[_i6];
if(_node.className&&(' '+_node.className+' ').includes(classContains)){
elements.push(_node);
}
}
}
if(htmlSrc&&elements.length&&!forceAdd){for(var _i8=0;_i8<
elements.length;_i8++){var element=elements[_i8];
element.innerHTML=BattleLog.sanitizeHTML(htmlSrc);
}
this.updateScroll();
return;
}for(var _i10=0;_i10<
elements.length;_i10++){var _element=elements[_i10];
_element.parentElement.removeChild(_element);
}
if(!htmlSrc)return;
if(forceAdd){
this.addDiv('notice uhtml-'+id,BattleLog.sanitizeHTML(htmlSrc));
}else{
this.prependDiv('notice uhtml-'+id,BattleLog.sanitizeHTML(htmlSrc));
}
};_proto.
hideChatFrom=function hideChatFrom(userid){var showRevealButton=arguments.length>1&&arguments[1]!==undefined?arguments[1]:true;var lineCount=arguments.length>2&&arguments[2]!==undefined?arguments[2]:0;
var classStart='chat chatmessage-'+userid+' ';
var nodes=[];
var buttonContainer=this.innerElem.lastChild;for(var _i12=0,_this$innerElem$child4=
this.innerElem.childNodes;_i12<_this$innerElem$child4.length;_i12++){var node=_this$innerElem$child4[_i12];
if(node.className&&(node.className+' ').startsWith(classStart)){
nodes.push(node);
}
}
if(this.preemptElem){for(var _i14=0,_this$preemptElem$chi4=
this.preemptElem.childNodes;_i14<_this$preemptElem$chi4.length;_i14++){var _node2=_this$preemptElem$chi4[_i14];
if(_node2.className&&(_node2.className+' ').startsWith(classStart)){
nodes.push(_node2);
}
}
}
if(lineCount)nodes=nodes.slice(-lineCount);for(var _i16=0,_nodes2=

nodes;_i16<_nodes2.length;_i16++){var _node3=_nodes2[_i16];
_node3.style.display='none';
_node3.className='revealed '+_node3.className;
}
if(!nodes.length||!showRevealButton)return;
var button=document.createElement('button');
button.name='toggleMessages';
button.setAttribute('data-cmd','/togglemessages '+userid);
button.value=userid;
button.className='subtle';
var hiddenCount=nodes.length;
var hiddenText=hiddenCount===1?
TL(["("," line from "," hidden)"],hiddenCount,userid):
TL(["("," lines from "," hidden)"],hiddenCount,userid);
button.innerHTML="<small>"+hiddenText+"</small>";
if(
!buttonContainer||!(" "+buttonContainer.className+" ").includes(' chat ')||
buttonContainer.style.display==='none')
{
buttonContainer=document.createElement('div');
buttonContainer.className='chat';
this.addNode(buttonContainer);
}
buttonContainer.appendChild(document.createTextNode(' '));
buttonContainer.appendChild(button);
};BattleLog.

unlinkNodeList=function unlinkNodeList(nodeList){for(var _i18=0;_i18<
nodeList.length;_i18++){var node=nodeList[_i18];
var linkList=node.getElementsByTagName('a');

for(var i=linkList.length-1;i>=0;i--){
var linkNode=linkList[i];
var parent=linkNode.parentElement;
if(!parent)continue;for(var _i20=0,_linkNode$childNodes2=
linkNode.childNodes;_i20<_linkNode$childNodes2.length;_i20++){var childNode=_linkNode$childNodes2[_i20];
parent.insertBefore(childNode,linkNode);
}
parent.removeChild(linkNode);
}
}
};_proto.

unlinkChatFrom=function unlinkChatFrom(userid){


var nodeList=document.getElementsByClassName('chatmessage-'+userid);
BattleLog.unlinkNodeList(nodeList);
};_proto.

preemptCatchup=function preemptCatchup(){
if(!this.preemptElem.firstChild)return;
this.innerElem.appendChild(this.preemptElem.firstChild);
};BattleLog.

escapeFormat=function escapeFormat(){var formatid=arguments.length>0&&arguments[0]!==undefined?arguments[0]:'';var fixGen6=arguments.length>1?arguments[1]:undefined;
var atIndex=formatid.indexOf('@@@');
if(atIndex>=0){
var customRules=this.escapeHTML(formatid.slice(atIndex+3));
return this.escapeHTML(this.formatName(formatid.slice(0,atIndex),fixGen6))+
'<br />'+TL.label(TL('Custom rules'),customRules);
}
return this.escapeHTML(this.formatName(formatid,fixGen6));
};BattleLog.
formatId=function formatId(format){
var atIndex=format.indexOf('@@@');
if(atIndex>=0){
format=toID(format.slice(0,atIndex))+format.slice(atIndex).trim();
}else{
format=toID(format);
}
if(!format)return'';
if(!format.startsWith('gen'))format=""+Dex.modid+format;
return format;
};BattleLog.




formatName=function formatName(){var formatid=arguments.length>0&&arguments[0]!==undefined?arguments[0]:'';var fixGen6=arguments.length>1?arguments[1]:undefined;
if(!formatid)return'';

var atIndex=formatid.indexOf('@@@');
if(atIndex>=0){
return this.formatName(formatid.slice(0,atIndex),fixGen6)+
' (Custom rules: '+this.escapeHTML(formatid.slice(atIndex+3))+')';
}
if(fixGen6&&!formatid.startsWith('gen')){
formatid="gen6"+formatid;
}
var name=formatid;
if(window.BattleFormats&&BattleFormats[formatid]){
name=BattleFormats[formatid].name;
}
if(window.NonBattleGames&&NonBattleGames[formatid]){
name=NonBattleGames[formatid];
}
if(name.startsWith('gen')){
name=name.replace(/^gen([0-9])/,'[Gen $1] ');
}
if(name.startsWith("[Gen "+Dex.gen+"] ")){
name=name.slice(("[Gen "+Dex.gen+"] ").length);
}else if(name.startsWith("[Gen "+Dex.gen+" ")){
name='['+name.slice(("[Gen "+Dex.gen+" ").length);
}
return name||"[Gen "+Dex.gen+"]";
};BattleLog.

escapeHTML=function escapeHTML(str,jsEscapeToo){
if(typeof str==='number')str=""+str;
if(typeof str!=='string')return'';
str=str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
if(jsEscapeToo)str=str.replace(/\\/g,'\\\\').replace(/'/g,'\\\'');
return str;
};BattleLog.
unescapeHTML=function unescapeHTML(str){
str=str?''+str:'';
return str.replace(/&quot;/g,'"').replace(/&gt;/g,'>').replace(/&lt;/g,'<').replace(/&amp;/g,'&');
};BattleLog.

roomidToFormat=function roomidToFormat(id){var _exec2;
if(id.lastIndexOf('-')>6){var _exec;
return(_exec=/^battle-([a-z0-9]*)-?[0-9]*$/.exec(id))==null?void 0:_exec[1];
}
return(_exec2=/^battle-([a-z0-9]*[a-z])[0-9]*$/.exec(id))==null?void 0:_exec2[1];
};BattleLog.




hashColor=function hashColor(name){
return"color:"+this.usernameColor(name)+";";
};BattleLog.

usernameColor=function usernameColor(name){
if(this.colorCache[name])return this.colorCache[name];
var hash;
if(Config.customcolors[name]){
hash=MD5(Config.customcolors[name]);
}else{
hash=MD5(name);
}
var H=parseInt(hash.substr(4,4),16)%360;
var S=parseInt(hash.substr(0,4),16)%50+40;
var L=Math.floor(parseInt(hash.substr(8,4),16)%20+30);

var _this$HSLToRGB=this.HSLToRGB(H,S,L),R=_this$HSLToRGB.R,G=_this$HSLToRGB.G,B=_this$HSLToRGB.B;
var lum=R*R*R*0.2126+G*G*G*0.7152+B*B*B*0.0722;

var HLmod=(lum-0.2)*-150;
if(HLmod>18)HLmod=(HLmod-18)*2.5;else
if(HLmod<0)HLmod/=3;else
HLmod=0;

var Hdist=Math.min(Math.abs(180-H),Math.abs(240-H));
if(Hdist<15){
HLmod+=(15-Hdist)/3;
}

L+=HLmod;

var _this$HSLToRGB2=this.HSLToRGB(H,S,L),r=_this$HSLToRGB2.R,g=_this$HSLToRGB2.G,b=_this$HSLToRGB2.B;
var toHex=function(x){
var hex=Math.round(x*255).toString(16);
return hex.length===1?'0'+hex:hex;
};
this.colorCache[name]="#"+toHex(r)+toHex(g)+toHex(b);
return this.colorCache[name];
};BattleLog.

HSLToRGB=function HSLToRGB(H,S,L){
var C=(100-Math.abs(2*L-100))*S/100/100;
var X=C*(1-Math.abs(H/60%2-1));
var m=L/100-C/2;

var R1;
var G1;
var B1;
switch(Math.floor(H/60)){
case 1:R1=X;G1=C;B1=0;break;
case 2:R1=0;G1=C;B1=X;break;
case 3:R1=0;G1=X;B1=C;break;
case 4:R1=X;G1=0;B1=C;break;
case 5:R1=C;G1=0;B1=X;break;
case 0:default:R1=C;G1=X;B1=0;break;
}
var R=R1+m;
var G=G1+m;
var B=B1+m;
return{R:R,G:G,B:B};
};BattleLog.

prefs=function prefs(name){var _window$Storage;

if((_window$Storage=window.Storage)!=null&&_window$Storage.prefs)return Storage.prefs(name);

if(window.PS)return PS.prefs[name];

return undefined;
};_proto.

renderName=function renderName(name){
var group=' ';
if(!/[A-Za-z0-9]/.test(name.charAt(0))){

group=name.charAt(0);
name=name.slice(1);
}
var clickableName="<span class=\"username\"><small class=\"groupsymbol\">"+BattleLog.escapeHTML(group)+"</small>"+BattleLog.escapeHTML(name)+"</span>";
return clickableName;
};_proto.
parseChatMessage=function parseChatMessage(
message,name,timestamp,isHighlighted)
{var _BattleLog$prefs,_window$app6,_window$PS5;
var showMe=!((_BattleLog$prefs=BattleLog.prefs('chatformatting'))!=null&&_BattleLog$prefs.hideme);
var userid=toID(name);
var colorStyle=" style=\"color:"+BattleLog.usernameColor(userid)+"\"";
var clickableName=this.renderName(name);
var isMine=((_window$app6=window.app)==null||(_window$app6=_window$app6.user)==null?void 0:_window$app6.get('userid'))===userid||((_window$PS5=window.PS)==null?void 0:_window$PS5.user.userid)===userid;
var hlClass=isHighlighted?' highlighted':'';
var mineClass=isMine?' mine':'';

var cmd='';
var target='';
if(message.startsWith('/')){
if(message.charAt(1)==='/'){
message=message.slice(1);
}else{
var spaceIndex=message.indexOf(' ');
cmd=spaceIndex>=0?message.slice(1,spaceIndex):message.slice(1);
if(spaceIndex>=0)target=message.slice(spaceIndex+1);
}
}

switch(cmd){
case'me':
case'mee':
var parsedMessage=BattleLog.parseMessage(' '+target);
if(cmd==='mee')parsedMessage=parsedMessage.slice(1);
if(!showMe){
return[
'chat chatmessage-'+userid+hlClass+mineClass,
timestamp+"<strong"+colorStyle+">"+clickableName+":</strong> <em>/me"+parsedMessage+"</em>"];

}
return[
'chat chatmessage-'+userid+hlClass+mineClass,
timestamp+"<em><i><strong"+colorStyle+">&bull; "+clickableName+"</strong>"+parsedMessage+"</i></em>"];

case'invite':
var roomid=toRoomid(target);
var inviteMessage=TL([""," invited you to join the room \"","\""],clickableName,roomid);
return[
'chat',
timestamp+"<em>"+inviteMessage+"</em>"+("<div class=\"notice\"><button class=\"button\" name=\"joinRoom\" value=\""+
roomid+"\">"+TL(["[Join ","]"],roomid)+"</button></div>")];

case'announce':
return[
'chat chatmessage-'+userid+hlClass+mineClass,
timestamp+"<strong"+colorStyle+">"+clickableName+":</strong> <span class=\"message-announce\">"+BattleLog.parseMessage(target)+"</span>"];

case'log':
return[
'chat chatmessage-'+userid+hlClass+mineClass,
timestamp+"<span class=\"message-log\">"+BattleLog.parseMessage(target)+"</span>"];

case'data-pokemon':
case'data-item':
case'data-ability':
case'data-move':
return['chat message-error','[outdated code no longer supported]'];
case'text':
return['chat',BattleLog.parseMessage(target),true];
case'error':
return['chat message-error',formatText(target,true)];
case'html':
if(!userid){
return[
'chat'+hlClass,
timestamp+"<em>"+BattleLog.sanitizeHTML(target)+"</em>"];

}
return[
'chat chatmessage-'+userid+hlClass+mineClass,
timestamp+"<strong"+colorStyle+">"+clickableName+":</strong> <em>"+BattleLog.sanitizeHTML(target)+"</em>"];

case'uhtml':
case'uhtmlchange':
var parts=target.split(',');
var htmlSrc=parts.slice(1).join(',').trim();
this.changeUhtml(parts[0],htmlSrc,cmd==='uhtml');
return['',''];
case'raw':
return['chat',BattleLog.sanitizeHTML(target),true];
case'nonotify':
return['chat',BattleLog.sanitizeHTML(target),true];
case'subtlenotify':
return['chat',BattleLog.sanitizeHTML(target),'subtle'];
default:

if(!userid){
return[
'chat'+hlClass,
timestamp+"<em>"+BattleLog.parseMessage(message)+"</em>"];

}
return[
'chat chatmessage-'+userid+hlClass+mineClass,
timestamp+"<strong"+colorStyle+">"+clickableName+":</strong> <em>"+BattleLog.parseMessage(message)+"</em>"];

}
};BattleLog.

parseMessage=function parseMessage(str){var isTrusted=arguments.length>1&&arguments[1]!==undefined?arguments[1]:false;

if(str.substr(0,3)==='>> '||str.substr(0,4)==='>>> ')return this.escapeHTML(str);

if(str.substr(0,3)==='<< ')return this.escapeHTML(str);
str=formatText(str,isTrusted);

var options=BattleLog.prefs('chatformatting')||{};

if(options.hidelinks){
str=str.replace(/<a[^>]*>/g,'<u>').replace(/<\/a>/g,'</u>');
}
if(options.hidespoiler){
str=str.replace(/<span class="spoiler">/g,'<span class="spoiler-shown">');
}
if(options.hidegreentext){
str=str.replace(/<span class="greentext">/g,'<span>');
}

return str;
};BattleLog.


























initSanitizeHTML=function initSanitizeHTML(){var _this4=this;
if(this.tagPolicy)return;
if(!('html4'in window)){
throw new Error('sanitizeHTML requires caja');
}



Object.assign(html4.ELEMENTS,{
marquee:0,
blink:0,
psicon:html4.eflags['OPTIONAL_ENDTAG']|html4.eflags['EMPTY'],
username:0,
spotify:0,
youtube:0,
formatselect:0,
copytext:0,
twitch:0
});



Object.assign(html4.ATTRIBS,{

'marquee::behavior':0,
'marquee::bgcolor':0,
'marquee::direction':0,
'marquee::height':0,
'marquee::hspace':0,
'marquee::loop':0,
'marquee::scrollamount':0,
'marquee::scrolldelay':0,
'marquee::truespeed':0,
'marquee::vspace':0,
'marquee::width':0,
'psicon::pokemon':0,
'psicon::item':0,
'psicon::type':0,
'selectformat::type':0,
'psicon::category':0,
'username::name':0,
'form::data-submitsend':0,
'formatselect::format':0,
'div::data-server':0,
'button::data-send':0,
'button::data-cmd':0,
'form::data-delimiter':0,
'button::data-delimiter':0,
'*::aria-label':0,
'*::aria-hidden':0
});



















this.tagPolicy=function(tagName,attribs){
if(html4.ELEMENTS[tagName]&html4.eflags['UNSAFE']){
return;
}

function getAttrib(key){
for(var i=0;i<attribs.length-1;i+=2){
if(attribs[i]===key){
return attribs[i+1];
}
}
return undefined;
}
function setAttrib(key,value){
for(var i=0;i<attribs.length-1;i+=2){
if(attribs[i]===key){
attribs[i+1]=value;
return;
}
}
attribs.push(key,value);
}
function deleteAttrib(key){
for(var i=0;i<attribs.length-1;i+=2){
if(attribs[i]===key){
attribs.splice(i,2);
return;
}
}
}

var dataUri='';
var targetReplace=false;

var unsanitizedStyle='';

if(tagName==='a'){
if(getAttrib('target')==='replace'){
targetReplace=true;
}
}else if(tagName==='img'){
var src=getAttrib('src')||'';
if(src.startsWith('data:image/')){
dataUri=src;
}
if(src.startsWith('//')){
if(location.protocol!=='http:'&&location.protocol!=='https:'){

setAttrib('src','https:'+src);
}
}
}else if(tagName==='twitch'){var _exec3;

var _src=getAttrib('src')||"";
var channelId=(_exec3=/(https?:\/\/)?twitch.tv\/([A-Za-z0-9]+)/i.exec(_src))==null?void 0:_exec3[2];
var height=parseInt(getAttrib('height')||"",10)||400;
var width=parseInt(getAttrib('width')||"",10)||340;
return{
tagName:'iframe',
attribs:[
'src',"https://player.twitch.tv/?channel="+channelId+"&parent="+location.hostname+"&autoplay=false",
'allowfullscreen','true','height',""+height,'width',""+width]

};
}else if(tagName==='username'){

tagName='strong';
var color=_this4.usernameColor(toID(getAttrib('name')));
unsanitizedStyle="color:"+color;
}else if(tagName==='spotify'){var _exec4;

var _src2=getAttrib('src')||'';
var songId=(_exec4=/(?:\?v=|\/track\/)([A-Za-z0-9]+)/.exec(_src2))==null?void 0:_exec4[1];

return{
tagName:'iframe',
attribs:['src',"https://open.spotify.com/embed/track/"+songId,'width','300','height','380','frameborder','0','allowtransparency','true','allow','encrypted-media']
};
}else if(tagName==='youtube'){var _exec5,_exec6;


var _src3=getAttrib('src')||'';

var _width=getAttrib('width')||'0';
var _height=getAttrib('height')||'0';
if(Number(_width)<200){
_width=window.innerWidth>=400?'400':'320';
}
if(Number(_height)<200){
_height=window.innerWidth>=400?'225':'200';
}
var videoId=(_exec5=/(?:\?v=|\/embed\/)([A-Za-z0-9_-]+)/.exec(_src3))==null?void 0:_exec5[1];
if(!videoId)return{tagName:'img',attribs:['alt',"invalid src for <youtube>"]};

var time=(_exec6=/(?:\?|&)(?:t|start)=([0-9]+)/.exec(_src3))==null?void 0:_exec6[1];
_this4.players.push(null);
var idx=_this4.players.length;
_this4.initYoutubePlayer(idx);
return{
tagName:'iframe',
attribs:[
'id',"youtube-iframe-"+idx,
'width',_width,'height',_height,
'src',"https://www.youtube.com/embed/"+videoId+"?enablejsapi=1&playsinline=1"+(time?"&start="+time:''),
'frameborder','0','allow','accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture','allowfullscreen','allowfullscreen',
'time',""+(time||0)]

};
}else if(tagName==='formatselect'){
return{
tagName:'button',
attribs:[
'data-select','selectformat',
'class',"select formatselect",
'value',getAttrib('format')||getAttrib('value')||'',
'name',getAttrib('name')||'']

};
}else if(tagName==='copytext'){
return{
tagName:'button',
attribs:[
'type',getAttrib('type'),
'class',getAttrib('class')||'button',
'value',getAttrib('value'),
'name','copyText']

};
}else if(tagName==='psicon'){


var iconType=null;
var iconValue=null;
for(var i=0;i<attribs.length-1;i+=2){
if(attribs[i]==='pokemon'||attribs[i]==='item'||attribs[i]==='type'||attribs[i]==='category'){var _attribs$slice=
attribs.slice(i,i+2);iconType=_attribs$slice[0];iconValue=_attribs$slice[1];
break;
}
}
tagName='span';

if(iconType){
var className=getAttrib('class');

if(iconType==='pokemon'){
setAttrib('class','picon'+(className?' '+className:''));
unsanitizedStyle=Dex.getPokemonIcon(getAttrib('fusion')?
{species:iconValue,fusion:getAttrib('fusion')}:iconValue);
}else if(iconType==='item'){
setAttrib('class','itemicon'+(className?' '+className:''));
unsanitizedStyle=Dex.getItemIcon(iconValue);
}else if(iconType==='type'){
tagName=Dex.getTypeIcon(iconValue).slice(1,-3);
}else if(iconType==='category'){
tagName=Dex.getCategoryIcon(iconValue).slice(1,-3);
}
}
}

attribs=html.sanitizeAttribs(tagName,attribs,function(urlData){
if(urlData.scheme_==='geo'||urlData.scheme_==='sms'||urlData.scheme_==='tel')return null;
return urlData;
});
if(unsanitizedStyle){
var style=getAttrib('style');
setAttrib('style',unsanitizedStyle+(style?'; '+style:''));
}

if(dataUri&&tagName==='img'){
setAttrib('src',dataUri);
}
if(tagName==='a'||tagName==='form'&&!getAttrib('data-submitsend')){
if(targetReplace){
setAttrib('data-target','replace');
deleteAttrib('target');
}else{
setAttrib('target','_blank');
}
if(tagName==='a'){
setAttrib('rel','noopener');
}
}
return{tagName:tagName,attribs:attribs};
};
};BattleLog.
localizeTime=function localizeTime(full,date,time,timezone){var _Intl;
var parsedTime=new Date(date+'T'+time+(timezone||'Z').toUpperCase());



if(!parsedTime.getTime())return full;

var formattedTime;

if((_Intl=window.Intl)!=null&&_Intl.DateTimeFormat){
formattedTime=new Intl.DateTimeFormat(undefined,{
month:'long',day:'numeric',hour:'numeric',minute:'numeric'
}).format(parsedTime);
}else{


formattedTime=parsedTime.toLocaleString();
}
return'<time>'+BattleLog.escapeHTML(formattedTime)+'</time>';
};BattleLog.
sanitizeHTML=function sanitizeHTML(input){
if(typeof input!=='string')return'';

this.initSanitizeHTML();

input=input.replace(/<username([^>]*)>([^<]*)<\/username>/gi,function(match,attrs,username){
if(/\bname\s*=\s*"/.test(attrs))return match;
var escapedUsername=username.replace(/"/g,'&quot;').replace(/>/g,'&gt;');
return"<username"+attrs+" name=\""+escapedUsername+"\">"+username+"</username>";
});



var sanitized=html.sanitizeWithPolicy(input,this.tagPolicy);
















return sanitized.replace(
/<time>\s*([+-]?\d{4,}-\d{2}-\d{2})[T ](\d{2}:\d{2}(?::\d{2}(?:\.\d{3})?)?)(Z|[+-]\d{2}:\d{2})?\s*<\/time>/ig,
this.localizeTime
);
};BattleLog.
hideForm=function hideForm(input){
var filters=["-Orion"];for(var _i22=0;_i22<
filters.length;_i22++){var filter=filters[_i22];
if(input.includes(filter)){
return input.replace(filter,'');
}else{
return input;
}
}
};BattleLog.

initYoutubePlayer=function initYoutubePlayer(idx){var _this5=this;
var id="youtube-iframe-"+idx;
var loadPlayer=function(){
var el=$("#"+id);
if(!el.length)return;
var player=new window.YT.Player(id,{
events:{
onStateChange:function(event){
if(event.data===window.YT.PlayerState.PLAYING){for(var _i24=0,_BattleLog$players2=
BattleLog.players;_i24<_BattleLog$players2.length;_i24++){var curPlayer=_BattleLog$players2[_i24];
if(player===curPlayer)continue;
curPlayer==null||curPlayer.pauseVideo==null||curPlayer.pauseVideo();
}
}
}
}
});
var time=Number(el.attr('time'));
if(time){
player.seekTo(time);
}
_this5.players[idx-1]=player;
};

this.ensureYoutube().then(function(){
setTimeout(function(){return loadPlayer();},300);
});
};BattleLog.

ensureYoutube=function ensureYoutube(){
if(this.ytLoading)return this.ytLoading;

this.ytLoading=new Promise(function(resolve){
var el=document.createElement('script');
el.type='text/javascript';
el.async=true;
el.src='https://youtube.com/iframe_api';
el.onload=function(){


var loopCheck=function(){var _window$YT;
if(!((_window$YT=window.YT)!=null&&_window$YT.Player)){
setTimeout(function(){return loopCheck();},300);
}else{
resolve();
}
};
loopCheck();
};
document.body.appendChild(el);
});
return this.ytLoading;
};BattleLog.


























createReplayFile=function createReplayFile(room){
var battle=room.battle;
var replayid=room.id;
if(replayid){var _window$Config;

replayid=replayid.slice(7);
if(((_window$Config=window.Config)==null?void 0:_window$Config.server.id)!=='showdown'){var _window$Config2;
if(!((_window$Config2=window.Config)!=null&&_window$Config2.server.registered)){
replayid='unregisteredserver-'+replayid;
}else{
replayid=Config.server.id+'-'+replayid;
}
}
}else if(room.fragment){

replayid=room.fragment;
}else{
replayid=battle.id;
}

battle.seekTurn(Infinity);
if(!battle.atQueueEnd)return null;
var buf='<!DOCTYPE html>\n';
buf+='<meta charset="utf-8" />\n';
buf+='<!-- version 1 -->\n';
buf+="<title>"+BattleLog.escapeHTML(battle.tier)+" replay: "+BattleLog.escapeHTML(battle.p1.name)+" vs. "+BattleLog.escapeHTML(battle.p2.name)+"</title>\n";

buf+='<style>\n';
buf+='html,body {font-family:Verdana, sans-serif;font-size:10pt;margin:0;padding:0;}body{padding:12px 0;} .battle-log {font-family:Verdana, sans-serif;font-size:10pt;} .battle-log-inline {border:1px solid #AAAAAA;background:#EEF2F5;color:black;max-width:640px;margin:0 auto 80px;padding-bottom:5px;} .battle-log .inner {padding:4px 8px 0px 8px;} .battle-log .inner-preempt {padding:0 8px 4px 8px;} .battle-log .inner-after {margin-top:0.5em;} .battle-log h2 {margin:0.5em -8px;padding:4px 8px;border:1px solid #AAAAAA;background:#E0E7EA;border-left:0;border-right:0;font-family:Verdana, sans-serif;font-size:13pt;} .battle-log .chat {vertical-align:middle;padding:3px 0 3px 0;font-size:8pt;} .battle-log .chat strong {color:#40576A;} .battle-log .chat em {padding:1px 4px 1px 3px;color:#000000;font-style:normal;} .chat.mine {background:rgba(0,0,0,0.05);margin-left:-8px;margin-right:-8px;padding-left:8px;padding-right:8px;} .spoiler {color:#BBBBBB;background:#BBBBBB;padding:0px 3px;} .spoiler:hover, .spoiler:active, .spoiler-shown {color:#000000;background:#E2E2E2;padding:0px 3px;} .spoiler a {color:#BBBBBB;} .spoiler:hover a, .spoiler:active a, .spoiler-shown a {color:#2288CC;} .chat code, .chat .spoiler:hover code, .chat .spoiler:active code, .chat .spoiler-shown code {border:1px solid #C0C0C0;background:#EEEEEE;color:black;padding:0 2px;} .chat .spoiler code {border:1px solid #CCCCCC;background:#CCCCCC;color:#CCCCCC;} .battle-log .rated {padding:3px 4px;} .battle-log .rated strong {color:white;background:#89A;padding:1px 4px;border-radius:4px;} .spacer {margin-top:0.5em;} .message-announce {background:#6688AA;color:white;padding:1px 4px 2px;} .message-announce a, .broadcast-green a, .broadcast-blue a, .broadcast-red a {color:#DDEEFF;} .broadcast-green {background-color:#559955;color:white;padding:2px 4px;} .broadcast-blue {background-color:#6688AA;color:white;padding:2px 4px;} .infobox {border:1px solid #6688AA;padding:2px 4px;} .infobox-limited {max-height:200px;overflow:auto;overflow-x:hidden;} .broadcast-red {background-color:#AA5544;color:white;padding:2px 4px;} .message-learn-canlearn {font-weight:bold;color:#228822;text-decoration:underline;} .message-learn-cannotlearn {font-weight:bold;color:#CC2222;text-decoration:underline;} .message-effect-weak {font-weight:bold;color:#CC2222;} .message-effect-resist {font-weight:bold;color:#6688AA;} .message-effect-immune {font-weight:bold;color:#666666;} .message-learn-list {margin-top:0;margin-bottom:0;} .message-throttle-notice, .message-error {color:#992222;} .message-overflow, .chat small.message-overflow {font-size:0pt;} .message-overflow::before {font-size:9pt;content:\'...\';} .subtle {color:#3A4A66;}\n';
buf+='</style>\n';
buf+='<div class="wrapper replay-wrapper" style="max-width:1180px;margin:0 auto">\n';
buf+='<input type="hidden" name="replayid" value="'+replayid+'" />\n';
buf+='<div class="battle"></div><div class="battle-log"></div><div class="replay-controls"></div><div class="replay-controls-2"></div>\n';
buf+="<h1 style=\"font-weight:normal;text-align:center\"><strong>"+BattleLog.escapeHTML(battle.tier)+"</strong><br /><a href=\"http://"+Config.routes.users+"/"+toID(battle.p1.name)+"\" class=\"subtle\" target=\"_blank\">"+BattleLog.escapeHTML(battle.p1.name)+"</a> vs. <a href=\"http://"+Config.routes.users+"/"+toID(battle.p2.name)+"\" class=\"subtle\" target=\"_blank\">"+BattleLog.escapeHTML(battle.p2.name)+"</a></h1>\n";
buf+='<script type="text/plain" class="battle-log-data">'+battle.stepQueue.join('\n').replace(/\//g,'\\/')+'</script>\n';
buf+='</div>\n';
buf+='<div class="battle-log battle-log-inline"><div class="inner">'+battle.scene.log.elem.innerHTML+'</div></div>\n';
buf+='</div>\n';
buf+='<script>\n';
buf+="let daily = Math.floor(Date.now()/1000/60/60/24);document.write('<script src=\"https://play.pokeathlon.com/js/replay-embed.js?version'+daily+'\"></'+'script>');\n";
buf+='</script>\n';
return buf;
};BattleLog.

createReplayFileHref=function createReplayFileHref(room){

var replayFile=BattleLog.createReplayFile(room);
if(!replayFile){
return'javascript:alert("You will need to click Download again once the replay file is at the end.");void 0';
}
return'data:text/plain;base64,'+encodeURIComponent(btoa(unescape(encodeURIComponent(replayFile))));
};return BattleLog;}();BattleLog.colorCache={};BattleLog.interstice=function(){var whitelist=Config.whitelist||[];var patterns=whitelist.map(function(entry){return new RegExp("^(https?:)?//([A-Za-z0-9-]*\\.)?"+entry.replace(/\./g,'\\.')+"(/.*)?",'i');});return{isWhitelisted:function(uri){if(uri.startsWith('/')&&uri[1]!=='/'){return true;}for(var _i26=0;_i26<patterns.length;_i26++){var pattern=patterns[_i26];if(pattern.test(uri))return true;}return false;},getURI:function(uri){return"http://"+Config.routes.root+"/interstice?uri="+encodeURIComponent(uri);}};}();BattleLog.players=[];BattleLog.ytLoading=null;BattleLog.tagPolicy=null;





function eHTML(strings){
var buf=strings[0];
var i=0;for(var _len=arguments.length,args=new Array(_len>1?_len-1:0),_key=1;_key<_len;_key++){args[_key-1]=arguments[_key];}
while(i<args.length){
buf+=BattleLog.escapeHTML(args[i]);
buf+=strings[++i];
}
return buf;
}

if(window.Net){
Net("/config/colors.json?"+Math.random()).get().then(function(response){
var data=JSON.parse(response);
Object.assign(Config.customcolors,data);
})["catch"](function(){});
}
//# sourceMappingURL=battle-log.js.map