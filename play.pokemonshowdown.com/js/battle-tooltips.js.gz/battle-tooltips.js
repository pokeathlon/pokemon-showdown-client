"use strict";/**
 * Pokemon Showdown Tooltips
 *
 * A file for generating tooltips for battles. This should be IE7+ and
 * use the DOM directly.
 *
 * @author Guangcong Luo <guangcongluo@gmail.com>
 * @license MIT
 */var








ModifiableValue=function(){











function ModifiableValue(battle,pokemon,serverPokemon){this.value=0;this.maxValue=0;this.comment=void 0;this.battle=void 0;this.pokemon=void 0;this.serverPokemon=void 0;this.itemName=void 0;this.abilityName=void 0;this.abilityNames=void 0;this.weatherName=void 0;this.isAccuracy=false;
this.comment=[];
this.battle=battle;
this.pokemon=pokemon;
this.serverPokemon=serverPokemon;

this.itemName=this.battle.dex.items.get(serverPokemon.item).name;
var ability=serverPokemon.ability||(pokemon==null?void 0:pokemon.ability)||serverPokemon.baseAbility;
this.abilityName=this.battle.dex.abilities.get(ability).name;
this.abilityNames=[this.abilityName];
var isDoubleAbilityMod=battle.rules['Double Ability Mod'];
if(isDoubleAbilityMod){
var activeInnates=
((pokemon==null?void 0:pokemon.innates)||[]).
concat((serverPokemon==null?void 0:serverPokemon.innates)||[]);for(var _i2=0;_i2<
activeInnates.length;_i2++){var innate=activeInnates[_i2];
if(!(innate in this.abilityNames)){
this.abilityNames.push(this.battle.dex.abilities.get(innate).name);
}
}
}
this.weatherName=this.battle.dex.moves.get(battle.weather).exists?
this.battle.dex.moves.get(battle.weather).name:this.battle.dex.abilities.get(battle.weather).name;
}var _proto=ModifiableValue.prototype;_proto.
reset=function reset(){var value=arguments.length>0&&arguments[0]!==undefined?arguments[0]:0;var isAccuracy=arguments.length>1?arguments[1]:undefined;
this.value=value;
this.maxValue=0;
this.isAccuracy=!!isAccuracy;
this.comment=[];
};_proto.
tryItem=function tryItem(itemName){var _this$pokemon;
if(itemName!==this.itemName)return false;
if(this.battle.hasPseudoWeather('Magic Room')){
this.comment.push(" ("+itemName+" suppressed by Magic Room)");
return false;
}
if((_this$pokemon=this.pokemon)!=null&&_this$pokemon.volatiles['embargo']){
this.comment.push(" ("+itemName+" suppressed by Embargo)");
return false;
}
var ignoreKlutz=[
"Macho Brace","Power Anklet","Power Band","Power Belt","Power Bracer","Power Lens","Power Weight"];

if(this.tryAbility('Klutz')&&!ignoreKlutz.includes(itemName)){
this.comment.push(" ("+itemName+" suppressed by Klutz)");
return false;
}
return true;
};_proto.
tryAbility=function tryAbility(abilityName){var _this$pokemon2,_this$pokemon3;
if(abilityName!==this.abilityName)return false;
if((_this$pokemon2=this.pokemon)!=null&&_this$pokemon2.volatiles['gastroacid']){
this.comment.push(" ("+abilityName+" suppressed by Gastro Acid)");
return false;
}

if(!((_this$pokemon3=this.pokemon)!=null&&_this$pokemon3.effectiveAbility(this.serverPokemon)))return false;
return true;
};_proto.
tryWeather=function tryWeather(weatherName){
if(!this.weatherName)return false;
if(!weatherName)weatherName=this.weatherName;else
if(weatherName!==this.weatherName)return false;for(var _i4=0,_this$battle$sides2=
this.battle.sides;_i4<_this$battle$sides2.length;_i4++){var side=_this$battle$sides2[_i4];for(var _i6=0,_side$active2=
side.active;_i6<_side$active2.length;_i6++){var active=_side$active2[_i6];
if(active&&['Air Lock','Cloud Nine'].includes(active.ability)){
this.comment.push(" ("+weatherName+" suppressed by "+active.ability+")");
return false;
}
}
}
return true;
};_proto.
itemModify=function itemModify(factor,itemName){
if(!itemName)itemName=this.itemName;
if(!itemName)return false;
if(!this.tryItem(itemName))return false;
return this.modify(factor,itemName);
};_proto.
abilityModify=function abilityModify(factor,abilityName){
if(!this.tryAbility(abilityName))return false;
return this.modify(factor,abilityName);
};_proto.
weatherModify=function weatherModify(factor,weatherName,name){
if(!weatherName)weatherName=this.weatherName;
if(!weatherName)return false;
if(!this.tryWeather(weatherName))return false;
return this.modify(factor,name||weatherName);
};_proto.
modify=function modify(factor,name){
if(factor===0){
if(name)this.comment.push(" ("+name+")");
this.value=0;
this.maxValue=0;
return true;
}
if(name)this.comment.push(" ("+this.round(factor)+"&times; from "+name+")");
this.value*=factor;
if(!(name==='Technician'&&this.maxValue>60))this.maxValue*=factor;
if(this.battle.tier.includes('Super Staff Bros')&&
!(name==='Confirmed Town'&&this.maxValue>60))this.maxValue*=factor;
return true;
};_proto.
set=function set(value,reason){
if(reason)this.comment.push(" ("+reason+")");
this.value=value;
this.maxValue=0;
return true;
};_proto.
setRange=function setRange(value,maxValue,reason){
if(reason)this.comment.push(" ("+reason+")");
this.value=value;
this.maxValue=maxValue;
return true;
};_proto.
round=function round(value){
return value?Number(value.toFixed(2)):0;
};_proto.
toString=function toString(){
var valueString;
if(this.isAccuracy){
valueString=this.value?this.round(this.value)+"%":"can't miss";
}else{
valueString=this.value?""+this.round(this.value):"";
}
if(this.maxValue){
valueString+=" to "+this.round(this.maxValue)+(this.isAccuracy?'%':'');
}
return valueString+this.comment.join('');
};return ModifiableValue;}();var


BattleTooltips=function(){


function BattleTooltips(battle){var _this=this;this.battle=void 0;this.











































































































clickTooltipEvent=function(e){
if(BattleTooltips.isLocked){
e.preventDefault();
e.stopImmediatePropagation();
}
};this.





holdLockTooltipEvent=function(e){


if(e.type==='pointerdown'&&e.originalEvent.pointerType==='touch')return;
if(BattleTooltips.isLocked)BattleTooltips.hideTooltip();
var target=e.currentTarget;
_this.showTooltip(target);
var isClick=e.type!=='touchstart'&&target.tagName==='BUTTON';

BattleTooltips.longTapTimeout=setTimeout(function(){
BattleTooltips.longTapTimeout=null;
_this.lockTooltip();
},isClick?BattleTooltips.LONG_CLICK_DELAY:BattleTooltips.LONG_TAP_DELAY);
if(isClick){
$('#tooltipwrapper').addClass('tooltip-locking-click');
}else{
$('#tooltipwrapper').addClass('tooltip-locking-tap');
}
};this.

showTooltipEvent=function(e){
if(BattleTooltips.isLocked)return;
_this.showTooltip(e.currentTarget);
};this.

mouseOverEvent=function(e){var _originalEvent;

if(BattleTooltips.isLocked||((_originalEvent=e.originalEvent)==null?void 0:_originalEvent.mozInputSource)===5)return;
_this.showTooltip(e.currentTarget);
};this.battle=battle;}BattleTooltips.allowsTouchScroll=function allowsTouchScroll(elem){return elem&&(elem.tagName==='DIV'||elem.tagName==='SPAN');};BattleTooltips.hideTooltip=function hideTooltip(){BattleTooltips.cancelLongTap();if(!BattleTooltips.elem)return;BattleTooltips.elem.parentNode.removeChild(BattleTooltips.elem);BattleTooltips.elem=null;BattleTooltips.parentElem=null;BattleTooltips.isLocked=false;$('#tooltipwrapper').removeClass('tooltip-locked tooltip-locking-click tooltip-locking-tap');};BattleTooltips.cancelLongTap=function cancelLongTap(){if(BattleTooltips.longTapTimeout){clearTimeout(BattleTooltips.longTapTimeout);BattleTooltips.longTapTimeout=null;}$('#tooltipwrapper').removeClass('tooltip-locking-click tooltip-locking-tap');};BattleTooltips.dismissOnOutsideClick=function dismissOnOutsideClick(e){if(!BattleTooltips.elem)return;var target=e.target;if(target&&BattleTooltips.elem.contains(target))return;if(target&&target.closest!=null&&target.closest('.has-tooltip'))return;BattleTooltips.hideTooltip();};var _proto2=BattleTooltips.prototype;_proto2.lockTooltip=function lockTooltip(){if(BattleTooltips.elem&&!BattleTooltips.isLocked){BattleTooltips.isLocked=true;if(BattleTooltips.isPressed){$(BattleTooltips.parentElem).removeClass('pressed');BattleTooltips.isPressed=false;}$('#tooltipwrapper').addClass('tooltip-locked');}};_proto2.handleTouchEnd=function handleTouchEnd(e){BattleTooltips.cancelLongTap();if(!BattleTooltips.isLocked)BattleTooltips.hideTooltip();};_proto2.listen=function listen(elem){var _this2=this;if(!BattleTooltips.outsideClickListenerAdded){window.addEventListener('click',BattleTooltips.dismissOnOutsideClick,true);BattleTooltips.outsideClickListenerAdded=true;}var $elem=$(elem);$elem.on('mouseover.battleTooltips','.has-tooltip',this.mouseOverEvent);$elem.on('click.battleTooltips','.has-tooltip',this.clickTooltipEvent);$elem.on('focus.battleTooltips','.has-tooltip',this.showTooltipEvent);$elem.on('mouseout.battleTooltips','.has-tooltip',BattleTooltips.unshowTooltip);var pressEvent=window.PointerEvent?'pointerdown':'mousedown';$elem.on(pressEvent+".battleTooltips",'.has-tooltip',this.holdLockTooltipEvent);$elem.on('blur.battleTooltips','.has-tooltip',BattleTooltips.unshowTooltip);$elem.on('mouseup.battleTooltips','.has-tooltip',BattleTooltips.unshowTooltip);$elem.on('touchstart.battleTooltips','.has-tooltip',function(e){if(!BattleTooltips.allowsTouchScroll(e.currentTarget))e.preventDefault();_this2.holdLockTooltipEvent(e);if(!BattleTooltips.parentElem){BattleTooltips.parentElem=e.currentTarget;}$(BattleTooltips.parentElem).addClass('pressed');BattleTooltips.isPressed=true;});$elem.on('touchend.battleTooltips','.has-tooltip',function(e){var allowScroll=BattleTooltips.allowsTouchScroll(e.currentTarget);if(!allowScroll)e.preventDefault();if(!allowScroll&&e.currentTarget===BattleTooltips.parentElem&&BattleTooltips.isPressed){BattleTooltips.parentElem.click();}BattleTooltips.unshowTooltip();});$elem.on('touchleave.battleTooltips','.has-tooltip',BattleTooltips.unshowTooltip);$elem.on('touchcancel.battleTooltips','.has-tooltip',BattleTooltips.unshowTooltip);$elem.on('contextmenu.battleTooltips','.has-tooltip',function(e){var _e$originalEvent;var pointerType=(_e$originalEvent=e.originalEvent)==null?void 0:_e$originalEvent.pointerType;if(pointerType==='touch'||pointerType==='pen')e.preventDefault();});};_proto2.unlisten=function unlisten(elem){$(elem).off('.battleTooltips');};BattleTooltips.




unshowTooltip=function unshowTooltip(){
if(BattleTooltips.isLocked)return;
if(BattleTooltips.isPressed){
$(BattleTooltips.parentElem).removeClass('pressed');
BattleTooltips.isPressed=false;
}
BattleTooltips.hideTooltip();
};_proto2.

showTooltip=function showTooltip(elem){
var args=(elem.dataset.tooltip||'').split('|');
var type=args[0];





var ownHeight=!!elem.dataset.ownheight;

var buf;
switch(type){
case'move':
case'zmove':
case'maxmove':{
var move=this.battle.dex.moves.get(args[1]);
var teamIndex=parseInt(args[2],10);
var pokemon=this.battle.nearSide.active[
teamIndex+this.battle.pokemonControlled*Math.floor(this.battle.mySide.n/2)];

var gmaxMove=args[3]?this.battle.dex.moves.get(args[3]):undefined;
if(!pokemon)return false;
var serverPokemon=this.battle.myPokemon[teamIndex];
buf=this.showMoveTooltip(move,type,pokemon,serverPokemon,gmaxMove);
break;
}

case'pokemon':{


var sideIndex=parseInt(args[1],10);
var side=this.battle.sides[sideIndex];
var _pokemon=side.pokemon[parseInt(args[2],10)];
if(args[3]==='illusion'){
buf='';
var species=_pokemon.getBaseSpecies().baseSpecies;
var index=1;for(var _i8=0,_side$pokemon2=
side.pokemon;_i8<_side$pokemon2.length;_i8++){var otherPokemon=_side$pokemon2[_i8];
if(otherPokemon.getBaseSpecies().baseSpecies===species){
buf+=this.showPokemonTooltip(otherPokemon,null,false,index);
index++;
}
}
}else{
buf=this.showPokemonTooltip(_pokemon);
}
break;
}
case'activepokemon':{


var _sideIndex=parseInt(args[1],10);
var _side=this.battle.sides[+this.battle.viewpointSwitched^_sideIndex];
var activeIndex=parseInt(args[2],10);
var pokemonIndex=activeIndex;
if(activeIndex>=1&&this.battle.sides.length>2){
pokemonIndex-=1;
_side=this.battle.sides[_side.n+2];
}
var _pokemon2=_side.active[activeIndex];
var _serverPokemon=null;
if(_side===this.battle.mySide&&this.battle.myPokemon){
_serverPokemon=this.battle.myPokemon[pokemonIndex];
}
if(_side===this.battle.mySide.ally&&this.battle.myAllyPokemon){
_serverPokemon=this.battle.myAllyPokemon[pokemonIndex];
}
if(!_pokemon2)return false;
buf=this.showPokemonTooltip(_pokemon2,_serverPokemon,true);
break;
}
case'switchpokemon':{



var _activeIndex=parseInt(args[1],10);
var _pokemon3=null;




var _serverPokemon2=this.battle.myPokemon[_activeIndex];
buf=this.showPokemonTooltip(_pokemon3,_serverPokemon2);
break;
}
case'allypokemon':{



var _activeIndex2=parseInt(args[1],10);
var _pokemon4=null;



var _serverPokemon3=this.battle.myAllyPokemon?this.battle.myAllyPokemon[_activeIndex2]:null;
buf=this.showPokemonTooltip(_pokemon4,_serverPokemon3);
break;
}
case'field':{
buf=this.showFieldTooltip();
break;
}
default:

Promise.resolve(new Error("unrecognized type"));
buf="<p class=\"message-error\" style=\"white-space: pre-wrap\">"+new Error("unrecognized type").stack+"</p>";
}

this.placeTooltip(buf,elem,ownHeight,type);
return true;
};_proto2.

placeTooltip=function placeTooltip(innerHTML,hoveredElem,notRelativeToParent,type){
var $elem;
if(hoveredElem){
$elem=$(hoveredElem);
}else{
$elem=this.battle.scene.$turn;
notRelativeToParent=true;
}

var hoveredX1=$elem.offset().left;

if(!notRelativeToParent){
$elem=$elem.parent();
}

var hoveredY1=$elem.offset().top;
var hoveredY2=hoveredY1+$elem.outerHeight();




var x=Math.max(hoveredX1-2,0);
var y=Math.max(hoveredY1-5,0);

var $wrapper=$('#tooltipwrapper');
if(!$wrapper.length){
$wrapper=$("<div id=\"tooltipwrapper\" role=\"tooltip\"></div>");
$(document.body).append($wrapper);
$wrapper.on('click',function(e){
try{
var selection=window.getSelection();
if(selection.type==='Range')return;
}catch(_unused){}
BattleTooltips.hideTooltip();
});
}else{
$wrapper.removeClass('tooltip-locked');
}
$wrapper.css({
left:Math.min(x,document.documentElement.clientWidth-400),
top:y
});
innerHTML="<div class=\"tooltipinner\"><div class=\"tooltip tooltip-"+type+"\">"+innerHTML+"</div></div>";
$wrapper.html(innerHTML).appendTo(document.body);
BattleTooltips.elem=$wrapper.find('.tooltip')[0];
BattleTooltips.isLocked=false;

var height=$(BattleTooltips.elem).outerHeight();
if(y-height<1){


y=hoveredY2+height+5;
if(y>document.documentElement.clientHeight){


y=height+1;
}
$wrapper.css('top',y);
}else if(y<75){

y=hoveredY2+height+5;
if(y<document.documentElement.clientHeight){

$wrapper.css('top',y);
}
}

var width=$(BattleTooltips.elem).outerWidth();
var availableWidth=document.documentElement.clientWidth+window.scrollX;
if(x>availableWidth-width-2){
x=availableWidth-width-2;
$wrapper.css('left',x);
}else if(x>document.documentElement.clientWidth-400){
$wrapper.css('left',x);
}

BattleTooltips.parentElem=hoveredElem||null;
return true;
};_proto2.

hideTooltip=function hideTooltip(){
BattleTooltips.hideTooltip();
};_proto2.










getStatusZMoveEffect=function getStatusZMoveEffect(move){
if(move.zMove.effect in BattleTooltips.zMoveEffects){
return BattleTextParser.ui(BattleTooltips.zMoveEffects[move.zMove.effect]);
}
var boostText='';
if(move.zMove.boost){
boostText=Object.entries(move.zMove.boost).map(function(_ref){var stat=_ref[0],boost=_ref[1];return(
TL.stat[stat]||stat)+" +"+boost;}
).join(', ');
}
return boostText;
};_proto2.



















































getFieldMoves=function getFieldMoves(item){
var rejuv=this.battle.dex.modid==='gen9rejuvenation';
if(!rejuv&&item.id==='fieldcleats')return['Tri Attack','Normal'];
var field=this.battle.getTerrain()||(rejuv?this.battle.getBattlefield():'');
if(!rejuv&&field==='Misty Terrain')return['Moonblast','Fairy'];
if(field==='Crystal Cavern Field')return['Power Gem',this.battle.fieldState.crystalType||'???'];
return BattleTooltips.fieldMoves[field]||['Tri Attack','Normal'];
};_proto2.

























































getMaxMoveFromType=function getMaxMoveFromType(type,gmaxMove){
if(gmaxMove){
if(typeof gmaxMove==='string')gmaxMove=this.battle.dex.moves.get(gmaxMove);
if(type===gmaxMove.type)return gmaxMove;
}
return this.battle.dex.moves.get(BattleTooltips.maxMoveTable[type]);
};_proto2.

getDisplayedTarget=function getDisplayedTarget(move){
switch(move.target){
case'self':case'foeSide':case'allySide':case'allyTeam':case'all':case'allies':

return null;
}
switch(this.battle.gameType){
case'doubles':case'multi':
switch(move.target){
case'normal':case'any':return'normalDoubles';
case'adjacentFoe':return'normalFFA';
case'adjacentAlly':return'adjacentAllyDoubles';
case'adjacentAllyOrSelf':return'adjacentAllyOrSelfDoubles';
case'allAdjacentFoes':return'allAdjacentFoesDoubles';
case'allAdjacent':return'allAdjacentDoubles';
case'randomNormal':return'randomNormalDoubles';
default:return move.target;
}
case'triples':
return move.target;
case'freeforall':
switch(move.target){
case'normal':case'any':case'adjacentFoe':case'adjacentAlly':return'normalFFA';
case'adjacentAllyOrSelf':return'self';
case'allAdjacent':case'allAdjacentFoes':return'allAdjacentFFA';
case'randomNormal':return'randomNormalDoubles';
default:return move.target;
}
default:
switch(move.target){
case'normal':case'any':case'adjacentFoe':case'scripted':case'randomNormal':
case'allAdjacent':case'allAdjacentFoes':

return null;
case'adjacentAllyOrSelf':return'self';
case'adjacentAlly':return'adjacentAllySingles';
default:return move.target;
}
}
};_proto2.

showMoveTooltip=function showMoveTooltip(
move,isZOrMax,pokemon,serverPokemon,gmaxMove)
{
var text='';

var zEffect='';
var foeActive=[].concat(pokemon.side.foe.active).reverse();
if(this.battle.gameType==='freeforall'){
foeActive=[].concat(foeActive,pokemon.side.active).filter(function(active){return active!==pokemon;});
}

if(pokemon.ability==='(suppressed)')serverPokemon.ability='(suppressed)';
var ability=toID(serverPokemon.ability||pokemon.ability||serverPokemon.baseAbility);
var item=this.battle.dex.items.get(serverPokemon.item);

var value=new ModifiableValue(this.battle,pokemon,serverPokemon);
var _this$getMoveType=this.getMoveType(move,value,gmaxMove||isZOrMax==='maxmove'),moveType=_this$getMoveType[0],category=_this$getMoveType[1];
var categoryDiff=move.category!==category;

if(isZOrMax==='zmove'){
if(item.zMoveFrom===move.name){
move=this.battle.dex.moves.get(item.zMove);
}else if(move.category==='Status'){
move=new Move(move.id,"",Object.assign({},
move,{
name:'Z-'+move.name})
);
zEffect=this.getStatusZMoveEffect(move);
}else{
var _moveName=BattleTooltips.zMoveTable[item.zMoveType];
var zMove=this.battle.dex.moves.get(_moveName);
var movePower=move.zMove.basePower;

if(!movePower&&move.id.startsWith('hiddenpower')){
movePower=this.battle.dex.moves.get('hiddenpower').zMove.basePower;
}
if(move.id==='weatherball'){
switch(this.battle.weather){
case'sunnyday':
case'desolateland':
zMove=this.battle.dex.moves.get(BattleTooltips.zMoveTable['Fire']);
break;
case'raindance':
case'primordialsea':
zMove=this.battle.dex.moves.get(BattleTooltips.zMoveTable['Water']);
break;
case'sandstorm':
zMove=this.battle.dex.moves.get(BattleTooltips.zMoveTable['Rock']);
break;
case'hail':
case'snowscape':
zMove=this.battle.dex.moves.get(BattleTooltips.zMoveTable['Ice']);
break;
case'newmoon':
zMove=this.battle.dex.moves.get(BattleTooltips.zMoveTable['Dark']);
break;
case'thunderstorm':
zMove=this.battle.dex.moves.get(BattleTooltips.zMoveTable['Electric']);
break;
}
}
move=new Move(zMove.id,zMove.name,Object.assign({},
zMove,{
category:move.category,
basePower:movePower})
);
categoryDiff=false;
}
}else if(isZOrMax==='maxmove'){
if(move.category==='Status'){
move=this.battle.dex.moves.get('Max Guard');
}else{
var maxMove=this.getMaxMoveFromType(moveType,gmaxMove);
var basePower=['gmaxdrumsolo','gmaxfireball','gmaxhydrosnipe'].includes(maxMove.id)?
maxMove.basePower:move.maxMove.basePower;
move=new Move(maxMove.id,maxMove.name,Object.assign({},
maxMove,{
category:move.category,
basePower:basePower})
);
categoryDiff=false;
}
}

if(categoryDiff){
move=new Move(move.id,move.name,Object.assign({},
move,{
category:category})
);
}

var moveName=TL(move);
if(move.name.startsWith('Z-')&&!moveName.startsWith('Z-'))moveName="Z-"+moveName;
text+="<h2>"+moveName+"<br />";

text+=Dex.getTypeIcon(moveType);
if(move.id==='terrainpulse'&&moveType==='???'&&this.battle.hasPseudoWeather('New World Field')){
text+=' '+TL(["(random type)"]);
}
text+=" "+Dex.getCategoryIcon(category)+"</h2>";

var powerMove=move;
var powerType=moveType;
if(move.id==='naturepower'){
var name='Swift';
if(this.battle.gen>5){var _this$getFieldMoves=
this.getFieldMoves(item);name=_this$getFieldMoves[0];
}else if(this.battle.gen>3){
name='Earthquake';
}
var called=this.battle.dex.moves.get(name);
var _this$getMoveType2=this.getMoveType(called,value),calledType=_this$getMoveType2[0],calledCategory=_this$getMoveType2[1];
var calledMove=Dex.getTypeIcon(calledType)+" "+TL(called);
text+="<p>"+TL(["Calls ",""],calledMove)+"</p>";
if(this.battle.dex.modid==='gen9rejuvenation'){
powerMove=calledCategory===called.category?called:Object.assign({},called,{category:calledCategory});
powerType=calledType;
}
}


var showingMultipleBasePowers=false;
if(powerMove.category!=='Status'&&foeActive.length>1){



var prevBasePower=null;
var _basePower='';
var difference=false;
var basePowers=[];for(var _i10=0,_foeActive2=
foeActive;_i10<_foeActive2.length;_i10++){var active=_foeActive2[_i10];
if(!active)continue;
value=this.getMoveBasePower(powerMove,powerType,value,active);
_basePower=""+value;
if(prevBasePower===null)prevBasePower=_basePower;
if(prevBasePower!==_basePower)difference=true;
basePowers.push(TL.label(TL(["Base power vs. ",""],active.name),_basePower));
}
if(difference){
text+='<p>'+basePowers.join('<br />')+'</p>';
showingMultipleBasePowers=true;
}

}
if(!showingMultipleBasePowers&&powerMove.category!=='Status'){
var activeTarget=foeActive[0]||foeActive[1]||foeActive[2];
value=this.getMoveBasePower(powerMove,powerType,value,activeTarget);
text+="<p>"+TL.label(TL.tag.basepower,value)+"</p>";
}

var accuracy=this.getMoveAccuracy(move,value);
text+="<p>"+TL.label(TL.tag.accuracy,accuracy)+"</p>";
if(zEffect)text+="<p>"+TL.label(TL(["Z-Effect"]),zEffect)+"</p>";

if(this.battle.hardcoreMode){
text+="<p class=\"tooltip-section\">"+this.battle.dex.text.get(move).shortDesc+"</p>";
}else{
text+='<p class="tooltip-section">';
var priority=move.id==='grassyglide'&&this.battle.hasPseudoWeather('Grassy Terrain')?1:move.priority;
if(priority>1){
text+=TL(["Nearly always moves first (priority +",")."],priority)+'</p><p>';
}else if(priority<=-1){
var absPriority=-priority;
text+=TL(["Nearly always moves last (priority \u2212",")."],absPriority)+'</p><p>';
}else if(priority===1){
text+=TL(["Usually moves first (priority +",")."],priority)+'</p><p>';
}

text+=this.battle.dex.text.get(move).desc+'</p>';

var displayedTarget=this.getDisplayedTarget(move);
if(displayedTarget){
text+="<p>&#x25ce; "+TL.target[displayedTarget]+"</p>";
}

if(move.flags.defrost){
text+="<p class=\"movetag\">&#x2713; "+TL.tag.defrost+" <small>("+TL.tagHint.defrost+")</small></p>";
}
if(!move.flags.protect&&!['self','allySide'].includes(move.target)){
text+="<p class=\"movetag\">"+TL.tag.bypassprotect+" <small>("+TL.tagHint.bypassprotect+")</small></p>";
}
if(move.flags.bypasssub){
text+="<p class=\"movetag\">"+TL.tag.bypasssubstitute+" <small>("+TL.tagHint.bypasssubstitute+")</small></p>";
}
if(!move.flags.reflectable&&!['self','allySide'].includes(move.target)&&move.category==='Status'){
text+="<p class=\"movetag\">"+TL.tag.nonreflectable+" <small>("+TL.tagHint.nonreflectable+")</small></p>";
}

if(move.flags.contact){
text+="<p class=\"movetag\">&#x2713; "+TL.tag.contact+" <small>("+TL.tagHint.contact+")</small></p>";
}
if(move.flags.sound){
text+="<p class=\"movetag\">&#x2713; "+TL.tag.sound+" <small>("+TL.tagHint.sound+")</small></p>";
}
if(move.flags.powder&&this.battle.gen>5){
text+="<p class=\"movetag\">&#x2713; "+TL.tag.powder+" <small>("+TL.tagHint.powder+")</small></p>";
}
if(move.flags.punch&&ability==='ironfist'){
text+="<p class=\"movetag\">&#x2713; "+TL.tag.fist+" <small>("+TL.tagHint.fist+")</small></p>";
}
if(move.flags.pulse&&ability==='megalauncher'){
text+="<p class=\"movetag\">&#x2713; "+TL.tag.pulse+" <small>("+TL.tagHint.pulse+")</small></p>";
}
if(move.flags.bite&&ability==='strongjaw'){
text+="<p class=\"movetag\">&#x2713; "+TL.tag.bite+" <small>("+TL.tagHint.bite+")</small></p>";
}
if((move.recoil||move.hasCrashDamage)&&ability==='reckless'){
text+="<p class=\"movetag\">&#x2713; "+TL.tag.recoil+" <small>("+TL.tagHint.recoil+")</small></p>";
}
if(move.flags.bullet){
text+="<p class=\"movetag\">&#x2713; "+TL.tag.bullet+" <small>("+TL.tagHint.bullet+")</small></p>";
}
if(move.flags.slicing){
text+="<p class=\"movetag\">&#x2713; "+TL.tag.slicing+" <small>("+TL.tagHint.slicing+")</small></p>";
}
if(move.flags.wind){
text+="<p class=\"movetag\">&#x2713; "+TL.tag.wind+" <small>("+TL.tagHint.wind+")</small></p>";
}

if(this.battle.gen===1&&!toID(this.battle.tier).includes('stadium')&&
['recover','softboiled','rest'].includes(move.id)){
var hpValues=[];

var hp=serverPokemon.maxhp-255;
if(hp>0&&hp%256!==0){
hpValues.push(hp);
if(hp-256>0){
hpValues.push(hp-256);
}
}
var hpList=hpValues.join(TL([" or "]));
var failMessage=hpValues.length?TL(["Fails if current HP is ","."],hpList):'';
if(hpValues.includes(serverPokemon.hp))failMessage="<strong class=\"message-error\">"+failMessage+"</strong>";
if(failMessage)text+="<p>"+failMessage+"</p>";
}
if(this.battle.gen===1&&!toID(this.battle.tier).includes('stadium')&&
move.id==='substitute'){
var selfKO=serverPokemon.maxhp%4===0?serverPokemon.maxhp/4:null;
var _failMessage=selfKO?TL(["KOs yourself if current HP is exactly ","."],selfKO):'';
if(selfKO===serverPokemon.hp)_failMessage="<strong class=\"message-error\">"+_failMessage+"</strong>";
if(_failMessage)text+="<p>"+_failMessage+"</p>";
}
}for(var _i12=0,_foeActive4=

foeActive;_i12<_foeActive4.length;_i12++){var possibleTarget=_foeActive4[_i12];
if(!possibleTarget)continue;
var effectiveness=this.getMoveEffectiveness(pokemon,move,moveType,category,possibleTarget);
var target=BattleLog.escapeHTML(this.getNickname(possibleTarget));
if(effectiveness===null){

}else if(effectiveness===0){
var effect=TL(["No effect"]);
text+="<p><span class=\"effectiveness-icon\">&times;</span> "+TL(["<strong>","</strong> vs. ",""],effect,target)+"</p>";
}else if(effectiveness<0.5){
var effectivenessText=effectiveness===0.25?'&#x00BC;':effectiveness;
var _effect=TL(["Mostly ineffective"]);
text+="<p><span class=\"effectiveness-icon\">&#x25BC;</span> "+TL(["<strong>","</strong> vs. ",""],_effect,target)+" <small>("+effectivenessText+"&times;)</small></p>";
}else if(effectiveness<1){
var _effectivenessText=effectiveness===0.5?'&#x00BD;':effectiveness;
var _effect2=TL(["Not very effective"]);
text+="<p><span class=\"effectiveness-icon\">&#x25B3;</span> "+TL(["<strong>","</strong> vs. ",""],_effect2,target)+" <small>("+_effectivenessText+"&times;)</small></p>";
}else if(effectiveness>2){
var _effect3=TL(["Extremely effective"]);
text+="<p><span class=\"effectiveness-icon\">&#x2605;</span> "+TL(["<strong>","</strong> vs. ",""],_effect3,target)+" <small>("+effectiveness+"&times;)</small></p>";
}else if(effectiveness>1){
var _effect4=TL(["Super effective"]);
text+="<p><span class=\"effectiveness-icon\">&#x29BF;</span> "+TL(["<strong>","</strong> vs. ",""],_effect4,target)+" <small>("+effectiveness+"&times;)</small></p>";
}
}

return text;
};_proto2.
getNickname=function getNickname(pokemon){
var ignoreNicks=this.battle.ignoreNicks||this.battle.ignoreOpponent;
if(!ignoreNicks)return pokemon.name;
var species=this.battle.dex.species.get(pokemon.speciesForme);
return TL(this.battle.dex.species.get(species.baseSpecies));
};_proto2.











showPokemonTooltip=function showPokemonTooltip(
clientPokemon,serverPokemon,isActive,illusionIndex)
{var _this3=this;
var pokemon=clientPokemon||serverPokemon;
var text='';
var genderBuf='';
var gender=pokemon.gender;
if(gender==='M'||gender==='F'){
var genderName=TL.gender[gender]||gender;
genderBuf=" <img src=\""+Dex.fxPrefix+"gender-"+gender.toLowerCase()+".png\" alt=\""+BattleLog.escapeHTML(genderName)+"\" width=\"7\" height=\"10\" class=\"pixelated\" /> ";
}

var nickname=this.getNickname(pokemon);
var name=BattleLog.escapeHTML(nickname);
var speciesName=TL(this.battle.dex.species.get(pokemon.speciesForme));
if(speciesName!==nickname){

var speciesSuffix=BattleTextParser.defaultText('fullName',{NICKNAME:'',SPECIES:speciesName});
name+="<small>"+speciesSuffix+"</small>";
}

var fuseBuf=pokemon.fusion?" <small><b>Fusion: </b>"+pokemon.fusion+"</small><br />":"";

var fusionData=Dex.getFusionData(pokemon);
var fangameCredit=Dex.getFangameCredit(pokemon);
if(clientPokemon!=null&&clientPokemon.volatiles.formechange&&clientPokemon.volatiles.transform){
fusionData=Dex.getFusionData({species:clientPokemon.volatiles.formechange[1],fusion:clientPokemon.volatiles.transform[5]});
fangameCredit=Dex.getFangameCredit({species:clientPokemon.volatiles.formechange[1]});
}
var creditBuf='';
if(fusionData.credit){
creditBuf=" <small><b>Sprite: </b>"+fusionData.credit+"</small><br />";
}else if(fangameCredit){
creditBuf=" <small><b>Concept: </b>"+fangameCredit[0]+"<br><b>Sprite: </b>"+fangameCredit[1]+"</small><br />";
}

var levelBuf=pokemon.level!==100?" <small>"+TL(["Level"])+" "+pokemon.level+"</small>":"";
if(!illusionIndex||illusionIndex===1){
text+="<h2>"+name+genderBuf+(illusionIndex?'':levelBuf)+"<br />"+fuseBuf+creditBuf;

if(clientPokemon!=null&&clientPokemon.volatiles.formechange){
var forme=TL(this.battle.dex.species.get(clientPokemon.volatiles.formechange[1]));
if(clientPokemon.volatiles.transform){
var fusion=clientPokemon.volatiles.transform[5]?'/'+TL(this.battle.dex.species.get(clientPokemon.volatiles.transform[5])):'';
text+="<small>"+TL(["(Transformed into ",")"],forme+fusion)+"</small><br />";
}else{
text+="<small>"+TL(["(Changed forme: ",")"],forme)+"</small><br />";
}
}

var types=serverPokemon!=null&&serverPokemon.terastallized?[serverPokemon.teraType]:this.getPokemonTypes(pokemon);
var knownPokemon=serverPokemon||clientPokemon;

if(pokemon.terastallized){
text+="<small>(Terastallized)</small><br />";
}else if(clientPokemon!=null&&clientPokemon.volatiles.typechange||clientPokemon!=null&&clientPokemon.volatiles.typeadd){
text+="<small>(Type changed)</small><br />";
}
text+="<span class=\"textaligned-typeicons\">"+types.map(function(type){return Dex.getTypeIcon(type);}).join(' ')+"</span>";
if(pokemon.terastallized){
var baseTypes="<span class=\"textaligned-typeicons\">"+this.getPokemonTypes(pokemon,true).map(function(type){return Dex.getTypeIcon(type);}).join(' ')+"</span>";
text+="&nbsp; &nbsp; <small>"+TL(["(base: ",")"],baseTypes)+"</small>";
}else if(knownPokemon.teraType){
var teraType="<span class=\"textaligned-typeicons\">"+Dex.getTypeIcon(knownPokemon.teraType)+"</span>";
var teraTypeText=TL(["Tera ",""],teraType);
text+="&nbsp; &nbsp; <small>("+teraTypeText+")</small>";
}
text+="</h2>";
}

if(illusionIndex){
text+="<p class=\"tooltip-section\"><strong>"+TL(["Possible Illusion #",""],illusionIndex)+"</strong>"+levelBuf+"</p>";
}

var hpName=TL.stat.hp||'HP';
var faintedName=TL.status.fnt||'fainted';
var statusName=pokemon.status?TL.status[pokemon.status]||pokemon.status.toUpperCase():'';
var status=pokemon.status?" <span class=\"status "+
pokemon.status+"\">"+statusName+"</span>":'';
if(pokemon.fainted&&pokemon.maxhp===100){
text+="<p><small>"+TL.label(hpName)+"</small>("+faintedName+")</p>";
}else if(pokemon.fainted){
text+="<p><small>"+TL.label(hpName)+"</small><span class=\"gray\">0/"+pokemon.maxhp+" ("+faintedName+")</span></p>";
}else if(this.battle.hardcoreMode){
if(serverPokemon){
text+="<p><small>"+TL.label(hpName)+"</small>"+serverPokemon.hp+"/"+serverPokemon.maxhp+status+"</p>";
}
}else{
var exacthp='';
if(serverPokemon){
exacthp=" ("+serverPokemon.hp+"/"+serverPokemon.maxhp+")";
}else if(pokemon.maxhp===48){
exacthp=" <small>"+TL(["(","/"," pixels)"],pokemon.hp,pokemon.maxhp)+"</small>";
}
text+="<p><small>"+TL.label(hpName)+"</small>"+Pokemon.getHPText(pokemon,this.battle.reportExactHP)+exacthp+status;
if(clientPokemon){
if(pokemon.status==='tox'){
if(pokemon.ability==='Poison Heal'||pokemon.ability==='Magic Guard'){
var percent=Math.floor(100/16*Math.min(clientPokemon.statusData.toxicTurns+1,15));
text+=" <small>"+TL(["Would take if ability removed: ","%"],percent)+"</small>";
}else{
var _percent=Math.floor(
100/(clientPokemon.volatiles['dynamax']?32:16)*Math.min(clientPokemon.statusData.toxicTurns+1,15)
);
text+=" "+TL(["Next damage: ","%"],_percent);
}
}else if(pokemon.status==='slp'){
text+=" "+TL(["Turns asleep: ",""],clientPokemon.statusData.sleepTurns);
}
}
text+='</p>';
}

var supportsAbilities=this.battle.gen>2&&!this.battle.tier.includes("Let's Go");

var abilityText='';
if(supportsAbilities){
abilityText=this.getPokemonAbilityText(
clientPokemon,serverPokemon,isActive,!!illusionIndex&&illusionIndex>1
);
}

var itemText='';
if(serverPokemon){
var item='';
var itemEffect='';
if(clientPokemon!=null&&clientPokemon.prevItem){
item='None';
var prevItem=TL(this.battle.dex.items.get(clientPokemon.prevItem));
itemEffect+=clientPokemon.prevItemEffect?prevItem+' was '+clientPokemon.prevItemEffect:'was '+prevItem;
}
if(serverPokemon.item)item=TL(this.battle.dex.items.get(serverPokemon.item));
if(itemEffect)itemEffect=' ('+itemEffect+')';
if(item)itemText="<small>"+TL.label(TL(["Item"]))+"</small>"+item+itemEffect;
}else if(clientPokemon){
var _item='';
var _itemEffect=clientPokemon.itemEffect||'';
if(clientPokemon.prevItem){
_item='None';
if(_itemEffect)_itemEffect+='; ';
var _prevItem=TL(this.battle.dex.items.get(clientPokemon.prevItem));
_itemEffect+=clientPokemon.prevItemEffect?_prevItem+' was '+clientPokemon.prevItemEffect:'was '+_prevItem;
}
if(pokemon.item)_item=TL(this.battle.dex.items.get(pokemon.item));
if(_itemEffect)_itemEffect=' ('+_itemEffect+')';
if(_item)itemText="<small>"+TL.label(TL(["Item"]))+"</small>"+_item+_itemEffect;
}

if(abilityText||itemText){
text+='<p>';
text+=abilityText;
if(abilityText&&itemText){

text+=!isActive&&serverPokemon?' / ':'</p><p>';
}
text+=itemText;
text+='</p>';
}


if(clientPokemon!=null&&clientPokemon.nature&&!serverPokemon){
var nature=TL.nature[clientPokemon.nature]||clientPokemon.nature;
var natureText="<small>"+TL.label(TL(["Nature"]))+"</small>"+nature;
text+="<p>"+natureText+"</p>";
}

text+=this.renderStats(clientPokemon,serverPokemon,!isActive);

if(serverPokemon&&!isActive){

text+="<p class=\"tooltip-section\">";
var battlePokemon=clientPokemon||this.battle.findCorrespondingPokemon(pokemon);for(var _i14=0,_serverPokemon$moves2=
serverPokemon.moves;_i14<_serverPokemon$moves2.length;_i14++){var moveid=_serverPokemon$moves2[_i14];
var move=this.battle.dex.moves.get(moveid);
var moveName="&#8226; "+TL(move);
if(battlePokemon!=null&&battlePokemon.moveTrack){for(var _i16=0,_battlePokemon$moveTr2=
battlePokemon.moveTrack;_i16<_battlePokemon$moveTr2.length;_i16++){var row=_battlePokemon$moveTr2[_i16];
if(move.name===row[0]){
moveName=this.getPPUseText(row,true);
break;
}
}
}
text+=moveName+"<br />";
}
text+='</p>';
}else if(this.battle.hardcoreMode&&clientPokemon!=null&&clientPokemon.side.openTeamSheet&&clientPokemon.moveTrack.length){

text+="<p class=\"tooltip-section\">";for(var _i18=0,_clientPokemon$moveTr2=
clientPokemon.moveTrack;_i18<_clientPokemon$moveTr2.length;_i18++){var _ref2=_clientPokemon$moveTr2[_i18];var _moveName2=_ref2[0];{
var _move=this.battle.dex.moves.get(_moveName2);
text+="&#8226; "+TL(_move)+"<br />";
}}
text+="</p>";
}else if(!this.battle.hardcoreMode&&clientPokemon!=null&&clientPokemon.moveTrack.length){

text+="<p class=\"tooltip-section\">";for(var _i20=0,_clientPokemon$moveTr4=
clientPokemon.moveTrack;_i20<_clientPokemon$moveTr4.length;_i20++){var _row=_clientPokemon$moveTr4[_i20];
text+=this.getPPUseText(_row)+"<br />";
}
if(clientPokemon.moveTrack.filter(function(_ref3){var moveName=_ref3[0];
if(moveName.startsWith('*'))return false;
var move=_this3.battle.dex.moves.get(moveName);
return!move.isZ&&!move.isMax&&move.name!=='Mimic';
}).length>4){
text+=TL(["(More than 4 moves is usually a sign of Illusion Zoroark/Zorua.)"])+" ";
}
if(this.battle.gen===3&&clientPokemon.moveTrack.some(function(_ref4){var _=_ref4[0],pp=_ref4[1];return typeof pp!=='number';})){
text+=TL(["(Pressure is not visible in Gen 3, so in certain situations, the exact amount of PP used may be unknown.)"])+" ";
}
if(this.pokemonHasClones(clientPokemon)){
text+=TL(["(Your opponent has two indistinguishable Pok\xE9mon, making it impossible for you to tell which one has which moves/ability/item.)"])+" ";
}
text+="</p>";
}
return text;
};_proto2.

showFieldTooltip=function showFieldTooltip(){
var scene=this.battle.scene;
var buf="<table style=\"border: 0; border-collapse: collapse; vertical-align: top; padding: 0; width: 100%\"><tr>";

var atLeastOne=false;for(var _i22=0,_this$battle$sides4=
this.battle.sides;_i22<_this$battle$sides4.length;_i22++){var side=_this$battle$sides4[_i22];
var sideConditions=scene.sideConditionsLeft(side,true);
if(sideConditions)atLeastOne=true;
buf+="<td><p class=\"tooltip-section\"><strong>"+BattleLog.escapeHTML(side.name)+"</strong>"+(sideConditions||"<br />"+TL(["(no conditions)"]))+"</p></td>";
}
buf+="</tr><table>";
if(!atLeastOne)buf="";

var weatherbuf=scene.weatherLeft()||TL(["(no weather)"]);
if(weatherbuf.startsWith('<br />')){
weatherbuf=weatherbuf.slice(6);
}
buf="<p>"+weatherbuf+"</p>"+buf;
if(this.battle.dex.modid==='gen9mariomon'){
buf+="<p style=\"border-top:1px solid #888888;\">Background by <b>"+window.BattleBackdropsMario[scene.backdropImage]+"</b></p>";
if(scene.bgm)buf+="<p>\u266B <i>"+window.BattleMusicMario[scene.bgm.url].title+"</i> - <b>"+window.BattleMusicMario[scene.bgm.url].composer+"</b> \u266B</p>";
}
if(this.battle.dex.modid==='gen9rejuvenation'){
buf+="<p style=\"border-top:1px solid #888888;\">Background by <b>"+window.BattleBackdropsRejuv[scene.backdropImage]+"</b></p>";
}
return"<p>"+buf+"</p>";
};_proto2.






pokemonHasClones=function pokemonHasClones(pokemon){
var side=pokemon.side;
if(side.battle.speciesClause)return false;for(var _i24=0,_side$pokemon4=
side.pokemon;_i24<_side$pokemon4.length;_i24++){var ally=_side$pokemon4[_i24];
if(pokemon!==ally&&pokemon.searchid===ally.searchid){
return true;
}
}
return false;
};_proto2.

calculateModifiedStats=function calculateModifiedStats(clientPokemon,serverPokemon,statStagesOnly){var _clientPokemon$effect,_clientPokemon$volati;
var stats=Object.assign({},serverPokemon.stats);
var pokemon=clientPokemon||serverPokemon;
var isPowerTrick=clientPokemon==null?void 0:clientPokemon.volatiles['powertrick'];for(var _i26=0,_Dex$statNamesExceptH2=
Dex.statNamesExceptHP;_i26<_Dex$statNamesExceptH2.length;_i26++){var statName=_Dex$statNamesExceptH2[_i26];
var sourceStatName=statName;
if(isPowerTrick){
if(statName==='atk')sourceStatName='def';
if(statName==='def')sourceStatName='atk';
}
stats[statName]=serverPokemon.stats[sourceStatName];
if(!clientPokemon)continue;

var clientStatName=clientPokemon.boosts.spc&&(statName==='spa'||statName==='spd')?'spc':statName;
var boostLevel=clientPokemon.boosts[clientStatName];
if(boostLevel){
var boostTable=[1,1.5,2,2.5,3,3.5,4];
if(boostLevel>0){
stats[statName]*=boostTable[boostLevel];
}else{
if(this.battle.gen<=2)boostTable=[1,100/66,2,2.5,100/33,100/28,4];
stats[statName]/=boostTable[-boostLevel];
}
stats[statName]=Math.floor(stats[statName]);
}
}
if(statStagesOnly)return stats;

var ability=toID((_clientPokemon$effect=
clientPokemon==null?void 0:clientPokemon.effectiveAbility(serverPokemon))!=null?_clientPokemon$effect:serverPokemon.ability||serverPokemon.baseAbility
);


if(pokemon.status){
if(this.battle.gen>2&&ability==='guts'){
stats.atk=Math.floor(stats.atk*1.5);
}else if(this.battle.gen>2&&ability==='attunement'){
stats.spa=Math.floor(stats.spa*1.5);
}else if(this.battle.gen<2&&pokemon.status==='brn'){
stats.atk=Math.floor(stats.atk*0.5);
}


if(this.battle.gen<=2&&pokemon.status==='par'){
stats.spe=Math.floor(stats.spe*0.25);
}
}


if(this.battle.gen<=1){for(var _i28=0,_Dex$statNamesExceptH4=
Dex.statNamesExceptHP;_i28<_Dex$statNamesExceptH4.length;_i28++){var _statName=_Dex$statNamesExceptH4[_i28];
if(stats[_statName]>999)stats[_statName]=999;
}
return stats;
}

var item=toID(serverPokemon.item);
var speedHalvingEVItems=[
'machobrace','poweranklet','powerband','powerbelt','powerbracer','powerlens','powerweight'];

if(
ability==='klutz'&&!speedHalvingEVItems.includes(item)||
this.battle.hasPseudoWeather('Magic Room')||
clientPokemon!=null&&clientPokemon.volatiles['embargo'])
{
item='';
}

var species=this.battle.dex.species.get(serverPokemon.speciesForme).baseSpecies;
var fusionSpecies=this.battle.dex.species.get(serverPokemon.fusion).baseSpecies;
var isTransform=clientPokemon==null?void 0:clientPokemon.volatiles.transform;
var speciesName=isTransform&&clientPokemon!=null&&(_clientPokemon$volati=clientPokemon.volatiles.formechange)!=null&&_clientPokemon$volati[1]&&this.battle.gen<=4?
this.battle.dex.species.get(clientPokemon.volatiles.formechange[1]).baseSpecies:species;

var speedModifiers=[];



if(item==='lightball'&&(speciesName==='Pikachu'||fusionSpecies==='Pikachu'||speciesName==='Pikachu-Delta'||fusionSpecies==='Pikachu-Delta')&&this.battle.gen!==4){
if(this.battle.gen>4)stats.atk*=2;
stats.spa*=2;
}

if(item==='anchor'&&(speciesName==='Dhelmise'||fusionSpecies==='Dhelmise')){
stats.atk=Math.floor(stats.atk*1.5);
}

if(item==='thickclub'){
if(speciesName==='Marowak'||speciesName==='Cubone'||fusionSpecies==='Marowak'||fusionSpecies==='Cubone'){
stats.atk*=2;
}
}

if((speciesName==='Ditto'||fusionSpecies==='Ditto')&&!(clientPokemon&&'transform'in clientPokemon.volatiles)){
if(item==='quickpowder'){
speedModifiers.push(2);
}
if(item==='metalpowder'){
if(this.battle.gen===2){
stats.def=Math.floor(stats.def*1.5);
stats.spd=Math.floor(stats.spd*1.5);
}else{
stats.def*=2;
}
}
}

if(item==='goombaboots'&&(['Goomba','Goomba Stack'].includes(speciesName)||['Goomba','Goomba Stack'].includes(fusionSpecies))){
stats.spe*=2;
}

if(item==='sturdyshell'&&(['Koopa Troopa','Paratroopa','Dry Bones','Hammer Bro'].includes(speciesName)||['Koopa Troopa','Paratroopa','Dry Bones','Hammer Bro'].includes(fusionSpecies))){
stats.def*=2;
}

if(item==='dandelight'&&(speciesName==='Delcatty-Temporal'||fusionSpecies==='Delcatty-Temporal')){
stats.def=Math.floor(stats.def*1.25);
stats.spd=Math.floor(stats.spd*1.25);
}

if(item==='sharpcoral'&&(['Cubone-Orion','Marowak-Orion'].includes(speciesName)||['Cubone-Orion','Marowak-Orion'].includes(fusionSpecies))){
stats.atk*=2;
}

if(item==='arcanespellbook'&&(['Omanyte-Orion','Omastar-Orion'].includes(speciesName)||['Omanyte-Orion','Omastar-Orion'].includes(fusionSpecies))){
stats.spa*=2;
}

if(item==='focusingorb'&&(speciesName==='Clamperl-Orion'||fusionSpecies==='Clamperl-Orion')){
stats.def*=2;
stats.spd*=2;
}

if(item==='voidheart'&&(speciesName==='Volbeat-Orion'||fusionSpecies==='Volbeat-Orion')){
stats.atk=Math.floor(stats.atk*1.5);
stats.def=Math.floor(stats.def*1.5);
}

if(item==='radiantorb'&&(speciesName==='Illumise-Orion'||fusionSpecies==='Illumise-Orion')){
stats.spa=Math.floor(stats.spa*1.5);
stats.spd=Math.floor(stats.spd*1.5);
}


if(this.battle.gen<=2){
return stats;
}

var weather=this.battle.weather;
if(this.battle.abilityActive(['Air Lock','Cloud Nine'])){
weather='';
}

if(item==='choiceband'&&!(clientPokemon!=null&&clientPokemon.volatiles['dynamax'])){
stats.atk=Math.floor(stats.atk*1.5);
}
if(ability==='purepower'||ability==='hugepower'){
stats.atk*=2;
}
if(ability==='athenian'||ability==='purefocus'||ability==='genius'){
stats.spa*=2;
}
if(ability==='sharpcoral'){
stats.atk*=2;
stats.spa*=2;
stats.def=Math.floor(stats.def*0.5);
stats.spd=Math.floor(stats.spd*0.5);
}
if(ability==='hustle'||ability==='gorillatactics'&&!(clientPokemon!=null&&clientPokemon.volatiles['dynamax'])){
stats.atk=Math.floor(stats.atk*1.5);
}
if(ability==='tormented'){
stats.spa=Math.floor(stats.spa*1.5);
}
if(ability==='superconductive'&&pokemon.status==='frb'){
stats.atk=Math.floor(stats.atk*1.5);
}
if(weather){
if(this.battle.gen>=4&&this.pokemonHasType(pokemon,'Rock')&&weather==='sandstorm'){
stats.spd=Math.floor(stats.spd*1.5);
}
if(this.pokemonHasType(pokemon,'Ice')&&weather==='snowscape'){
stats.def=Math.floor(stats.def*1.5);
}
if(this.pokemonHasType(pokemon,'Ice')&&weather==='hail'&&this.battle.dex.modid==='gen9soulstones'){
stats.def=Math.floor(stats.def*1.5);
}
if(ability==='sandydefense'&&weather==='sandstorm'){
stats.spd=Math.floor(stats.spd*1.5);
stats.def=Math.floor(stats.def*1.5);
}
if(ability==='sandrush'&&weather==='sandstorm'){
speedModifiers.push(2);
}
if(['slushrush','icecleats'].includes(ability)&&(weather==='hail'||weather==='snowscape'||this.battle.hasPseudoWeather('Icy Field')||this.battle.hasPseudoWeather('Frozen Dimensional Field'))){
speedModifiers.push(2);
}
if(ability==='shadowdance'&&weather==='newmoon'){
speedModifiers.push(2);
}
if(ability==='absolution'&&weather==='newmoon'){
stats.spa=Math.floor(stats.spa*1.5);
}
if(ability==='supercell'&&['raindance','primordialsea','newmoon'].includes(weather)){
stats.spa=Math.floor(stats.spa*1.5);
}
if(weather==='hail'||weather==='snowscape'){
var allyActive=clientPokemon==null?void 0:clientPokemon.side.active;
if(allyActive){for(var _i30=0;_i30<
allyActive.length;_i30++){var ally=allyActive[_i30];
if(!ally||ally.fainted)continue;
var allyAbility=this.getAllyAbility(ally);
if(allyAbility==='Winter Gift'&&ally.getSpecies().baseSpecies==='Cherrim-Orion'){
stats.spa=Math.floor(stats.spa*1.5);
stats.spd=Math.floor(stats.spd*1.5);
}
}
}
}
if(item!=='utilityumbrella'){
if(weather==='sunnyday'||weather==='desolateland'){
if(ability==='chlorophyll'){
speedModifiers.push(2);
}
if(ability==='solarpower'&&!this.battle.hasPseudoWeather('Frozen Dimensional Field')){
stats.spa=Math.floor(stats.spa*1.5);
}
if(ability==='orichalcumpulse'){
stats.atk=Math.floor(stats.atk*1.3333);
}
var _allyActive=clientPokemon==null?void 0:clientPokemon.side.active;
if(_allyActive){for(var _i32=0;_i32<
_allyActive.length;_i32++){var _ally=_allyActive[_i32];
if(!_ally||_ally.fainted)continue;
var _allyAbility=this.getAllyAbility(_ally);
if(_allyAbility==='Flower Gift'&&(_ally.getSpecies().baseSpecies==='Cherrim'||this.battle.gen<=4)){
stats.atk=Math.floor(stats.atk*1.5);
stats.spd=Math.floor(stats.spd*1.5);
}
}
}
}
if(weather==='raindance'||weather==='primordialsea'){
if(ability==='swiftswim'){
speedModifiers.push(2);
}
}
}
}
if(ability==='defeatist'&&serverPokemon.hp<=serverPokemon.maxhp/2){
stats.atk=Math.floor(stats.atk*0.5);
stats.spa=Math.floor(stats.spa*0.5);
}
if(clientPokemon){
if(clientPokemon.volatiles['slowstart']){
stats.atk=Math.floor(stats.atk*0.5);
speedModifiers.push(0.5);
}
if(ability==='unburden'&&clientPokemon.volatiles['itemremoved']&&!item){
speedModifiers.push(2);
}for(var _i34=0,_Dex$statNamesExceptH6=
Dex.statNamesExceptHP;_i34<_Dex$statNamesExceptH6.length;_i34++){var _statName2=_Dex$statNamesExceptH6[_i34];
if(clientPokemon.volatiles['protosynthesis'+_statName2]||clientPokemon.volatiles['quarkdrive'+_statName2]){
if(_statName2==='spe'){
speedModifiers.push(1.5);
}else{
stats[_statName2]=Math.floor(stats[_statName2]*1.3);
}
}
}
}
if(pokemon.status){
if(ability==='marvelscale'){
stats.def=Math.floor(stats.def*1.5);
}
if(ability==='quickfeet'){
speedModifiers.push(1.5);
}
}
if(item==='eviolite'&&(this.battle.dex.species.get(serverPokemon.speciesForme).nfe||this.battle.dex.species.get(serverPokemon.fusion).nfe)){
stats.def=Math.floor(stats.def*1.5);
stats.spd=Math.floor(stats.spd*1.5);
}
if(this.battle.hasPseudoWeather('Grassy Terrain')){
if(ability==='grasspelt'){
stats.def=Math.floor(stats.def*1.5);
}
if(ability==='forestking'){
stats.spa=Math.floor(stats.spa*1.33);
stats.atk=Math.floor(stats.atk*1.33);
}
}
if(this.battle.hasPseudoWeather('Electric Terrain')){
if(ability==='surgesurfer'){
speedModifiers.push(2);
}
if(ability==='hadronengine'){
stats.spa=Math.floor(stats.spa*1.3333);
}
}
if(ability==='psychoslider'&&this.battle.hasPseudoWeather('Psychic Terrain')){
speedModifiers.push(2);
}
if(item==='choicespecs'&&!(clientPokemon!=null&&clientPokemon.volatiles['dynamax'])){
stats.spa=Math.floor(stats.spa*1.5);
}
if(item==='deepseatooth'&&(species==='Clamperl'||fusionSpecies==='Clamperl')){
stats.spa*=2;
}
if(item==='dragonfang'&&(species==='Clamperl-Delta'||fusionSpecies==='Clamperl-Delta')){
stats.atk*=2;
}
if(item==='souldew'&&this.battle.gen<=6&&(species==='Latios'||species==='Latias')){
stats.spa=Math.floor(stats.spa*1.5);
stats.spd=Math.floor(stats.spd*1.5);
}
if(clientPokemon&&(ability==='plus'||ability==='minus')){
var _allyActive2=clientPokemon.side.active;
if(_allyActive2.length>1){
var abilityName=ability==='plus'?'Plus':'Minus';for(var _i36=0;_i36<
_allyActive2.length;_i36++){var _ally2=_allyActive2[_i36];
if(!_ally2||_ally2===clientPokemon||_ally2.fainted)continue;
var _allyAbility2=this.getAllyAbility(_ally2);
if(_allyAbility2!=='Plus'&&_allyAbility2!=='Minus')continue;
if(this.battle.gen<=4&&_allyAbility2===abilityName)continue;
stats.spa=Math.floor(stats.spa*1.5);
break;
}
}
}
if(item==='assaultvest'){
stats.spd=Math.floor(stats.spd*1.5);
}
if(item==='deepseascale'&&(species==='Clamperl'||fusionSpecies==='Clamperl')){
stats.spd*=2;
}
if(item==='dragonscale'&&(species==='Clamperl-Delta'||fusionSpecies==='Clamperl-Delta')){
stats.def*=2;
}
if(item==='choicescarf'&&!(clientPokemon!=null&&clientPokemon.volatiles['dynamax'])){
speedModifiers.push(1.5);
}
if(['ironball','anchor'].includes(item)||speedHalvingEVItems.includes(item)){
speedModifiers.push(0.5);
}
if(item==='assaultarmor'){
stats.def=Math.floor(stats.def*1.5);
}
if(item==='wisevest'){
stats.spd=Math.floor(stats.spd*1.1);
}
if(item==='musclearmor'){
stats.def=Math.floor(stats.def*1.1);
}
if(ability==='furcoat'){
stats.def*=2;
}
if(this.battle.abilityActive('Vessel of Ruin')){
if(ability!=='vesselofruin'){
stats.spa=Math.floor(stats.spa*0.75);
}
}
if(this.battle.abilityActive('Sword of Ruin')){
if(ability!=='swordofruin'){
stats.def=Math.floor(stats.def*0.75);
}
}
if(this.battle.abilityActive('Tablets of Ruin')){
if(ability!=='tabletsofruin'){
stats.atk=Math.floor(stats.atk*0.75);
}
}
if(this.battle.abilityActive('Beads of Ruin')){
if(ability!=='beadsofruin'){
stats.spd=Math.floor(stats.spd*0.75);
}
}


if(this.battle.tier.includes('Super Staff Bros')){
if(pokemon.name==='Felucia'){
speedModifiers.push(1.5);
}
if(ability==='misspelled'){
stats.spa=Math.floor(stats.spa*1.5);
}
if(ability==='fortifyingfrost'&&weather==='snowscape'){
stats.spa=Math.floor(stats.spa*1.5);
stats.spd=Math.floor(stats.spd*1.5);
}
if(weather==='deserteddunes'&&this.pokemonHasType(pokemon,'Rock')){
stats.spd=Math.floor(stats.spd*1.25);
}
if(weather==='stormsurge'&&ability==='swiftswim'){
speedModifiers.push(2);
}
if(pokemon.status&&ability==='fortifiedmetal'){
stats.atk=Math.floor(stats.atk*1.5);
}
if(ability==='grassyemperor'&&this.battle.hasPseudoWeather('Grassy Terrain')){
stats.atk=Math.floor(stats.atk*1.3333);
}
if(ability==='magicalmysterycharge'&&this.battle.hasPseudoWeather('Electric Terrain')){
stats.spd=Math.floor(stats.spd*1.5);
}
if(ability==='youkaiofthedusk'||ability==='galeguard'){
stats.def*=2;
}
if(ability==='climatechange'){
if(weather==='snowscape'){
stats.def=Math.floor(stats.def*1.5);
stats.spd=Math.floor(stats.spd*1.5);
}
if(weather==='sunnyday'||weather==='desolateland')stats.spa=Math.floor(stats.spa*1.5);
}
if(item!=='utilityumbrella'&&ability==='ridethesun'&&(
weather==='sunnyday'||weather==='desolateland')){
speedModifiers.push(2);
}
if(ability==='soulsurfer'&&this.battle.hasPseudoWeather('Electric Terrain')){
speedModifiers.push(2);
}
if(ability==='orchardsgift'&&this.battle.hasPseudoWeather('Grassy Terrain')){
stats.spa=Math.floor(stats.spa*1.5);
stats.spd=Math.floor(stats.spd*1.5);
}
if(item==='eviolite'&&this.battle.dex.species.get(serverPokemon.speciesForme).id==='pichuspikyeared'){
stats.def=Math.floor(stats.def*1.5);
stats.spd=Math.floor(stats.spd*1.5);
}
if(this.battle.abilityActive('quagofruin')){
if(ability!=='quagofruin'){
stats.def=Math.floor(stats.def*0.85);
}
}
if(this.battle.abilityActive('clodofruin')){
if(ability!=='clodofruin'){
stats.atk=Math.floor(stats.atk*0.85);
}
}
if(this.battle.abilityActive('blitzofruin')){
if(ability!=='blitzofruin'){
speedModifiers.push(0.75);
}
}
if(this.battle.hasPseudoWeather('Anfield Atmosphere')&&ability==='youllneverwalkalone'){
stats.atk=Math.floor(stats.atk*1.25);
stats.def=Math.floor(stats.def*1.25);
stats.spd=Math.floor(stats.spd*1.25);
speedModifiers.push(1.25);
}
if(clientPokemon){
if(clientPokemon.volatiles['boiled']){
stats.spa=Math.floor(stats.spa*1.5);
}for(var _i38=0,_Dex$statNamesExceptH8=
Dex.statNamesExceptHP;_i38<_Dex$statNamesExceptH8.length;_i38++){var _statName3=_Dex$statNamesExceptH8[_i38];
if(clientPokemon.volatiles['ultramystik']){
if(_statName3==='spe'){
speedModifiers.push(1.3);
}else{
stats[_statName3]=Math.floor(stats[_statName3]*1.3);
}
}
}
}
}

if(item==='ariadoscrest'&&species==='Ariados'){
speedModifiers.push(1.5);
}
if(item==='cofagriguscrest'&&species==='Cofagrigus'){
stats.spa=Math.floor(stats.spa*1.25);
stats.spd=Math.floor(stats.spd*1.25);
}
if(item==='crabominablecrest'&&species==='Crabominable'){
stats.def=Math.floor(stats.def*1.2);
stats.spd=Math.floor(stats.spd*1.2);
}
if(item==='cryogonalcrest'&&species==='Cryogonal'){
stats.spd=Math.floor(stats.spd*1.2);
stats.atk=Math.floor(stats.atk+stats.spd*0.1);
stats.def=Math.floor(stats.def+stats.spd*0.1);
stats.spa=Math.floor(stats.spa+stats.spd*0.1);
stats.spe=Math.floor(stats.spe+stats.spd*0.1);
}
if(item==='delcattycrest'&&species==='Delcatty'){
var delcattyatk=0;
var delcattydef=0;
var delcattyspa=0;
var delcattyspd=0;
var delcattyspe=0;
var allyParty=this.battle.myAllyPokemon;
if(allyParty){
for(var i=0;i<allyParty.length;i++){
var poke=allyParty[i];
if(poke.fainted)continue;
delcattyatk+=Math.floor(poke.stats.atk*0.1);
delcattydef+=Math.floor(poke.stats.def*0.1);
delcattyspa+=Math.floor(poke.stats.spa*0.1);
delcattyspd+=Math.floor(poke.stats.spd*0.1);
delcattyspe+=Math.floor(poke.stats.spe*0.1);
}
stats.atk=Math.floor(stats.atk+delcattyatk);
stats.def=Math.floor(stats.def+delcattydef);
stats.spa=Math.floor(stats.spa+delcattyspa);
stats.spd=Math.floor(stats.spd+delcattyspd);
stats.spe=Math.floor(stats.spe+delcattyspe);
}
}
if(item==='dusknoircrest'&&species==='Dusknoir'){
stats.atk=Math.floor(stats.atk*1.5);
}
if(item==='empoleoncrest'&&species==='Empoleon'){
if(['Hail','Snow'].includes(weather)||this.battle.hasPseudoWeather('Icy Field')||this.battle.hasPseudoWeather('Snowy Mountain')||this.battle.hasPseudoWeather('Frozen Dimensional Field')){
speedModifiers.push(2);
}
}
if(item==='infernapecrest'&&species==='Infernape'){var _ref5=
[stats.def,stats.atk,stats.spd,stats.spa];stats.atk=_ref5[0];stats.def=_ref5[1];stats.spa=_ref5[2];stats.spd=_ref5[3];
}
if(item==='magcargocrest'&&species==='Magcargo'){var _ref6=
[stats.spe,stats.def];stats.def=_ref6[0];stats.spe=_ref6[1];
stats.spa=Math.floor(stats.spa*1.1);
}
if(item==='noctowlcrest'&&species==='Noctowl'){
stats.def=Math.floor(stats.def*1.2);
}
if(item==='oricoriocrest'&&species==='Oricorio'){
stats.spa=Math.floor(stats.spa*1.25);
speedModifiers.push(1.25);
}
if(item==='phionecrest'&&species==='Phione'){
stats.def=Math.floor(stats.def*1.5);
stats.spd=Math.floor(stats.spd*1.5);
}
if(item==='relicanthcrest'&&species==='Relicanth'){
stats.atk=Math.floor(stats.atk*1.2);
stats.spd=Math.floor(stats.spd*1.3);
}
if(item==='sevipercrest'&&species==='Seviper'){
speedModifiers.push(1.5);
}
if(item==='simipourcrest'&&species==='Simipour'){
stats.atk=Math.floor(stats.atk*1.2);
stats.spa=Math.floor(stats.spa*1.2);
}
if(item==='simisagecrest'&&species==='Simisage'){
stats.atk=Math.floor(stats.atk*1.2);
stats.spa=Math.floor(stats.spa*1.2);
}
if(item==='simisearcrest'&&species==='Simisear'){
stats.atk=Math.floor(stats.atk*1.2);
stats.spa=Math.floor(stats.spa*1.2);
}
if(item==='skuntankcrest'&&species==='Skuntank'){
stats.atk=Math.floor(stats.atk*1.2);
stats.spa=Math.floor(stats.spa*1.2);
}
if(item==='stantlercrest'&&['stantler','Wyrdeer'].includes(species)){
stats.atk=Math.floor(stats.atk*1.5);
}
if(item==='whiscashcrest'&&species==='Whiscash'){
stats.atk=Math.floor(stats.atk*1.2);
stats.spa=Math.floor(stats.spa*1.2);
}


if(this.battle.dex.modid==='gen9rejuvenation'){


if(ability==='lunaridol'&&(weather==='hail'||weather==='snow')){
stats.spa=Math.floor(stats.spa*1.5);
}
if(ability==='solaridol'&&(weather==='sunnyday'||weather==='desolateland')){
stats.atk=Math.floor(stats.atk*1.5);
}

if(this.battle.hasPseudoWeather('Grassy Terrain')&&!pokemon.status&&ability==='quickfeet'){
speedModifiers.push(1.5);
}
if((this.battle.hasPseudoWeather('Misty Terrain')||this.battle.hasPseudoWeather('Dragons Den Field'))&&!pokemon.status&&pokemon.ability==='marvelscale'){
stats.def=Math.floor(stats.def*1.5);
}
if((this.battle.hasPseudoWeather('Water Surface Field')||this.battle.hasPseudoWeather('Underwater Field')||this.battle.hasPseudoWeather(' Murkwater Surface Field'))&&['surgesurfer','swiftswim'].includes(ability)){
speedModifiers.push(2);
}
if(this.battle.hasPseudoWeather('Misty Terrain')&&this.pokemonHasType(pokemon,'Fairy')){
stats.spd=Math.floor(stats.spd*1.5);
}
if(this.battle.hasPseudoWeather('Icy Field')&&this.pokemonHasType(pokemon,'Ice')&&weather==='hail'){
stats.def=Math.floor(stats.def*1.5);
}
if(this.battle.hasPseudoWeather('Water Surface Field')&&!this.pokemonHasType(pokemon,'Water')&&!(pokemon.ability==='surgesurfer'||pokemon.ability==='swiftswim')){
speedModifiers.push(0.75);
}
if(this.battle.hasPseudoWeather('Underwater Field')&&!this.pokemonHasType(pokemon,'Water')&&!(pokemon.ability==='surgesurfer'||pokemon.ability==='swiftswim')){
speedModifiers.push(0.5);
}
if(this.battle.hasPseudoWeather('Murkwater Surface Field')&&!this.pokemonHasType(pokemon,'Water')&&!(pokemon.ability==='surgesurfer'||pokemon.ability==='swiftswim')){
speedModifiers.push(0.75);
}
if(this.battle.hasPseudoWeather('Dragons Den Field')&&this.pokemonHasType(pokemon,'Dragon')){
stats.def=Math.floor(stats.def*1.3);
stats.spd=Math.floor(stats.spd*1.3);
}
if(this.battle.hasPseudoWeather('Frozen Dimensional Field')&&(this.pokemonHasType(pokemon,'Ice')||this.pokemonHasType(pokemon,'Ghost'))){
stats.def=Math.floor(stats.def*1.2);
stats.spd=Math.floor(stats.spd*1.2);
}
if(this.battle.hasPseudoWeather('Frozen Dimensional Field')&&this.pokemonHasType(pokemon,'Fire')){
stats.def=Math.floor(stats.def*0.8);
stats.spd=Math.floor(stats.spd*0.8);
}

}

var sideConditions=this.battle.mySide.sideConditions;
if(sideConditions['tailwind']){
speedModifiers.push(2);
}
if(sideConditions['grasspledge']){
speedModifiers.push(0.25);
}

var chainedSpeedModifier=1;for(var _i40=0;_i40<
speedModifiers.length;_i40++){var modifier=speedModifiers[_i40];
chainedSpeedModifier*=modifier;
}

stats.spe*=chainedSpeedModifier;
stats.spe=stats.spe%1>0.5?Math.ceil(stats.spe):Math.floor(stats.spe);

if(pokemon.status==='par'&&ability!=='quickfeet'){
if(this.battle.gen>6){
stats.spe=Math.floor(stats.spe*0.5);
}else{
stats.spe=Math.floor(stats.spe*0.25);
}
}

return stats;
};_proto2.

renderStats=function renderStats(clientPokemon,serverPokemon,short){
var isTransformed=clientPokemon==null?void 0:clientPokemon.volatiles.transform;
if(!serverPokemon||isTransformed){
if(!clientPokemon)throw new Error('Must pass either clientPokemon or serverPokemon');
var _this$getSpeedRange=this.getSpeedRange(clientPokemon),min=_this$getSpeedRange.min,ev0=_this$getSpeedRange.ev0,ev84=_this$getSpeedRange.ev84,ev252=_this$getSpeedRange.ev252,max=_this$getSpeedRange.max;
var speedName=TL.statShort.spe||'Spe';
var speedRange=TL([""," to ",""],min,max);
if(this.battle.gen<3){
var beforeStatStages=TL(["(before stat stage changes)"]);
if(this.battle.tier.includes('Random')){
return"<p><small>"+speedName+"</small> "+max+" <small>"+beforeStatStages+"</small></p>";
}
return"<p><small>"+speedName+"</small> "+speedRange+" <small>"+beforeStatStages+"</small></p>";
}
var beforeExternalModifiers=TL(["(before external modifiers)"]);
if(this.battle.tier.includes('Random')){
return"<p><small>"+speedName+"</small> "+min+TL([" or "])+ev84+" <small>"+beforeExternalModifiers+"</small></p>";
}else if(this.battle.tier.includes("Let's Go")){
return"<p><small>"+speedName+"</small> "+min+"<small class=\"gray\">&ndash;"+ev0+"&ndash;</small>"+max+" <small>"+beforeExternalModifiers+"</small></p>";
}else if(clientPokemon.nature){

return"<p><small>"+speedName+"</small> "+speedRange+" <small>"+beforeExternalModifiers+"</small></p>";
}else{
return"<p><small>"+speedName+"</small> "+min+"<small class=\"gray\">&ndash;"+ev0+"&ndash;"+ev252+"&ndash;</small>"+max+"<br><small>"+beforeExternalModifiers+"</small></p>";
}
}
var stats=serverPokemon.stats;
console.log(clientPokemon);
console.log(serverPokemon);
var modifiedStats=this.calculateModifiedStats(clientPokemon,serverPokemon);

var buf='<p>';

if(!short){
var hasModifiedStat=false;for(var _i42=0,_Dex$statNamesExceptH10=
Dex.statNamesExceptHP;_i42<_Dex$statNamesExceptH10.length;_i42++){var statName=_Dex$statNamesExceptH10[_i42];
if(this.battle.gen===1&&statName==='spd')continue;
var statLabel=this.battle.gen===1&&statName==='spa'?'spc':statName;
buf+=statName==='atk'?'<small>':'<small> / ';
buf+=(TL.statShort[statLabel]||statLabel)+"&nbsp;</small>";
buf+=""+stats[statName];
if(modifiedStats[statName]!==stats[statName])hasModifiedStat=true;
}
buf+='</p>';

if(!hasModifiedStat)return buf;

buf+="<p><small>"+TL(["(After stat modifiers:)"])+"</small></p>";
buf+='<p>';
}for(var _i44=0,_Dex$statNamesExceptH12=

Dex.statNamesExceptHP;_i44<_Dex$statNamesExceptH12.length;_i44++){var _statName4=_Dex$statNamesExceptH12[_i44];
if(this.battle.gen===1&&_statName4==='spd')continue;
var _statLabel=this.battle.gen===1&&_statName4==='spa'?'spc':_statName4;
buf+=_statName4==='atk'?'<small>':'<small> / ';
buf+=(TL.statShort[_statLabel]||_statLabel)+"&nbsp;</small>";
if(modifiedStats[_statName4]===stats[_statName4]){
buf+=""+modifiedStats[_statName4];
}else if(modifiedStats[_statName4]<stats[_statName4]){
buf+="<strong class=\"stat-lowered\">"+modifiedStats[_statName4]+"</strong>";
}else{
buf+="<strong class=\"stat-boosted\">"+modifiedStats[_statName4]+"</strong>";
}
}
buf+='</p>';
return buf;
};_proto2.

getPPUseText=function getPPUseText(moveTrackRow,showKnown){
var moveName=moveTrackRow[0],ppUsed=moveTrackRow[1];
var move;
var maxpp;
if(moveName.startsWith('*')){

move=this.battle.dex.moves.get(moveName.substr(1));
maxpp=5;
}else{
move=this.battle.dex.moves.get(moveName);
maxpp=move.pp===1||move.noPPBoosts?move.pp:move.pp*8/5;
if(this.battle.gen<3)maxpp=Math.min(61,maxpp);
if(this.battle.tier.includes('Champions')){
var pp=move.pp>20?20:move.pp;
maxpp=pp===1||move.noPPBoosts?pp:(pp/5+1)*4;
}
}
var bullet=moveName.startsWith('*')||move.isZ?'<span style="color:#888">&#8226;</span>':'&#8226;';
if(ppUsed===Infinity){
return bullet+" "+TL(move)+" <small>(0/"+maxpp+")</small>";
}
if(ppUsed||moveName.startsWith('*')){
if(typeof ppUsed==='number'){
return bullet+" "+TL(move)+" <small>("+(maxpp-ppUsed)+"/"+maxpp+")</small>";
}else{
var low=maxpp-ppUsed[0]+"/"+maxpp;
var high=maxpp-ppUsed[1]+"/"+maxpp;
var range=TL(["("," to ",")"],low,high);
return bullet+" "+TL(move)+" <small>"+range+"</small>";
}
}
return bullet+" "+TL(move)+" "+(showKnown?" <small>"+TL(["(revealed)"])+"</small>":'');
};_proto2.

ppUsed=function ppUsed(move,pokemon){for(var _i46=0,_pokemon$moveTrack2=
pokemon.moveTrack;_i46<_pokemon$moveTrack2.length;_i46++){var _ref7=_pokemon$moveTrack2[_i46];var moveName=_ref7[0];var _ppUsed=_ref7[1];
if(moveName.startsWith('*'))moveName=moveName.substr(1);
if(move.name===moveName)return _ppUsed;
}
return 0;
};_proto2.




getSpeedRange=function getSpeedRange(pokemon){var _pokemon$volatiles$tr;
var tr=Math.trunc||Math.floor;
var species=pokemon.getSpecies();
var rules=this.battle.rules;
var baseSpe=species.baseStats.spe;
if(pokemon.fusion)baseSpe=Math.floor(baseSpe/3+this.battle.dex.species.get(pokemon.fusion).baseStats.spe*2/3);
if(rules['Scalemons Mod']){
var bstWithoutHp=species.bst-species.baseStats.hp;
var scale=600-species.baseStats.hp;
baseSpe=tr(baseSpe*scale/bstWithoutHp);
if(baseSpe<1)baseSpe=1;
if(baseSpe>255)baseSpe=255;
}
if(rules['Frantic Fusions Mod']){
var fusionSpecies=this.battle.dex.species.get(pokemon.name);
if(fusionSpecies.exists&&fusionSpecies.name!==species.name){
baseSpe+=tr(fusionSpecies.baseStats.spe/4);
if(baseSpe<1)baseSpe=1;
if(baseSpe>255)baseSpe=255;
}
}
if(rules['Flipped Mod']){
baseSpe=species.baseStats.hp;
if(baseSpe<1)baseSpe=1;
if(baseSpe>255)baseSpe=255;
}
if(rules['350 Cup Mod']&&species.bst<=350){
baseSpe*=2;
if(baseSpe<1)baseSpe=1;
if(baseSpe>255)baseSpe=255;
}
var level=((_pokemon$volatiles$tr=pokemon.volatiles.transform)==null?void 0:_pokemon$volatiles$tr[4])||pokemon.level;
var tier=this.battle.tier;
var gen=this.battle.gen;
var isCGT=tier.includes('Computer-Generated Teams');

var minNatureMult=0.9;
var maxNatureMult=1.1;
if(tier.includes('Random')){
minNatureMult=1;
maxNatureMult=1;
}
if(pokemon.nature){
var natureVals=BattleNatures[pokemon.nature];
if(natureVals.minus==='spe')maxNatureMult=0.9;else
if(natureVals.plus==='spe')minNatureMult=1.1;else
{
minNatureMult=1;
maxNatureMult=1;
}
}

var min;
var ev0;
var ev84;
var ev252;
var max;
if(tier.includes("Let's Go")){
min=tr(tr(tr(2*baseSpe*level/100+5)*minNatureMult)*tr((70/255/10+1)*100)/100);
ev0=tr(tr(tr((2*baseSpe+31)*level/100+5))*tr((70/255/10+1)*100)/100);
ev84=tr(tr(tr((2*baseSpe+31)*level/100+5))*tr((70/255/10+1)*100)/100);
ev252=tr(tr(tr((2*baseSpe+31+63)*level/100+5))*tr((70/255/10+1)*100)/100);
max=tr(tr(tr((2*baseSpe+31)*level/100+5)*maxNatureMult)*tr((70/255/10+1)*100)/100);
if(tier.includes('No Restrictions'))max+=200;else
if(tier.includes('Random'))max+=20;
}else if(tier.includes('Champions')){
min=tr(minNatureMult*(baseSpe+20));
ev0=tr((2*baseSpe+31)*level/100)+5;
ev84=tr((2*baseSpe+31+21)*level/100)+5;
ev252=tr(baseSpe+32+20);
max=tr(maxNatureMult*(baseSpe+32+20));
}else if(gen<3){
max=tr((2*baseSpe+30+63)*level/100+5);
ev252=max;
ev84=0;
ev0=tr((2*baseSpe+30)*level/100+5);
min=isCGT?max:tr(2*baseSpe*level/100+5);
}else{
max=tr(tr((2*baseSpe+94)*level/100+5)*maxNatureMult);
ev252=tr(tr((2*baseSpe+94)*level/100+5));
ev84=tr(tr((2*baseSpe+31+21)*level/100+5));
ev0=tr(tr((2*baseSpe+31)*level/100+5));
min=isCGT?max:tr(tr(2*baseSpe*level/100+5)*minNatureMult);
}
return{min:min,ev0:ev0,ev84:ev84,ev252:ev252,max:max};
};_proto2.




getMoveType=function getMoveType(
move,value,forMaxMove)
{
var pokemon=value.pokemon;
var serverPokemon=value.serverPokemon;

var moveType=move.type;
var category=move.category;
if(category==='Status'&&forMaxMove)return['Normal','Status'];

if(!pokemon)return[moveType,category];

var pokemonTypes=pokemon.getTypeList(serverPokemon);
value.reset();
if(move.id==='revelationdance'){
moveType=pokemonTypes[0];
if(pokemonTypes[0]==='???'||pokemonTypes[0]==='Bird'){
moveType=pokemonTypes[1]||pokemonTypes[0];
}
}

var item=this.battle.dex.items.get(value.itemName);
if(move.id==='multiattack'&&item.onMemory){
if(value.itemModify(0))moveType=item.onMemory;
}
if(move.id==='judgment'&&item.onPlate&&!item.zMoveType){
if(value.itemModify(0))moveType=item.onPlate;
}
if(move.id==='technoblast'&&item.onDrive){
if(value.itemModify(0))moveType=item.onDrive;
}
if(move.id==='naturalgift'&&item.naturalGift){
if(value.itemModify(0))moveType=item.naturalGift.type;
}

if(move.id==='weatherball'){
var rejuv=this.battle.dex.modid==='gen9rejuvenation';
if(value.abilityModify(0,'Mega Sol')){
moveType='Fire';
}else if(value.weatherModify(0)){
switch(this.battle.weather){
case'sunnyday':
case'desolateland':
if(value.tryItem('Utility Umbrella'))break;
moveType='Fire';
break;
case'raindance':
case'primordialsea':
if(value.tryItem('Utility Umbrella'))break;
moveType='Water';
break;
case'sandstorm':
moveType='Rock';
break;
case'hail':
case'snow':
moveType='Ice';
break;
case'snowscape':
if(!rejuv)moveType='Ice';
break;
case'deltastream':
if(rejuv)moveType='Flying';
break;
case'shadowsky':
if(rejuv)moveType='???';
break;
case'newmoon':
if(!rejuv)moveType='Dark';
break;
case'thunderstorm':
if(!rejuv)moveType='Electric';
break;
}
}
}
if(move.id==='terrainpulse'&&pokemon.isGrounded(serverPokemon)){
moveType=this.getFieldMoves(item)[1];
}
if(move.id==='terablast'&&pokemon.terastallized){
moveType=pokemon.terastallized;
}
if(move.id==='terastarstorm'&&pokemon.getSpeciesForme()==='Terapagos-Stellar'){
moveType='Stellar';
}


if(move.id==='aurawheel'&&[pokemon.getSpeciesForme(),pokemon.fusion].includes('Morpeko-Hangry')){
moveType='Dark';
}

if(move.id==='ragingbull'){
var forme=pokemon.getSpeciesForme().includes('Tauros-Paldea')?pokemon.getSpeciesForme():pokemon.fusion;
switch(forme){
case'Tauros-Paldea-Combat':
moveType='Fighting';
break;
case'Tauros-Paldea-Blaze':
moveType='Fire';
break;
case'Tauros-Paldea-Aqua':
moveType='Water';
break;
}
}

if(move.id==='ivycudgel'){
var _forme=pokemon.getSpeciesForme().includes('Ogerpon')?pokemon.getSpeciesForme():pokemon.fusion;
switch(_forme){
case'Ogerpon-Wellspring':case'Ogerpon-Wellspring-Tera':
moveType='Water';
break;
case'Ogerpon-Hearthflame':case'Ogerpon-Hearthflame-Tera':
moveType='Fire';
break;
case'Ogerpon-Cornerstone':case'Ogerpon-Cornerstone-Tera':
moveType='Rock';
break;
}
}


var noTypeOverride=[
'judgment','multiattack','naturalgift','revelationdance','struggle','technoblast','terrainpulse','weatherball'];

var allowTypeOverride=!noTypeOverride.includes(move.id)&&(move.id!=='terablast'||!pokemon.terastallized);
if(allowTypeOverride){
if(this.battle.rules['Revelationmons Mod']){
var _pokemon$getTypes=pokemon.getTypes(serverPokemon),types=_pokemon$getTypes[0];
for(var i=0;i<types.length;i++){
if(serverPokemon.moves[i]&&move.id===toID(serverPokemon.moves[i])){
moveType=types[i];
}
}
}

if(!(move.isZ&&move.category!=='Status')&&!move.id.startsWith('hiddenpower')){
if(moveType==='Normal'){
if(value.abilityModify(0,'Aerilate'))moveType='Flying';
if(value.abilityModify(0,'Dragonize'))moveType='Dragon';
if(value.abilityModify(0,'Galvanize'))moveType='Electric';
if(value.abilityModify(0,'Pixilate'))moveType='Fairy';
if(value.abilityModify(0,'Refrigerate'))moveType='Ice';
if(value.abilityModify(0,'Intoxicate'))moveType='Poison';
if(value.abilityModify(0,'Atomizate'))moveType='Nuclear';
if(value.abilityModify(0,'Energizate'))moveType='Electric';
if(value.abilityModify(0,'Transmutate'))moveType='Psychic';
if(value.abilityModify(0,'Dark Matter'))moveType='Cosmic';
if(this.battle.dex.modid==='gen9soulstones'&&value.abilityModify(0,'Illuminate'))moveType='Light';
}
if(moveType==='Rock'){
if(value.abilityModify(0,'Foundry'))moveType='Fire';
}
if(moveType==='Light'){
if(value.abilityModify(0,'Black Light'))moveType='Dark';
}
if(moveType==='Dark'){
if(value.abilityModify(0,'Whiteout'))moveType='Light';
}
if(value.abilityModify(0,'Normalize'))moveType='Normal';
}


var isSound=!!(
forMaxMove?
this.getMaxMoveFromType(moveType,forMaxMove!==true&&forMaxMove||undefined):move).
flags['sound'];
if(isSound&&value.abilityModify(0,'Liquid Voice')&&
!(this.battle.dex.modid==='gen9rejuvenation'&&this.battle.hasPseudoWeather('Icy Field'))){
moveType='Water';
}
}

if(move.id==='photongeyser'||move.id==='lightthatburnsthesky'||
move.id==='terablast'&&pokemon.terastallized||
move.id==='terastarstorm'&&pokemon.getSpeciesForme()==='Terapagos-Stellar'){
var stats=this.calculateModifiedStats(pokemon,serverPokemon,true);
if(stats.atk>stats.spa)category='Physical';
}
if(move.flags.bite&&value.abilityModify(0,'Spectral Jaws'))category='Special';


if(this.battle.tier.includes('Super Staff Bros')){
if(allowTypeOverride&&category!=="Status"&&!move.isZ&&!move.id.startsWith('hiddenpower')){
if(value.abilityModify(0,'Acetosa'))moveType='Grass';
if(value.abilityModify(0,'I Can Hear The Heart Beating As One')&&moveType==='Normal')moveType='Fairy';
}
if(move.id==='tsignore'||move.id==='o'){
var _stats=this.calculateModifiedStats(pokemon,serverPokemon,true);
if(_stats.atk>_stats.spa)category='Physical';
}
if(move.id==='tsignore'&&pokemon.getSpeciesForme().startsWith('Meloetta')&&
pokemon.terastallized){
moveType='Stellar';
}
if(move.id==='weatherball'&&value.weatherModify(0)){
if(this.battle.weather==='stormsurge'&&!value.tryItem('Utility Umbrella'))moveType='Water';
if(this.battle.weather==='deserteddunes')moveType='Rock';
}
if(move.id==='o'||move.id==='worriednoises'){
moveType=pokemonTypes[0];
}
if(move.id==='dillydally'){
moveType=pokemonTypes[pokemonTypes.length-1];
}
if(move.id==='magicalfocus'){
if(this.battle.turn%3===1){
moveType='Fire';
}else if(this.battle.turn%3===2){
moveType='Electric';
}else{
moveType='Ice';
}
}
if(move.id==='hydrostatics'&&pokemon.terastallized){
moveType='Water';
}
if(move.id==='asongoficeandfire'&&pokemon.getSpeciesForme()==='Volcarona')moveType='Ice';
if(this.battle.abilityActive('dynamictyping')){
moveType='???';
}
if(move.id==='alting'){
moveType='???';
if(pokemon.shiny){
category='Special';
}
}
}
if(this.battle.dex.modid==='gen9rejuvenation'){
if(!forMaxMove&&move.id==='rage'&&this.battle.hasPseudoWeather('Frozen Dimensional Field')){
moveType='Dark';
}else if(!forMaxMove&&['cut','sacredsword','secretsword','slash'].includes(move.id)&&
this.battle.hasPseudoWeather('Fairy Tale Field')){
moveType='Steel';
}else if(this.battle.hasPseudoWeather('Glitch Field')){
if(moveType==='Fairy')moveType='Normal';
if(category!=='Status'){
if(Dex.getGen3Category(moveType)==='Special')category='Special';
if(['Normal','Fighting','Flying','Poison','Ground','Rock','Bug','Ghost','Steel'].includes(moveType)){
category='Physical';
}
}
}
}

return[moveType,category];
};BattleTooltips.
getTypeAbilityWeakness=function getTypeAbilityWeakness(attackType,abilityid){var dex=arguments.length>2&&arguments[2]!==undefined?arguments[2]:Dex;var strict=arguments.length>3?arguments[3]:undefined;
if(attackType==='Ground'&&['levitate','eelevate'].includes(abilityid))return 0;
if(attackType==='Water'&&abilityid==='dryskin')return 0;
if(attackType==='Fire'&&abilityid==='flashfire')return 0;
if(attackType==='Electric'&&abilityid==='lightningrod'&&dex.gen>=5)return 0;
if(attackType==='Grass'&&abilityid==='sapsipper')return 0;
if(attackType==='Electric'&&abilityid==='motordrive')return 0;
if(attackType==='Water'&&abilityid==='stormdrain'&&dex.gen>=5)return 0;
if(attackType==='Electric'&&abilityid==='voltabsorb')return 0;
if(attackType==='Water'&&abilityid==='waterabsorb')return 0;
if(attackType==='Ground'&&abilityid==='eartheater')return 0;
if(attackType==='Fire'&&abilityid==='wellbakedbody')return 0;

if(attackType==='Fire'&&abilityid==='primordialsea'&&!strict)return 0;
if(attackType==='Water'&&abilityid==='desolateland'&&!strict)return 0;

var factor=1;
if((attackType==='Fire'||attackType==='Ice')&&abilityid==='thickfat')factor*=0.5;
if(attackType==='Fire'&&abilityid==='waterbubble')factor*=0.5;
if(attackType==='Fire'&&abilityid==='heatproof')factor*=0.5;
if(attackType==='Ghost'&&abilityid==='purifyingsalt')factor*=0.5;
if(attackType==='Fire'&&abilityid==='fluffy')factor*=2;
if((attackType==='Electric'||attackType==='Rock'||attackType==='Ice')&&abilityid==='deltastream'){
factor*=0.5;
}
return factor;
};_proto2.
getMoveEffectiveness=function getMoveEffectiveness(
source,move,attackType,category,target)
{
if([
'adjacentAlly','adjacentAllyOrSelf','self','allySide','foeSide','all'].
includes(move.target)){
return 1;
}
var hardcoreMode=this.battle.hardcoreMode;
var inverse=this.battle.rules['Inverse Mod'];
var targetTypes=target.getTypeList();
var sourceAbility=source.effectiveAbility();

var targetAbility=hardcoreMode||[
'Mold Breaker','Teravolt','Turboblaze'].
includes(sourceAbility)?'':target.effectiveAbility();
var dex=this.battle.dex;
var priority=move.priority+(category==='Status'&&sourceAbility==='Prankster'?1:0);

if(hardcoreMode&&(move.category==='Status'||dex.gen<7))return null;
if(move.id==='struggle'&&dex.gen>1)return 1;

var inflictsStatus=null;
var inflictsEffect=null;
if(category==='Status'){
if(['glare','stunspore','thunderwave'].includes(move.id))inflictsStatus='par';
if(['toxic','poisongas','poisonpowder'].includes(move.id))inflictsStatus='psn';
if([
'darkvoid','grasswhistle','hypnosis','lovelykiss','sing','sleeppowder','spore','yawn'].
includes(move.id))inflictsStatus='slp';
if(move.id==='willowisp')inflictsStatus='brn';
if(move.id==='chillingtouch')inflictsStatus='frb';
if(['block','meanlook','spiderweb'].includes(move.id))inflictsEffect='trapped';
if(['confuseray','supersonic','sweetkiss','teeterdance'].includes(move.id))inflictsEffect='confusion';
}


var otherFactor=BattleTooltips.getTypeAbilityWeakness(attackType,toID(targetAbility),dex,true);

if(category==='Status'&&dex.gen<=3)otherFactor=1;

var factor=1;
if(!otherFactor&&(targetAbility==="Levitate"||targetAbility==="Eelevate")){
otherFactor=1;
if(!target.isGrounded()&&move.id!=='thousandarrows'&&!hardcoreMode){
factor=0;
}
}for(var _i48=0;_i48<
targetTypes.length;_i48++){var _tType$damageTaken,_tType$damageTaken2,_tType$damageTaken3,_tType$damageTaken4;var targetType=targetTypes[_i48];
var tType=dex.types.get(targetType);


if(inflictsStatus&&((_tType$damageTaken=tType.damageTaken)==null?void 0:_tType$damageTaken[inflictsStatus||inflictsEffect])===Dex.IMMUNE){
if(!(inflictsStatus==='psn'&&sourceAbility==='Corrosion')){
return 0;
}
}
if(category==='Status'&&sourceAbility==='Prankster'&&((_tType$damageTaken2=tType.damageTaken)==null?void 0:_tType$damageTaken2['prankster'])===Dex.IMMUNE){
return 0;
}
if(move.flags['powder']&&((_tType$damageTaken3=tType.damageTaken)==null?void 0:_tType$damageTaken3['powder'])===Dex.IMMUNE)otherFactor=0;
if(move.flags['powder']&&targetAbility==='Overcoat'&&dex.gen>=6)otherFactor=0;
if(move.flags['sound']&&targetAbility==='Soundproof')otherFactor=0;
if(move.flags['bullet']&&targetAbility==='Bulletproof')otherFactor=0;


if(((_tType$damageTaken4=tType.damageTaken)==null?void 0:_tType$damageTaken4[attackType])===Dex.IMMUNE){
if(target.item==='Ring Target')continue;
if(targetType==='Ghost'&&(sourceAbility==="Scrappy"||sourceAbility==="Mind's Eye"))continue;
if(targetType==='Ghost'&&(target.volatiles['foresight']||target.volatiles['odorsleuth']))continue;
if(targetType==='Dark'&&target.volatiles['miracleeye'])continue;
if(targetType==='Flying'&&target.isGrounded())continue;
if(targetType==='Flying'&&move.id==='thousandarrows'&&!target.isGrounded()){
factor=1;
break;
}




if(inverse){
factor*=0.5;
}else{
factor=0;
}
}else if(move.id==='freezedry'&&targetType==='Water'){
factor*=2;
}else{var _ref8,_tType$damageTaken5;
factor*=(_ref8=[1,2,0.5,0][((_tType$damageTaken5=tType.damageTaken)==null?void 0:_tType$damageTaken5[attackType])||0])!=null?_ref8:1;
}
if(move.id==='sheercold'&&targetType==='Ice')otherFactor=0;
}


if(category!=='Status'&&attackType==='Ground'&&factor&&!target.isGrounded())otherFactor=0;
if(this.battle.hasPseudoWeather('Misty Terrain')&&target.isGrounded()&&inflictsStatus){
return 0;
}
if(this.battle.hasPseudoWeather('Psychic Terrain')&&target.isGrounded()&&priority>0){
otherFactor=0;
}
if(this.battle.weather==='primordialsea'&&attackType==='Fire'&&move.category!=='Status'){
otherFactor=0;
}
if(this.battle.weather==='desolateland'&&attackType==='Water'&&move.category!=='Status'){
otherFactor=0;
}


if(target.status&&inflictsStatus){
if(dex.gen===1&&inflictsStatus==='slp'&&target.volatiles['mustrecharge']){

}else{
return 0;
}
}
if(targetAbility==="Comatose"&&inflictsStatus)return 0;
if(targetAbility==="Purifying Salt"&&inflictsStatus)return 0;
if(targetAbility==="Shields Down"&&target.speciesForme==='Minior-Meteor'&&inflictsStatus)return 0;
if(targetAbility==="Leaf Guard"&&this.battle.weather==='sunnyday'&&inflictsStatus)return 0;
if(targetAbility==="Sweet Veil"&&inflictsStatus==='slp')return 0;
if(targetAbility==="Pastel Veil"&&inflictsStatus==='psn')return 0;
if(["Water Veil","Water Bubble","Thermal Exchange"].includes(targetAbility)&&inflictsStatus==='brn')return 0;

if(targetAbility==='Wonder Guard'&&factor<2&&category!=='Status')otherFactor=0;
if(targetAbility==="Good as Gold"&&category==='Status')return 0;
if(targetAbility==="Own Tempo"&&inflictsEffect==='confusion')return 0;
if(sourceAbility==='Tinted Lens'&&factor<1)otherFactor*=2;
if(targetAbility==='Sturdy'&&move.ohko)otherFactor=0;
if(targetAbility==='Damp'&&[
'explosion','mindblown','mistyexplosion','selfdestruct'].
includes(move.id))otherFactor=0;
if(targetAbility==='Aroma Veil'&&[
'disable','encore','healblock','taunt','torment','attract'].
includes(move.id))return 0;

if(category==='Status'){
if(target.volatiles['substitute']&&!move.flags['bypasssub']&&sourceAbility!=='Infiltrator'){
if(dex.gen!==1)return 0;
if(inflictsStatus!=='par'&&inflictsStatus!=='slp'&&inflictsEffect!=='confusion')return 0;
}
if(move.id==='thunderwave')return factor*otherFactor===0?0:null;
return otherFactor===0?0:null;
}

if(

move.damage||move.ohko||

move.id==='comeuppance'||move.id==='counter'||move.id==='mirrorcoat'||move.id==='metalburst'||

move.id==='endeavor'||move.id==='bide'||move.id==='ruination'||move.id==='superfang'||
move.id==='finalgambit'||move.id==='guardianofalola'||move.id==='naturesmadness'||move.id==='psywave')
{
if(hardcoreMode)return null;
return factor*otherFactor===0?0:1;
}
if(hardcoreMode&&dex.gen<=9){
if(factor>2)factor=2;
if(factor<0.5)factor=0.5;
if(inverse&&dex.gen>=7)return 1/factor;
return factor;
}
if(hardcoreMode){
if(inverse&&dex.gen>=7)return 1/factor;
return factor;
}


if(inverse){
return 1/(factor*otherFactor);
}
return factor*otherFactor;
};_proto2.
getMoveTypeText=function getMoveTypeText(move,value,forMaxMove){
var _this$getMoveType3=this.getMoveType(move,value,forMaxMove),moveType=_this$getMoveType3[0],category=_this$getMoveType3[1];
var pokemon=value.pokemon;
if(!pokemon)return[moveType,''];

var foeActive=[].concat(pokemon.side.foe.active).reverse();
if(this.battle.gameType==='freeforall'){
foeActive=[].concat(foeActive,pokemon.side.active).filter(function(active){return active!==pokemon;});
}

if(this.battle.hardcoreMode){
var _tags='';for(var _i50=0,_foeActive6=
foeActive;_i50<_foeActive6.length;_i50++){var possibleTarget=_foeActive6[_i50];
if(!possibleTarget)continue;
var effectiveness=this.getMoveEffectiveness(pokemon,move,moveType,category,possibleTarget);

if(effectiveness===null){
break;
}if(effectiveness===0){
_tags+="\xD7";
}else if(effectiveness<0.5){
_tags+="\u25BC";
}else if(effectiveness<1){
_tags+="\u25B3";
}else if(effectiveness>2){
_tags+="\u2605";
}else if(effectiveness>1){
_tags+="\u29BF";
}else{
_tags+="\u25CB";
}
}

return[moveType,_tags];
}

var tags="\xD7";for(var _i52=0,_foeActive8=
foeActive;_i52<_foeActive8.length;_i52++){var _possibleTarget=_foeActive8[_i52];
if(!_possibleTarget)continue;
var _effectiveness=this.getMoveEffectiveness(pokemon,move,moveType,category,_possibleTarget);
if(_effectiveness!==0){
tags='';
break;
}
}

return[moveType,tags];
};_proto2.

getMoveAccuracy=function getMoveAccuracy(move,value,target){
value.reset(move.accuracy===true?0:move.accuracy,true);

var pokemon=value.pokemon;

if(move.id==='toxic'&&this.battle.gen>=6&&this.pokemonHasType(pokemon,'Poison')){
value.set(0,"Poison type");
return value;
}
if(move.id==='blizzard'&&this.battle.gen>=4){
value.weatherModify(0,'Hail');
value.weatherModify(0,'Snowscape');
}
if(['hurricane','thunder','bleakwindstorm','wildboltstorm','sandsearstorm'].includes(move.id)){
value.weatherModify(0,'Rain Dance');
value.weatherModify(0,'Primordial Sea');
}
value.abilityModify(0,'No Guard');
if(!value.value)return value;


if(move.ohko){
if(this.battle.gen===1){
value.set(value.value,"fails if target's Speed is higher");
return value;
}
if(move.id==='sheercold'&&this.battle.gen>=7&&!this.pokemonHasType(pokemon,'Ice')){
value.set(20,'not Ice-type');
}
if(target){
if(pokemon.level<target.level){
value.reset(0);
value.set(0,"FAILS: target's level is higher");
}else if(pokemon.level>target.level){
value.set(value.value+pokemon.level-target.level,"+1% per level above target");
}
}else{
if(pokemon.level<100)value.set(value.value,"fails if target's level is higher");
if(pokemon.level>1)value.set(value.value,"+1% per level above target");
}
return value;
}



var accuracyModifiers=[];
if(this.battle.hasPseudoWeather('Gravity')){
accuracyModifiers.push(6840);
value.modify(5/3,"Gravity");
}for(var _i54=0,_pokemon$side$active2=

pokemon.side.active;_i54<_pokemon$side$active2.length;_i54++){var active=_pokemon$side$active2[_i54];
if(!active||active.fainted)continue;
var ability=this.getAllyAbility(active);
if(ability==='Victory Star'){
accuracyModifiers.push(4506);
value.modify(1.1,"Victory Star");
}
}

if(value.tryAbility('Hustle')&&move.category==='Physical'){
accuracyModifiers.push(3277);
value.abilityModify(0.8,"Hustle");
}else if(value.tryAbility('Compound Eyes')){
accuracyModifiers.push(5325);
value.abilityModify(1.3,"Compound Eyes");
}else if(value.tryAbility('Precision')){
accuracyModifiers.push(5325);
value.abilityModify(1.3,"Precision");
}else if(value.tryAbility('Tormented')&&move.category==='Special'){
accuracyModifiers.push(3277);
value.abilityModify(0.8,"Tormented");
}

if(value.tryItem('Wide Lens')){
accuracyModifiers.push(4505);
value.itemModify(1.1,"Wide Lens");
}


if(this.battle.tier.includes('Super Staff Bros')){
if(move.id==='alting'&&pokemon.shiny){
value.set(100);
}
if(move.flags['wind']&&this.battle.weather==='stormsurge'){
value.weatherModify(0,'Storm Surge');
}
if(value.tryAbility('Misspelled')&&move.category==='Special'){
accuracyModifiers.push(3277);
value.abilityModify(0.8,"Misspelled");
}
if(value.tryAbility('Hydrostatic Positivity')&&['Electric','Water'].includes(move.type)){
accuracyModifiers.push(5325);
value.abilityModify(1.3,"Hydrostatic Positivity");
}
if(value.tryAbility('Hardcore Hustle')){
for(var i=1;i<=5&&i<=pokemon.side.faintCounter;i++){
if(pokemon.volatiles["fallen"+i]){
value.abilityModify([1,0.95,0.90,0.85,0.80,0.75][i],"Hardcore Hustle");
}
}
}
if(value.tryAbility('See No Evil, Hear No Evil, Speak No Evil')&&
pokemon.getSpeciesForme().includes('Wellspring')){
value.abilityModify(0,'See No Evil, Hear No Evil, Speak No Evil');
}
value.abilityModify(0,'Sure Hit Sorcery');
value.abilityModify(0,'Eyes of Eternity');
if(!value.value)return value;
}


if(value.tryItem('Hypno Crest')&&pokemon.name==='Hypno'){
accuracyModifiers.push(6144);
value.itemModify(1.5,"Hypno Crest");
}
if(value.tryItem('Stantler Crest')&&['Stantler','Wyrdeer'].includes(pokemon.name)){
value.itemModify(1.5,"Stantler Crest");
}

if(this.battle.dex.modid==='gen9rejuvenation'){
if(move.id==='grasswhistle'&&this.battle.hasPseudoWeather('Grassy Terrain'))value.set(80,'Terrain Modifier');
if(move.id==='sweetkiss'&&this.battle.hasPseudoWeather('Misty Terrain'))value.set(100,'Terrain Modifier');
if(move.id==='toxic'&&this.battle.hasPseudoWeather('Corrosive Mist Field'))value.set(100,'Terrain Modifier');
if(move.type==='Electric'&&this.battle.hasPseudoWeather('Underwater Field'))value.set(0,'Terrain Modifier');
if(move.id==='dragonrush'&&this.battle.hasPseudoWeather('Dragons Den Field'))value.set(100,'Terrain Modifier');
if(move.id==='darkvoid'&&this.battle.hasPseudoWeather('Frozen Dimensional Field'))value.set(100,'Terrain Modifier');
if(['hurricane','thunder'].includes(move.id)&&this.battle.hasPseudoWeather('Sky Field'))value.set(0,'Terrain Modifier');
if(['willowisp','inferno','darkvoid'].includes(move.id)&&this.battle.hasPseudoWeather('Infernal Field'))value.set(0,'Terrain Modifier');
}


var chain=4096;for(var _i56=0;_i56<
accuracyModifiers.length;_i56++){var mod=accuracyModifiers[_i56];
if(mod!==4096){
chain=chain*mod+2048>>12;
}
}

value.set(move.accuracy);

if(move.id==='hurricane'||move.id==='thunder'){
if(value.tryAbility('Mega Sol'))value.set(50,'Mega Sol');
if(value.tryWeather('Sunny Day'))value.set(50,'Sunny Day');
if(value.tryWeather('Desolate Land'))value.set(50,'Desolate Land');
}


var accuracyAfterChain=value.value*chain/4096;
accuracyAfterChain=accuracyAfterChain%1>0.5?Math.ceil(accuracyAfterChain):Math.floor(accuracyAfterChain);
value.set(accuracyAfterChain);


if(pokemon!=null&&pokemon.boosts.accuracy){
if(pokemon.boosts.accuracy>0){
value.set(Math.floor(value.value*(pokemon.boosts.accuracy+3)/3));
}else{
value.set(Math.floor(value.value*3/(3-pokemon.boosts.accuracy)));
}
}


if(this.battle.gen===1&&!toID(this.battle.tier).includes('stadium')){
value.set(Math.floor(value.value*255/100)/256*100);
}
return value;
};_proto2.




getMoveBasePower=function getMoveBasePower(move,moveType,value){var _this4=this;var target=arguments.length>3&&arguments[3]!==undefined?arguments[3]:null;
var pokemon=value.pokemon;
var serverPokemon=value.serverPokemon;
var rejuv=this.battle.dex.modid==='gen9rejuvenation';
var field=rejuv?this.battle.getBattlefield():'';
var terrain=rejuv?this.battle.getTerrain():'';
if(move.id==='terrainpulse'&&moveType==='???'&&field==='New World Field'){
var min=Infinity;
var max=0;for(var _i58=0,_Dex$types$all2=
Dex.types.all();_i58<_Dex$types$all2.length;_i58++){var type=_Dex$types$all2[_i58];
if(type.name==='???'||!this.battle.dex.types.get(type.name).exists)continue;
var power=this.getMoveBasePower(move,type.name,value,target);
min=Math.min(min,power.value);
max=Math.max(max,power.maxValue||power.value);
}
if(max){
value.reset();
value.setRange(min,max>min?max:0,'Random Terrain Pulse type');
return value;
}
}
var poisonField=[
'Corrosive Mist Field','Murkwater Surface Field','Corrosive Field','Wasteland Field'].
includes(field);
var heldItem=this.battle.dex.items.get(serverPokemon.item);


var modifiedStats=this.calculateModifiedStats(pokemon,serverPokemon);

value.reset(move.basePower);

if(move.id==='acrobatics'){
if(!serverPokemon.item||field==='Big Top Arena Field'){
value.modify(2,move.name);
}
}
var variableBPCap=['crushgrip','wringout'].includes(move.id)?120:move.id==='hardpress'?100:undefined;
if(variableBPCap&&target){
value.set(
Math.floor(
Math.floor((variableBPCap*(100*Math.floor(target.hp*4096/target.maxhp))+2048-1)/4096)/100
)||1,
'approximate'
);
}
if(move.id==='terablast'&&pokemon.terastallized==='Stellar'){
value.set(100,'Tera Stellar boost');
}
if(move.id==='brine'&&target&&target.hp*2<=target.maxhp){
value.modify(2,'Brine + target below half HP');
}
if(move.id==='eruption'||move.id==='waterspout'||move.id==='dragonenergy'||move.id==='bloomsday'){
value.set(Math.floor(150*pokemon.hp/pokemon.maxhp)||1);
}
if(move.id==='facade'&&!['','slp','frz'].includes(pokemon.status)){
value.modify(2,'Facade + status');
}
if(move.id==='flail'||move.id==='reversal'){
var multiplier;
var ratios;
if(this.battle.gen>4){
multiplier=48;
ratios=[2,5,10,17,33];
}else{
multiplier=64;
ratios=[2,6,13,22,43];
}
var ratio=pokemon.hp*multiplier/pokemon.maxhp;
var basePower;
if(ratio<ratios[0])basePower=200;else
if(ratio<ratios[1])basePower=150;else
if(ratio<ratios[2])basePower=100;else
if(ratio<ratios[3])basePower=80;else
if(ratio<ratios[4])basePower=40;else
basePower=20;
value.set(basePower);
}
if(['hex','infernalparade'].includes(move.id)&&(
target!=null&&target.status||(target==null?void 0:target.effectiveAbility())==='Comatose'||(
move.id==='hex'?field==='Infernal Field':field==='Haunted Field')))
{
value.modify(2,move.name+' + status');
}
if(move.id==='vengefulpulse'&&!['','slp'].includes(pokemon.status)){
value.modify(1.5,move.name+' + status');
}
if(move.id==='lastrespects'){
value.set(Math.min(50+50*pokemon.side.faintCounter));
}
if(move.id==='punishment'&&target){
var boostCount=0;for(var _i60=0,_Object$values2=
Object.values(target.boosts);_i60<_Object$values2.length;_i60++){var boost=_Object$values2[_i60];
if(boost>0)boostCount+=boost;
}
value.set(Math.min(60+20*boostCount,200));
}
if(move.id==='smellingsalts'&&target){
if(target.status==='par'){
value.modify(2,'Smelling Salts + Paralysis');
}
}
if(['storedpower','powertrip'].includes(move.id)&&target){
var _boostCount=0;for(var _i62=0,_Object$values4=
Object.values(pokemon.boosts);_i62<_Object$values4.length;_i62++){var _boost=_Object$values4[_i62];
if(_boost>0)_boostCount+=_boost;
}
var perBoost=move.id==='powertrip'&&field==='Frozen Dimensional Field'?40:20;
value.set(20+perBoost*_boostCount);
}
if(move.id==='trumpcard'){
var pp=this.ppUsed(move,pokemon);
var ppLeft=5-(typeof pp==='number'?pp:pp[1]);
var _basePower2=40;
if(ppLeft===1)_basePower2=200;else
if(ppLeft===2)_basePower2=80;else
if(ppLeft===3)_basePower2=60;else
if(ppLeft===4)_basePower2=50;
value.set(_basePower2);
}
if(move.id==='magnitude'){
value.setRange(10,150);
}
if(['venoshock','barbbarrage'].includes(move.id)&&target){
if(['psn','tox'].includes(target.status)||poisonField){
value.modify(2,move.name+' + Poison');
}
}
if(move.id==='wakeupslap'&&target){
if(target.status==='slp'){
value.modify(2,'Wake-Up Slap + Sleep');
}
}
if(move.id==='weatherball'){
if(rejuv){
var wetOrSunny=['sunnyday','desolateland','raindance','primordialsea'].includes(this.battle.weather);
var weather=value.tryWeather()&&!(wetOrSunny&&value.tryItem('Utility Umbrella'))?this.battle.weather:'';
if(weather&&(wetOrSunny||['sandstorm','hail','snow','deltastream','shadowsky'].includes(weather))){
value.modify(2,value.weatherName);
}else if(!weather&&this.battle.hasPseudoWeather('Rainbow Field')){
value.modify(2,'Rainbow Field');
}
}else if(!value.abilityModify(2,"Mega Sol")&&this.battle.weather!=='deltastream'){
switch(this.battle.weather){
case'sunnyday':
case'desolateland':
case'raindance':
case'primordialsea':
case'stormsurge':
if(value.tryItem('Utility Umbrella'))break;
value.weatherModify(2);
break;
default:
value.weatherModify(2);
break;
}
}
}
if(move.id==='hydrosteam'){
value.weatherModify(1.5,'Sunny Day');
}
if(move.id==='psyblade'&&this.battle.hasPseudoWeather('Electric Terrain')&&heldItem.id!=='fieldcleats'){
value.modify(1.5,'Electric Terrain');
}
if(move.id==='mistbarrage'&&this.battle.hasPseudoWeather('Misty Terrain')&&heldItem.id!=='fieldcleats'){
value.modify(1.5,'Misty Terrain');
}
if(move.id==='terrainpulse'&&pokemon.isGrounded(serverPokemon)&&(
rejuv||heldItem.id!=='fieldcleats')&&this.battle.getTerrain()){
value.modify(2,'Terrain Pulse boost');
}
if(
move.id==='watershuriken'&&[pokemon.getSpeciesForme(),pokemon.fusion].includes('Greninja-Ash')&&pokemon.ability==='Battle Bond')
{
value.set(20,'Battle Bond');
}

if(move.id==='electroball'&&target){
var _this$getSpeedRange2=this.getSpeedRange(target),minSpe=_this$getSpeedRange2.min,maxSpe=_this$getSpeedRange2.max;
var minRatio=modifiedStats.spe/maxSpe;
var maxRatio=modifiedStats.spe/minSpe;
var _min;
var _max;

if(minRatio>=4)_min=150;else
if(minRatio>=3)_min=120;else
if(minRatio>=2)_min=80;else
if(minRatio>=1)_min=60;else
_min=40;

if(maxRatio>=4)_max=150;else
if(maxRatio>=3)_max=120;else
if(maxRatio>=2)_max=80;else
if(maxRatio>=1)_max=60;else
_max=40;

value.setRange(_min,_max);
}
if(move.id==='gyroball'&&target){
var _this$getSpeedRange3=this.getSpeedRange(target),_minSpe=_this$getSpeedRange3.min,_maxSpe=_this$getSpeedRange3.max;
var _min2=Math.floor(25*_minSpe/modifiedStats.spe)||1;
if(_min2>150)_min2=150;
var _max2=Math.floor(25*_maxSpe/modifiedStats.spe)||1;
if(_max2>150)_max2=150;
value.setRange(_min2,_max2);
}

if(serverPokemon.item){
if(move.id==='fling'&&heldItem.fling){
value.itemModify(heldItem.fling.basePower);
}
if(move.id==='naturalgift'&&heldItem.naturalGift){
value.itemModify(heldItem.naturalGift.basePower);
}
if(move.id==='deserttempest'&&heldItem.id==='smoothrock'){
value.itemModify(1.2,'Smooth Rock');
}
}

if(['lowkick','grassknot','heavyslam','heatcrash'].includes(move.id)&&this.battle.gen>2){
var isGKLK=['lowkick','grassknot'].includes(move.id);
if(target){
var targetWeight=target.getWeightKg();
var pokemonWeight=pokemon.getWeightKg(serverPokemon);
var _basePower3;
if(isGKLK){
_basePower3=20;
if(targetWeight>=200)_basePower3=120;else
if(targetWeight>=100)_basePower3=100;else
if(targetWeight>=50)_basePower3=80;else
if(targetWeight>=25)_basePower3=60;else
if(targetWeight>=10)_basePower3=40;
}else{
_basePower3=40;
if(pokemonWeight>=targetWeight*5)_basePower3=120;else
if(pokemonWeight>=targetWeight*4)_basePower3=100;else
if(pokemonWeight>=targetWeight*3)_basePower3=80;else
if(pokemonWeight>=targetWeight*2)_basePower3=60;
}
if(target.volatiles['dynamax']){
value.set(0,'blocked by target\'s Dynamax');
}else{
value.set(_basePower3);
}
}else{
value.setRange(isGKLK?20:40,120);
}
}
if(rejuv){
if(move.id==='feverpitch')value.setRange(40,150);
if(move.id==='doomdesire'&&this.battle.hasPseudoWeather('New World Field')){
value.set(560,'New World Field when used');
}
if(move.id==='rage'&&['Frozen Dimensional Field','Dimensional Field'].includes(field))value.set(60);
if(this.battle.hasPseudoWeather('Deep Earth Field')){
if(move.id==='crushgrip')value.set(120,'Deep Earth Field');
if(move.id==='gyroball')value.set(150,'Deep Earth Field');
}
if(this.battle.hasPseudoWeather('Concert Venue Field')){
var hype=this.battle.fieldCounter('hype');
if(hype===0||hype===3){
var maxHype=hype===3;
var bp=0;
if(['magnitude','feverpitch'].includes(move.id))bp=maxHype?150:60;
if(move.id==='spitup')bp=maxHype?300:100;
if(['heatcrash','heavyslam'].includes(move.id))bp=maxHype?120:40;
if(move.id==='electroball')bp=maxHype?150:40;
if(move.id==='furycutter')bp=maxHype?160:40;
if(move.id==='trumpcard')bp=maxHype?200:40;
if(['grassknot','lowkick'].includes(move.id))bp=maxHype?120:20;
if(['flail','reversal'].includes(move.id))bp=maxHype?200:20;
if(['crushgrip','dragonenergy','hardpress','wringout'].includes(move.id))bp=maxHype?120:1;
if(['eruption','waterspout','bloomdoom'].includes(move.id))bp=maxHype?150:1;
if(['pikapapow','veeveevolley','return','frustration'].includes(move.id))bp=maxHype?102:1;
if(move.id==='gyroball'&&!maxHype)bp=1;
if(move.id==='fling'&&value.value&&heldItem.fling)bp=maxHype?130:10;
if(move.id==='naturalgift'&&value.value&&heldItem.naturalGift)bp=maxHype?100:80;
if(bp)value.set(bp,'Concert Venue Field');
}
}
}

if(move.id==='ragefist'){
value.set(Math.min(350,50+50*pokemon.timesAttacked),
pokemon.timesAttacked>0?"Hit "+
pokemon.timesAttacked+" time"+(pokemon.timesAttacked>1?'s':''):
undefined);
}
if(!value.value)return value;


if(field!=='Frozen Dimensional Field'&&(
pokemon.status==='brn'&&move.category==='Special'||field==='Infernal Field'))
{
value.abilityModify(1.5,"Flare Boost");
}
if(move.flags['punch']){
value.abilityModify(1.2,'Iron Fist');
}
if(move.flags['pulse']){
value.abilityModify(1.5,"Mega Launcher");
}
if(move.flags['bite']){
value.abilityModify(1.5,"Strong Jaw");
}
if(move.flags['bullet']){
value.abilityModify(1.5,"Cannon Fire");
}
if(move.flags['wind']){
value.abilityModify(1.3,"Wind Fury");
}
var technicianLimit=['Factory Field','Concert Venue Field'].includes(field)?80:60;
if(value.value<=technicianLimit){
value.abilityModify(1.5,"Technician");
}
if(move.category==='Physical'&&(['psn','tox'].includes(pokemon.status)||poisonField)){
value.abilityModify(field==='Corrupted Cave Field'?2:1.5,'Toxic Boost');
}
if(['Rock','Ground','Steel'].includes(moveType)&&this.battle.weather==='sandstorm'){
if(value.tryAbility("Sand Force"))value.weatherModify(1.3,"Sandstorm","Sand Force");
}else if(['Rock','Ground','Steel'].includes(moveType)&&['Desert Field','Beach Field'].includes(field)){
value.abilityModify(1.3,'Sand Force');
}
if(move.secondaries){
value.abilityModify(1.3,"Sheer Force");
}
if(move.flags['contact']){
value.abilityModify(1.3,"Tough Claws");
}
if(move.flags['sound']){
value.abilityModify(['Big Top Arena Field','Cave Field'].includes(field)?1.5:1.3,'Punk Rock');
}
if(move.flags['slicing']){
value.abilityModify(1.5,"Sharpness");
}
for(var i=1;i<=5&&i<=pokemon.side.faintCounter;i++){
if(pokemon.volatiles["fallen"+i]){
value.abilityModify(1+0.1*i,"Supreme Overlord");
}
}
if(target){
if(["MF","FM"].includes(pokemon.gender+target.gender)){
value.abilityModify(0.75,"Rivalry");
}else if(["MM","FF"].includes(pokemon.gender+target.gender)){
value.abilityModify(1.25,"Rivalry");
}
}
var noTypeOverride=[
'judgment','multiattack','naturalgift','revelationdance','struggle','technoblast','terrainpulse','weatherball'];

var fieldGalvanize=terrain==='Electric Terrain'||['Factory Field','Short-Circuit Field'].includes(field);
if(fieldGalvanize)value.abilityModify(1.5,'Galvanize');
var allowTypeOverride=!noTypeOverride.includes(move.id)&&(move.id!=='terablast'||!pokemon.terastallized);
if(
move.category!=='Status'&&allowTypeOverride&&!move.isZ&&!move.isMax&&
!move.id.startsWith('hiddenpower'))
{
if(move.type==='Normal'){
var _boost2=this.battle.gen>6?1.2:1.3;
value.abilityModify(['Sky Field','Mountain Field','Snowy Mountain Field'].includes(field)?1.5:_boost2,'Aerilate');
value.abilityModify(1.2,"Dragonize");
if(!fieldGalvanize)value.abilityModify(1.2,'Galvanize');
value.abilityModify(terrain==='Misty Terrain'?1.5:_boost2,'Pixilate');
var iceField=['Icy Field','Frozen Dimensional Field','Snowy Mountain Field'].includes(field);
value.abilityModify(iceField?1.5:_boost2,'Refrigerate');
value.abilityModify(this.battle.gen>6?1.2:1.3,"Intoxicate");
value.abilityModify(this.battle.gen>6?1.2:1.3,"Atomizate");
value.abilityModify(this.battle.gen>6?1.2:1.3,"Energizate");
value.abilityModify(this.battle.gen>6?1.2:1.3,"Transmutate");
value.abilityModify(this.battle.gen>6?1.2:1.3,"Dark Matter");
if(this.battle.dex.modid==='gen9soulstones')value.abilityModify(1.2,"Illuminate");
}
if(move.type==='Rock'){
value.abilityModify(this.battle.gen>6?1.2:1.3,"Foundry");
}
if(move.type==='Light'){
value.abilityModify(this.battle.gen>6?1.2:1.3,"Black Light");
}
if(move.type==='Dark'){
value.abilityModify(this.battle.gen>6?1.2:1.3,"Whiteout");
}
if(this.battle.gen>6){
value.abilityModify(1.2,"Normalize");
}
}
if(move.flags['sound']){
value.abilityModify(1.25,"Amplifier");
value.abilityModify(1.3,"Sound Boost");
}
if(move.recoil||move.hasCrashDamage){
value.abilityModify(1.2,'Reckless');
}
if(move.flags.bite){
value.abilityModify(1.3,"Spectral Jaws");
}
var curMonth=new Date().getMonth();
if([10,11,0,1].includes(curMonth)){
value.abilityModify(1.4,"Winter Joy");
}else if([4,5,6,7].includes(curMonth)){
value.abilityModify(0.7,"Winter Joy");
}
if(move.priority>0||move.id==='grassyglide'&&this.battle.hasPseudoWeather('Grassy Terrain')){
value.abilityModify(1.5,'Acceleration');
}
if(move.flags['wind']){
value.abilityModify(1.2,"Windy Spirit");
}
if(move.flags['charge']){
value.abilityModify(1.5,"Hidden Ambush");
}
if(move.flags['bullet']){
value.abilityModify(1.5,"Cannoneer");
}
if(move.category==='Physical'&&move.basePower&&pokemon.strangeAnatomyTurns){
if(value.tryAbility("Strange Anatomy"))value.set(Math.max(move.basePower-5*pokemon.strangeAnatomyTurns,1),5*pokemon.strangeAnatomyTurns+" BP lost from Strange Anatomy");
}
if(pokemon.side.sideConditions['scatteredcoins']){
value.abilityModify(1.3,'Money Equals Power');
}
if(pokemon.volatiles[move.category.toLowerCase()]){
value.abilityModify(1.3,"Dual Mastery");
}

if(this.battle.dex.modid==='gen9soulstones'){
if(move.id==='magnitude')value.set(pokemon.level,'BP equal to level');
if(move.secondaries){for(var _i64=0,_move$secondaries2=
move.secondaries;_i64<_move$secondaries2.length;_i64++){var secondary=_move$secondaries2[_i64];
if(secondary.chance)value.abilityModify(1-secondary.chance/100,"Serene Grace");
}
}
}

if(move.category!=='Status'){
var auraBoosted='';
var auraBroken=false;for(var _i66=0,_pokemon$side$active4=
pokemon.side.active;_i66<_pokemon$side$active4.length;_i66++){var ally=_pokemon$side$active4[_i66];
if(!ally||ally.fainted)continue;
var allyAbility=this.getAllyAbility(ally);
if(moveType==='Fairy'&&allyAbility==='Fairy Aura'){
auraBoosted='Fairy Aura';
}else if(moveType==='Dark'&&allyAbility==='Dark Aura'){
auraBoosted='Dark Aura';
}else if(moveType==='Light'&&allyAbility==='Light Aura'){
auraBoosted='Light Aura';
}else if(allyAbility==='Aura Break'){
auraBroken=true;
}else if(allyAbility==='Battery'&&ally!==pokemon&&move.category==='Special'){
value.modify(1.3,'Battery');
}else if(allyAbility==='Power Spot'&&ally!==pokemon){
value.modify(1.3,'Power Spot');
}else if(allyAbility==='Steely Spirit'&&moveType==='Steel'){
value.modify(1.5,'Steely Spirit');
}
}for(var _i68=0,_pokemon$side$foe$act2=
pokemon.side.foe.active;_i68<_pokemon$side$foe$act2.length;_i68++){var foe=_pokemon$side$foe$act2[_i68];
if(!foe||foe.fainted)continue;
if(foe.ability==='Fairy Aura'&&moveType==='Fairy'){
auraBoosted='Fairy Aura';
}else if(foe.ability==='Dark Aura'&&moveType==='Dark'){
auraBoosted='Dark Aura';
}else if(foe.ability==='Light Aura'&&moveType==='Light'){
auraBoosted='Light Aura';
}else if(foe.ability==='Aura Break'){
auraBroken=true;
}
}
if(auraBoosted){
if(auraBroken){
value.modify(0.75,auraBoosted+' + Aura Break');
}else{
value.modify(1.33,auraBoosted);
}
}
}


if(rejuv){var _target$isGrounded;
var grounded=pokemon.isGrounded(serverPokemon);
var targetGrounded=(_target$isGrounded=target==null?void 0:target.isGrounded())!=null?_target$isGrounded:true;
if(this.battle.hasPseudoWeather('Electric Terrain')){
if(moveType==='Electric'&&grounded&&!pokemon.isSemiInvulnerable()||[
'explosion','hurricane','muddywater','selfdestruct','smackdown','surf','thousandarrows','wildboltstorm'].
includes(move.id)){
value.modify(1.5,'Electric Terrain');
}else if(move.id==='magnetbomb'){
value.modify(2,'Electric Terrain');
}
}else if(this.battle.hasPseudoWeather('Grassy Terrain')){
if(moveType==='Grass'&&grounded||moveType==='Fire'&&targetGrounded||[
'fairywind','grassknot','gust','icywind','ominouswind','razorwind','silverwind','twister'].
includes(move.id)){
value.modify(1.5,'Grassy Terrain');
}else if(['earthquake','bulldoze','magnitude'].includes(move.id)&&
targetGrounded&&!(target!=null&&target.isSemiInvulnerable())){
value.modify(0.5,'Grassy Terrain');
}else if(['aciddownpour','sludgewave'].includes(move.id)||
move.id==='surf'&&this.battle.fieldCounter('terrainFlooding')>=2||
move.id==='muddywater'&&this.battle.fieldCounter('terrainFlooding')>=1){
value.modify(1.3,'Grassy Terrain');
}
}else if(this.battle.hasPseudoWeather('Misty Terrain')){
if(moveType==='Dragon'&&targetGrounded&&!(target!=null&&target.isSemiInvulnerable())){
value.modify(0.5,'Misty Terrain');
}else if(moveType==='Fairy'&&grounded&&!(target!=null&&target.isSemiInvulnerable())||[
'aurasphere','clearsmog','doomdesire','icywind','magicalleaf','mistball','moongeistbeam',
'mysticalfire','silverwind','smog','springtidestorm','steameruption','strangestream'].
includes(move.id)){
value.modify(1.5,'Misty Terrain');
}else if(['darkpulse','nightdaze','shadowball'].includes(move.id)){
value.modify(0.5,'Misty Terrain');
}else if(['gust','hurricane','razorwind','supersonicskystrike','twister','aciddownpour'].includes(move.id)){
value.modify(1.3,'Misty Terrain');
}
}else if(this.battle.hasPseudoWeather('Psychic Terrain')){
if(moveType==='Psychic'&&grounded&&!pokemon.isSemiInvulnerable())value.modify(1.5,'Psychic Terrain');
if([
'aurasphere','focusblast','hex','hiddenpower','magicalleaf','mindblown','moonblast','mysticalfire','secretpower'].
includes(move.id))value.modify(1.5,'Psychic Terrain');
}
}else if(this.battle.hasPseudoWeather('Electric Terrain')&&moveType==='Electric'||
this.battle.hasPseudoWeather('Grassy Terrain')&&moveType==='Grass'||
this.battle.hasPseudoWeather('Psychic Terrain')&&moveType==='Psychic'){
if(pokemon.isGrounded(serverPokemon)&&heldItem.id!='fieldcleats'){
value.modify(this.battle.gen>7||this.battle.dex.modid==='gen9soulstones'?1.3:1.5,'Terrain boost');
}
}else if(this.battle.hasPseudoWeather('Misty Terrain')&&moveType==='Dragon'&&move.id!=='mistbarrage'&&heldItem.id!=='fieldcleats'){
if(target?target.isGrounded():true){
value.modify(0.5,'Misty Terrain + grounded target');
}
}else if(
this.battle.hasPseudoWeather('Grassy Terrain')&&['earthquake','bulldoze','magnitude','terraforce','anvilsmash','webwrecker'].includes(move.id)&&heldItem.id!=='fieldcleats')
{
if(target?target.isGrounded():true){
value.modify(0.5,'Grassy Terrain + grounded target');
}
}
if(
move.id==='expandingforce'&&
this.battle.hasPseudoWeather('Psychic Terrain')&&
pokemon.isGrounded(serverPokemon)&&heldItem.id!=='fieldcleats')
{
value.modify(this.battle.dex.modid==='gen9soulstones'?1.3:1.5,'Expanding Force + Psychic Terrain boost');
}
if(move.id==='mistyexplosion'&&this.battle.hasPseudoWeather('Misty Terrain')&&heldItem.id!=='fieldcleats'){
value.modify(1.5,'Misty Explosion + Misty Terrain boost');
}
if(move.id==='risingvoltage'&&this.battle.hasPseudoWeather('Electric Terrain')&&target!=null&&target.isGrounded()){
value.modify(this.battle.dex.modid==='gen9soulstones'?1.6:2,'Rising Voltage + Electric Terrain boost');
}


value=this.getItemBoost(move,value,moveType);

var applyTeraAndStatus=function(){
if(
pokemon.terastallized&&(pokemon.terastallized===move.type||pokemon.terastallized==='Stellar')&&
value.value>0&&value.value<60&&move.priority<=0&&!move.multihit&&!(
(move.basePower===0||move.basePower===150)&&move.basePowerCallback))

{
if(rejuv&&value.maxValue>60)value.setRange(60,value.maxValue,'Tera type BP minimum');else
value.set(60,'Tera type BP minimum');
}

if(_this4.battle.gen>2&&serverPokemon.status==='brn'&&move.id!=='facade'&&move.category==='Physical'){
if(!value.tryAbility("Guts"))value.modify(0.5,'Burn');
}
if(_this4.battle.gen>2&&serverPokemon.status==='frb'&&move.id!=='facade'&&move.category==='Special'){
if(!value.tryAbility("Attunement"))value.modify(0.5,'Frostbite');
}
};
if(!rejuv)applyTeraAndStatus();

if(
move.id==='steelroller'&&
!this.battle.hasPseudoWeather('Electric Terrain')&&
!this.battle.hasPseudoWeather('Grassy Terrain')&&
!this.battle.hasPseudoWeather('Misty Terrain')&&
!this.battle.hasPseudoWeather('Psychic Terrain'))
{
value.set(0,'no Terrain');
}


if(this.battle.tier.includes('Super Staff Bros')){
if(move.id==='bodycount'){
value.set(50+50*pokemon.side.faintCounter,
pokemon.side.faintCounter>0?
pokemon.side.faintCounter+" teammate"+(pokemon.side.faintCounter>1?'s':'')+" KOed":
undefined);
}

if(move.id==='vengefulmood'){
value.set(Math.min(140,60+20*pokemon.timesAttacked),
pokemon.timesAttacked>0?"Hit "+
pokemon.timesAttacked+" time"+(pokemon.timesAttacked>1?'s':''):
undefined);
}
if(move.id==='alting'&&pokemon.shiny){
value.set(69,'Shiny');
}
if(move.id==='darkmooncackle'){
var _boostCount2=0;for(var _i70=0,_Object$values6=
Object.values(pokemon.boosts);_i70<_Object$values6.length;_i70++){var _boost3=_Object$values6[_i70];
if(_boost3>0)_boostCount2+=_boost3;
}
value.set(30+20*_boostCount2);
}
if(move.id==='buildingcharacter'&&target!=null&&target.terastallized){
value.modify(2,'Terastallized target');
}
if(move.id==='mysticalbonfire'&&target!=null&&target.status){
value.modify(1.5,'Mystical Bonfire + status');
}
if(move.id==='adaptivebeam'&&target&&Object.values(target.boosts).some(function(x){return x>0;})){
value.set(0,"Target has more boosts");
}
if(value.value<=60){
value.abilityModify(1.5,"Confirmed Town");
}
if(move.category!=='Status'&&allowTypeOverride&&!move.isZ&&
!move.isMax&&!move.id.startsWith('hiddenpower')){
if(moveType==='Normal'){
value.abilityModify(this.battle.gen>6?1.2:1.3,"I Can Hear The Heart Beating As One");
}
value.abilityModify(this.battle.gen>6?1.2:1.3,"Acetosa");
}
if(move.flags['punch']){
value.abilityModify(1.5,"Harambe Hit");
}
if(move.flags['slicing']){
value.abilityModify(1.5,"I Can Hear The Heart Beating As One");
}
if(move.priority>0){
value.abilityModify(2,"Full Bloom");
}
if(move.recoil||move.hasCrashDamage){
value.abilityModify(1.2,'Hogwash');
if(pokemon.name==="Billo"){
value.modify(1.2);
}
}
if((target==null?void 0:target.gender)==="M"&&pokemon.getSpeciesForme().includes("Hearthflame")){
value.abilityModify(1.3,'See No Evil, Hear No Evil, Speak No Evil');
}
for(var _i71=1;_i71<=5&&_i71<=pokemon.side.faintCounter;_i71++){
if(pokemon.volatiles["fallen"+_i71]){
value.abilityModify([1,1.15,1.3,1.45,1.6,1.75][_i71],"Hardcore Hustle");
}
}
var timeDilationBPMod=1+0.1*Math.floor(this.battle.turn/10);
if(timeDilationBPMod>2)timeDilationBPMod=2;
value.abilityModify(timeDilationBPMod,"Time Dilation");

for(var _i72=1;_i72<=5&&_i72<=pokemon.side.faintCounter;_i72++){
if(pokemon.volatiles["fallen"+_i72]){
value.abilityModify(1+0.05*_i72,"The Eminence in the Shadow");
}
}
}



if(heldItem.id==='claydolcrest'&&pokemon.name==='Claydol'){
if(move.id.includes('beam')){
value.itemModify(1.5,'Claydol Crest');
}
}
if(heldItem.id==='druddigoncrest'&&pokemon.name==='Druddigon'){
if(['Dragon','Fire'].includes(move.type)){
value.itemModify(1.3,'Druddigon Crest');
}
}
if(heldItem.id==='dusknoircrest'&&pokemon.name==='Dusknoir'){
if(move.basePower<=60){
value.itemModify(1.5,'Dusknoir Crest');
}
}
if(heldItem.id==='fearowcrest'&&pokemon.name==='Fearow'){
var stabbing=['hornattack','furyattack','poisonsting','twineedle','pinmissile','peck','drillpeck','megahorn','poisonjab','needlearm','pluck','drillrun','hornleech','fellstinger','smartstrike','branchpoke','glaciallance','gildedarrow','gildedhelix','quicksilverspear'];
if(stabbing.includes(move.id)){
value.itemModify(1.5,'Fearow Crest');
}
}
if(heldItem.id==='feraligatrcrest'&&pokemon.name==='Feraligatr'){
if(move.flags.bite){
value.itemModify(1.5,'Feraligatr Crest');
}
}
if(heldItem.id==='spiritombcrest'&&pokemon.name==='Spiritomb'){
value.itemModify(1+0.2*pokemon.side.faintCounter,"Spiritomb Crest");
}

if(this.battle.dex.modid==='gen9rejuvenation'){


if(move.id==='bunrakubeatdown'&&target){
if(pokemon.ability==='worldofnightmares'){
for(var _i73=1;_i73<=6&&_i73<=target.side.faintCounter;_i73++){
if(pokemon.volatiles["slain"+_i73]){
value.modify(1+15*_i73,"Bunraku Beatdown");
}
}
}else{
for(var _i74=1;_i74<=6&&_i74<=pokemon.side.faintCounter;_i74++){
if(pokemon.volatiles["fallen"+_i74]){
value.modify(1+15*_i74,"Bunraku Beatdown");
}
}
}
}

if(move.id==='irritation'&&target!=null&&target.status){
value.modify(2,move.name+' + status');
}
if(move.id==='wakeupshock'&&target){
if(target.status==='slp'){
value.modify(2,'Wake-Up Shock + Sleep');
}
}
if(moveType==='Electric'&&this.battle.hasPseudoWeather('Electric Terrain')){
value.abilityModify(1.5,'Teravolt');
}
if(pokemon.ability==='execution'&&target&&target.hp<target.maxhp/2){
value.abilityModify(2,"Execution.");
}
if(pokemon.ability==='lunaridol'&&move.type==='Ice'){
value.abilityModify(2,"Lunar Idol Boost");
}
if(pokemon.ability==='solaridol'&&move.type==='Fire'){
value.abilityModify(2,"Solar Idol Boost");
}
if(pokemon.ability==='trueshot'&&move.flags.bullet){
value.abilityModify(1.3,"True Shot Boost");
}

if(move.id==='sludgewave'&&['Water Surface Field','Underwater Field'].includes(field)&&
this.battle.fieldCounter('pollution')>0){
value.modify(1.3,'Field pollution');
}
move=Object.assign({},move,{type:moveType});
if(this.battle.hasPseudoWeather('Volcanic Field')){var _target$isGrounded2;
if(move.type==='Fire'&&pokemon.isGrounded(serverPokemon)&&!pokemon.isSemiInvulnerable()){
value.modify(1.5,'Volcanic Field');
}else if(['Grass','Ice'].includes(move.type)&&((_target$isGrounded2=target==null?void 0:target.isGrounded())!=null?_target$isGrounded2:true)&&!(target!=null&&target.isSemiInvulnerable())){
value.modify(0.5,'Volcanic Field');
}else if(['clearsmog','smog'].includes(move.id)){
value.modify(2,'Terrain Boost');
}else if(['rockslide','smackdown','thousandarrows','infernalparade'].includes(move.id)){
value.modify(1.5,'Terrain Boost');
}else if(['continentalcrush','sandtomb','defog','gust','hurricane','razorwind','supersonicskystrike','tailwind','twister','whirlwind',
'hydrovortex','muddywater','oceanicoperetta','sparklingaria','surf','waterpledge','watersport','waterspout','sludgewave'].includes(move.id)){
value.modify(1.3,'Terminate Terrain Boost');
}

}
if(this.battle.hasPseudoWeather('Corrosive Mist Field')){
value.abilityModify(1.5,'Corrosion');
if(move.type==='Fire'){
value.modify(1.5,'Terrain Boost');
}
if(['acidspray','appleacid','bubble','bubblebeam','clearsmog','smog','sparklingaria'].includes(move.id)){
value.modify(1.5,'Terrain Boost');
}
if(['seedflare','gust','hurricane','razorwind','supersonicskystrike','twister'].includes(move.id)){
value.modify(1.3,'Terminate Terrain Boost');
}
}
if(this.battle.hasPseudoWeather('Icy Field')){
if(move.type==='Ice'||move.id==='bittermalice'){
value.modify(1.5,'Terrain Boost');
}
if(move.type==='Fire'||['scald','steameruption'].includes(move.id)){
value.modify(0.5,'Terrain Weaken');
}
if(move.id==='scald'&&this.battle.fieldCounter('melting')>=1){
value.modify(1.3,'Icy Field');
}
if(['eruption','firepledge','flameburst','heatwave','incinerate','infernooverdrive','lavaplume','magmadrift','mindblown','ragingfury','searingshot'].includes(move.id)){
value.modify(1.3,'Terminate Terrain Boost');
}
}
if(this.battle.hasPseudoWeather('Water Surface Field')){var _target$isGrounded3,_target$isGrounded4;
if(move.type==='Water'||move.type==='Electric'&&((_target$isGrounded3=target==null?void 0:target.isGrounded())!=null?_target$isGrounded3:true)){
value.modify(1.5,'Terrain Boost');
}
if(move.priority>0){
value.abilityModify(1.5,'Propeller Tail');
}
if(['dive','hydrovortex','muddywater','octazooka','originpulse','surf','whirlpool','sludgewave'].includes(move.id)){
value.modify(1.2,'Terrain Boost');
}
if(move.type==='Fire'&&((_target$isGrounded4=target==null?void 0:target.isGrounded())!=null?_target$isGrounded4:true)){
value.modify(0.5,'Terrain Weaken');
}
if(['anchorshot','dive','gravapple','gravity','aciddownpour','blizzard','glaciate','subzeroslammer'].includes(move.id)){
value.modify(1.3,'Terminate Terrain Boost');
}
}
if(this.battle.hasPseudoWeather('Underwater Field')){
if(move.type==='Electric'){
value.modify(2,'Terrain Boost');
}
if(['anchorshot','dragondarts'].includes(move.id)){
value.modify(2,'Terrain Boost');
}
if(move.type==='Water'){
value.modify(1.5,'Terrain Boost');
}
if(move.id==='waterpulse'){
value.modify(1.5,'Terrain Boost');
}
if(move.priority>0){
value.abilityModify(1.5,'Propeller Tail');
}
if(move.type!=='Water'&&!this.pokemonHasType(pokemon,'Water')&&move.category==='Physical'&&
!['Swift Swim','Steelworker'].includes(pokemon.effectiveAbility(serverPokemon))){
value.modify(0.5,'Terrain Weaken');
}
if(['bounce','fly','dive','skydrop','aciddownpour'].includes(move.id)){
value.modify(1.3,'Terminate Terrain Boost');
}
}
if(this.battle.hasPseudoWeather('Murkwater Surface Field')){
if(['Water','Poison'].includes(move.type)||['mudbarrage','mudbomb','mudshot','mudslap','thuosandwaves','appleacid','smackdown','acid','acidspray','brine'].includes(move.id)){
value.modify(1.5,'Terrain Boost');
}
if(move.type==='Electric'){
value.modify(1.3,'Terrain Boost');
}
if(['whirlpool','blizzard','glaciate','subzeroslammer'].includes(move.id)){
value.modify(1.3,'Terminate Terrain Boost');
}
}
if(this.battle.hasPseudoWeather('Dragons Den Field')){
if(['smackdown','thousandarrows','payday','dragonascent','lusterpurge','mistball'].includes(move.id)){
value.modify(2,'Terrain Boost');
}
if(['Fire','Dragon'].includes(move.type)){
value.modify(1.5,'Terrain Boost');
}
if(['rockclimb','strength','diamondstorm','matrixshot','powergem','earthpower','lavaplume','magmastorm','magmadrift','shelltrap','megakick','stompingtantrum'].includes(move.id)){
value.modify(1.5,'Terrain Boost');
}
if(move.type==='Rock'){
value.modify(1.3,'Terrain Boost');
}
if(move.type==='Water'){
value.modify(0.5,'Terrain Weaken');
}
if(move.id==='mistball'){
value.modify(1.3,'Terminate Terrain Boost');
}
}
if(this.battle.hasPseudoWeather('Frozen Dimensional Field')){
if(move.type==='Dark'){
value.modify(1.5,'Terrain Boost');
}
if(['fierywrath','freezingglare','lashout','outrage','ragingfury','rage','roaroftime','stompingtantrum','thrash'].includes(move.id)){
value.modify(1.5,'Terrain Boost');
}
if(move.type==='Ice'){
value.modify(1.2,'Terrain Boost');
}
if(['darkpulse','hydropump','muddywater','nightslash','surf','waterpulse','hyperspacehole','hyperspacefury'].includes(move.id)){
value.modify(1.2,'Terrain Boost');
}
if(['eruption','firepledge','flameburst','heatwave','incinerate','infernooverdrive','lavaplume','mindblown','ragingfury','searingshot'].includes(move.id)){
value.modify(1.3,'Terminate Terrain Boost');
}
}
if(this.battle.hasPseudoWeather('Sky Field')){
if(move.type==='Flying'){
value.modify(1.5,'Terrain Boost');
}
value.abilityModify(1.5,'Long Reach');
if(['dive','twister','aeroblast','bleakwindstorm','dragonascent','dragondarts',
'esperwing','fairywind','flyingpress','gravapple','icywind','ominouswind',
'razorwind','silverwind','skyuppercut','steelwing','thunder','thunderbolt','thundershock'].includes(move.id)){
value.modify(1.5,'Terrain Boost');
}
if(['sandsearstorm','springtidestorm','windboltstorm','gravapple','gravity','ingrain','smackdown','thousandarrows'].includes(move.id)){
value.modify(1.3,'Terrain Boost');
}
}
if(this.battle.hasPseudoWeather('Infernal Field')){
if(['punishment','smog','dreameater'].includes(move.id)){
value.modify(2);
}
if(['Dark','Fire'].includes(move.type)||['blastburn','infernalparade','inferno','infernooverdrive','precipiceblades','ragingfury'].includes(move.id)){
value.modify(1.5,'Terrain Boost');
}
if(['glaciate','judgement','originpulse','purify'].includes(move.id)){
value.modify(1.3);
}
if(['Fairy','Water'].includes(move.type)&&move.id!='spiritbreak'){
value.modify(0.5);
}
}
if(this.battle.hasPseudoWeather('Dark Crystal Cavern Field')){
if(['prismaticlaser'].includes(move.id)){
value.modify(2);
}
if(['blackholeeclipse','darkpulse','nightdaze','nightslash','menacingmoonrazemaelstrom','shadowball','shadowbone','shadowclaw','shadowforce','shadowpunch','shadowsneak'].includes(move.id)){
value.modify(1.5,'Terrain Boost');
}
if(move.id==='lightthatburnsthesky'){
value.modify(0.5);
}
}
if(this.battle.hasPseudoWeather('Rainbow Field')){
if(move.type==='Normal'&&move.category==='Special'){
value.modify(1.5);
}else if(['aurorabeam','dazzlinggleam','dragonpulse','firepledge','fleurcannon','grasspledge',
'heartstamp','hiddenpower','judgement','mirrorbeam','mistball','moonblast','mysticalfire',
'oceanicoperetta','prismaticlaser','relicsong','sacredfire','secretpower','silverwind',
'solarbeam','solarblade','sparklingaria','triattack','twinkletackle','waterpledge',
'weatherball','zenheadbutt'].includes(move.id)){
value.modify(1.5,'Terrain Boost');
}else if(move.id==='lightthatburnsthesky'){
value.modify(1.3);
}else if(['darkpulse','neverendingnightmare','nightdaze','shadowball'].includes(move.id)){
value.modify(0.5,'Terrain Boost');
}
}
if(this.battle.hasPseudoWeather('Crystal Cavern Field')){
if(move.id==='tectonicrage'||this.battle.fieldCounter('transformation')===1&&
['bulldoze','earthquake','fissure','magnitude'].includes(move.id)){
value.modify(1.3,'Crystal Cavern Field');
}
if(['Rock','Dragon'].includes(move.type)){
value.modify(1.5);
}
if(['judgement','multiattack','prismaticlaser','rockclimb','strength','ancientpower','diamondstorm','lusterpurge','powergem','rocksmash','rocktomb'].includes(move.id)){
value.modify(1.5,'Terrain Boost');
}
if(['aurorabeam','dazzlinggleam','doomdesire','flashcannon','menacingmoonrazemaelstrom','mirrorbeam','mirrorshot','moongeistbeam','photongeyser','signalbeam','technoblast'].includes(move.id)){
value.modify(1.3);
}
}
if(this.battle.hasPseudoWeather('Blessed Field')){
if(['Normal','Fairy'].includes(move.type)&&move.category==='Special'){
value.modify(1.5);
}
if(['Dragon','Psychic'].includes(move.type)){
value.modify(1.2);
}
if(move.type==='Dark'&&move.category==='Special'||move.type==='Ghost'){
value.modify(0.5);
}
if(['extremespeed','judgement','sacredfire','mysticalfire','magicalleaf','ancientpower','sacredsword','return'].includes(move.id)){
value.modify(1.5,'Terrain Boost');
}
if(['aeroblast','behemothblade','behemothbash','crushgrip','diamondstorm','dragonascent',
'doomdesire','dynamaxcannon','eternabeam','fleurcannon','genesissupernova','hyperspacehole',
'landswrath','lusterpurge','menacingmoonrazemaelstrom','mistball','moongeistbeam','multipulse',
'originpulse','precipiceblades','prismaticlaser','psychoboost','psystrike','relicsong',
'roaroftime','searingsunrazesmash','secretsword','spacialrend','sunsteelstrike','ominouswind',
'phantomforce','shadowforce','spectralscream','lightthatburnsthesky'].includes(move.id)){
value.modify(1.3);
}
}
if(this.battle.hasPseudoWeather('Fairy Tale Field')){
if(['Dragon','Steel','Fairy'].includes(move.type))value.modify(1.5,'Fairy Tale Field');
if(['airslash','aquacutter','behemothblade','ceaselessedge','leafblade','nightslash','psychocut',
'razorshell','smartstrike','solarblade','stoneaxe','ancientpower','behemothbash','fleurcannon',
'magiicalleaf','menacingmoonrazemaelstrom','moongeistbeam','mysticalfire','oceanicoperetta','relicsong',
'sparklingaria'].includes(move.id)){
value.modify(1.5);
}
if(['drainingkiss','mistball'].includes(move.id)){
value.modify(2.0);
}
}
if(this.battle.hasPseudoWeather('Starlight Arena Field')){
if(['Dark','Psychic'].includes(move.type)){
value.modify(1.5);
}else if(move.type==='Fairy'){
value.modify(1.3);
}else if(['aurorabeam','dazzlinggleam','flashcannon','lusterpurge',
'mirrorbeam','mirrorshot','moonblast','nightdaze','nightslash',
'photongeyser','prismaticlaser','signalbeam','technoblast','solarbeam'].includes(move.id)){
value.modify(1.5);
}else if(move.id==='doomdesire'){
value.modify(4);
}else if(['blackholeeclypse','cometpunch','dracometeor','hyperspacefury','hyperspacehole','lightthatburnsthesky','menacingmoonrazemaelstrom','meteorassault','meteormash','moongeistbeam','spacialrend','searingsunrazesmash','sunsteelstrike','swift'].includes(move.id)){
value.modify(2);
}
}
if(this.battle.hasPseudoWeather('New World Field')){
if(move.type==='Dark'){
value.modify(1.5);
}
if(['ancientpower','blackholeeclipse','cometpunch','dracometeor','futuresight','hyperspacefury','hyperspacehole','lightthatburnsthesky','meteormash','moonblast','spacialrend','swift','vacuumwave'].includes(move.id)){
value.modify(2);
}
if(['aeroblast','aurorabeam','blueflare','boltstrike','continentalcrush','coreenforcer','crushgrip','dazzlinggleam','diamondstorm','dragonascent','earthpower','eruption','flashcannon','fleurcannon','freezeshock','fusionbolt','fusionflare','genesissupernova','iceburn','judgment','landswrath','lusterpurge','magmastorm','menacingmoonrazemaelstrom','mindblown','mirrorbeam','mirrorshot','mistball','moongeistbeam','multiattack','oblivionwing','originpulse','photongeyser','plasmafists','powergem','precipiceblades','prismaticlaser','psychoboost','psystrike','relicsong','roaroftime','sacredfire','sacredsword','searingshot','searingsunrazesmash','secretsword','seedflare','shadowforce','signalbeam','soulstealing7starstrike','spectralthief','steameruption','sunsteelstrike','technoblast','thousandarrows','thousandwaves','vcreate'].includes(move.id)){
value.modify(1.5);
}
if(['bulldoze','magnitude','earthquake'].includes(move.id)){
value.modify(0.25);
}
if(move.id==='doomdesire'){
value.modify(4);
}
}
if(this.battle.hasPseudoWeather('Dimensional Field')){
if(['Dark','Shadow'].includes(move.type)){
value.modify(1.5);
}
if(move.type==='Ghost'){
value.modify(1.2);
}
if(move.type==='Fairy'){
value.modify(0.5);
}
if(['dynamaxcannon','eternabeam','hyperspacefury','hyperspacehole','roaroftime','shadowforce','spacialrend','fierywrath','freezingglare','lashout','outrage','ragingfury','stompingtantrum','thrash'].includes(move.id)){
value.modify(1.5);
}
if(['darkpulse','nightdaze'].includes(move.id)){
value.modify(1.2);
};
if(['freezeshock','glaciate','iceburn','seedflare'].includes(move.id)||
this.battle.fieldCounter('transformation')===1&&['blizzard','coldtruth','sheercold'].includes(move.id)){
value.modify(1.3);
}
}
if(this.battle.hasPseudoWeather('Haunted Field')){
if(move.type==='Ghost'){
value.modify(1.5);
}
if(['firespin','flameburst','flamecharge','inferno','astonish','boneclub','bonerush','bonemerang'].includes(move.id)){
value.modify(1.5);
}
if(move.id==='shadowbone'){
value.modify(1.2);
};
if(['judgement','originpulse','purify','sacredfire','dazzlinggleam'].includes(move.id)){
value.modify(1.3);
}
}
if(this.battle.hasPseudoWeather('Bewitched Woods Field')){
if(['Fairy','Grass'].includes(move.type)){
value.modify(1.5);
}
if(move.type==='Dark'){
value.modify(1.3);
}
if(['hex','mysticalfire','spiritbreak'].includes(move.id)){
value.modify(1.5);
};
if(['aurorabeam','bubblebeam','chargebeam','flashcannon','hyperbeam','icebeam','magicalleaf','mirrorbeam','psybeam','signalbeam'].includes(move.id)){
value.modify(1.4);
};
if(['darkpulse','moonblast','nightdaze'].includes(move.id)){
value.modify(1.2);
}
}
if(this.battle.hasPseudoWeather('Chess Board Field')){
if(['ancientpower','continentalcrush','psychic','rockthrow','barrage','secretpower','shatteredpsyche','strength','fakeout','feint','feintattack','firstimpression','shadowsneak','smartstrike','suckerpunch'].includes(move.id)){
value.modify(1.5);
};
var confused=!!(target!=null&&target.volatiles['confusion']);
var ability=toID(target==null?void 0:target.ability);
if(!confused&&['adaptability','anticipation','synchronize','telepathy'].includes(ability)){
value.modify(0.5,'Chess Board Field');
}
if(confused||['defeatist','klutz','oblivious','simple','unaware'].includes(ability)){
value.modify(2,'Chess Board Field');
}
if(confused||['gorillatactics','reckless'].includes(ability))value.modify(1.2,'Chess Board Field');
if(!pokemon.volatiles['queen'])value.abilityModify(1.5,'Queenly Majesty');
if(serverPokemon.chessPiece==='queen'&&target)value.modify(1.5,'Queen');
if(serverPokemon.chessPiece==='knight'&&move.target==='allAdjacentFoes')value.modify(1.25,'Knight');
if(value.tryAbility('Illusion')&&pokemon.getSpeciesForme()!==serverPokemon.speciesForme){
value.modify(1.2,'Illusion');
}
value.abilityModify(2,'Competitive');
}
if(this.battle.hasPseudoWeather('Big Top Arena Field')){
if(move.type==='Fighting'&&move.category==='Physical'||[
'blazekick','bodyslam','bounce','brutalswing','bulldoze','continentalcrush','crabhammer','doubleironbash','dragonhammer','dragonrush',
'dualchop','earthquake','gigaimpact','gravapple','headlongrush','heatcrash','heavyslam','highhorsepower','icehammer','iciclecrash',
'irontail','magnitude','meteormash','pound','skydrop','slam','smackdown','stomp','stompingtantrum','strength','woodhammer'].
includes(move.id)){
var strong=['guts','hugepower','purepower','sheerforce'].includes(toID(serverPokemon.ability||pokemon.ability));
function strike(roll){
if(roll>=15)return 3;
if(roll>=13)return 2;
if(roll>=9)return 1.5;
if(roll>=3)return 1;
return 0.5;
}
var atk=pokemon.boosts.atk||0;
var _min3=value.value*strike((strong?14:0)+atk);
var _max3=(value.maxValue||value.value)*strike((strong?15:14)+atk);
if(_min3===_max3)value.set(_min3,'Big Top Arena Field');else
value.setRange(_min3,_max3,'Big Top Arena Field');
}
if(['acrobatics','fly','firelash','powerwhip','vinewhip','fierydance','petaldance','revelationdance','firstimpression','drumbeating'].includes(move.id)||move.flags.sound){
value.modify(1.5);
};
if(move.id==='payday'){
value.modify(2);
}
}
if(this.battle.hasPseudoWeather('Factory Field')){
if(['doubleironbash','flashcannon','geargrind','gyroball','magnetbomb'].includes(move.id)){
value.modify(2);
};
if(['steamroller','superumdsequence','technoblast'].includes(move.id)){
value.modify(1.5);
};
if(move.type==='Electric'){
value.modify(1.2);
};
}
if(this.battle.hasPseudoWeather('Short-Circuit Field')){
if(move.type==='Electric'){
var index=this.battle.fieldCounter('electricModifierIndex');
value.modify(terrain==='Electric Terrain'?2:[0.8,1.5,0.5,1.2,2][index],'Short-Circuit Field');
}
if(move.id==='steelbeam'){
value.modify(10/6);
}
if(['geargrind','superumdmove','dazzlinggleam','gyroball','hydrovortex','magnetbomb','muddywater','surf','flashcannon'].includes(move.id)){
value.modify(1.5);
}
if(['aurawheel','chargebeam','discharge','gigavolthavoc','iondeluge','overdrive','paraboliccharge','superumdmove','wildcharge','darkpulse','nightdaze','nightslash','phantomforce','shadowball','shadowbone','shadowclaw','shadowforce','shadowpunch','shadowsneak'].includes(move.id)){
value.modify(1.3);
}
if(move.id==='lightthatburnsthesky'){
value.modify(0.5);
}
}
if(this.battle.hasPseudoWeather('Glitch Field')){
if(move.type==='Psychic'){
value.modify(1.2);
}
}
if(this.battle.hasPseudoWeather('Mirror Arena Field')){
if(move.id==='mirrorshot'){
value.modify(2);
};
if(['aurorabeam','signalbeam','flashcannon','lusterpurge','doomdesire','dazzlinggleam','technoblast','prismaticlaser','photongeyser'].includes(move.id)){
value.modify(1.5);
}
}
if(this.battle.hasPseudoWeather('Corrupted Cave Field')){
if(move.type==='Poison'){
value.modify(1.5);
}
if(['Grass','Rock'].includes(move.type)){
value.modify(1.2);
}
if(move.type==='Fairy'){
value.modify(0.5);
}
if(move.type==='Flying'&&!move.flags.contact){
value.modify(0.5);
}
value.abilityModify(1.5,'Corrosion');
if(['applceacid','seedflare'].includes(move.id)){
value.modify(1.5);
}
if(['seedflare','solarbeam','solarblade','blastburn','eruption','heatwave','infernooverdrive','lavaplume'].includes(move.id)){
value.modify(1.3);
}
}
if(this.battle.hasPseudoWeather('Colosseum Field')){
if(value.tryAbility('Skill Link')&&move.multihit&&Array.isArray(move.multihit)&&move.multihit.length){
value.modify(1.2);
}
if(['beatup','fellstinger','payday','pursuit','reversal'].includes(move.id)){
value.modify(2);
};
if(['bonerush','boneclub','bonemerang','brutalswing','bulletpunch','clangingscales','electroweb','firstimpression','leafblade','meteorassault','meteormash','nightslash','payback','punishment','psychocut','sacredsword','secretsword','smackdown','smartstrike','steamroller','submission','vinewhip'].includes(move.id)){
value.modify(1.5);
};
if(['anchorshot','crabhammer','dragonhammer','drillpeck','drillrun','firelash','icehammer','iciclespear','powerwhip','shadowbone','spiritshackle','stormthrow','suckerpunch','throatchop','woodhammer'].includes(move.id)){
value.modify(1.2);
}
}
if(this.battle.hasPseudoWeather('Flower Garden Field')){
var growth=this.battle.fieldCounter('growth');
if(growth>=2&&move.type==='Grass')value.modify([1.1,1.3,1.5,2][growth-2],'Flower Garden Field');
if(growth>=3&&move.type==='Fire')value.modify(1.5,'Flower Garden Field');
if(growth>=3&&move.type==='Bug')value.modify(growth===3?1.5:2,'Flower Garden Field');
if(growth>=3&&['fleurcannon','petalblizzard','petaldance'].includes(move.id)){
value.modify(growth===3?1.2:1.5,'Flower Garden Field');
}
}
if(this.battle.hasPseudoWeather('Concert Venue Field')){
if(this.battle.fieldCounter('hype')<=1&&['rage','thrash','frustration','outrage','stompingtantrum'].includes(move.id)){
value.modify(1.5,'Concert Venue Field');
}
if(move.flags.sound){
value.modify(1.5);
};
if(['acid','acidspray','circlethrow','dragontail','drumbeating','fakeout','firstimpression','rollout'].includes(move.id)){
value.modify(1.5);
}
}
if(this.battle.hasPseudoWeather('Back Alley Field')){
if(move.type==='Dark'&&move.category==='Physical'){
value.modify(1.5);
};
if(['Bug','Poison'].includes(move.type)){
value.modify(1.3);
};
if(move.type==='Fairy'){
value.modify(0.5);
};
if(['aerialace','aircutter','airslash','aquacutter','behemothblade','ceaselessedge','crosspoison','cut','furycutter','hexingslash',
'leafblade','nightslash','psychocut','razorleaf','razorshell','sacredsword','slashandburn','solarblade','slash','stoneaxe','xscissor',
'branchpoke','drillpeck','drillrun','falsesurrender','fellstinger','furyattack','gildedarrow','gildedhelix','glaciallance','hornattack',
'hornleech','megahorn','needlearm','peck','pinmissile','pluck','poisonjab','poisonsting','quicksilverspear','twineedle','smartstrike',
'firstimpression','beatup','payday','shadowsneak','smog','spectralthief','steamroller','technoblast'].includes(move.id)){
value.modify(1.5);
};
if(['boomburst','echoedvoice','hypervoice','uproar'].includes(move.id)){
value.modify(1.3);
}
if(!serverPokemon.item&&['covet','thief'].includes(move.id)&&target&&(!target.prevItem||target.item)){
value.setRange(value.value,(value.maxValue||value.value)*2,'If the target has a removable item');
}
}
if(this.battle.hasPseudoWeather('City Field')){
if(move.type==='Normal'&&move.category==='Physical'){
value.modify(1.5);
};
if(['Bug','Poison','Steel'].includes(move.type)){
value.modify(1.3);
};
if(move.type==='Fairy'){
value.modify(0.7);
};
if(['firstimpression','beatup','payday','shadowsneak','smog','spectralthief','steamroller','technoblast'].includes(move.id)){
value.modify(1.5);
};
if(['covet','pursuit','thief'].includes(move.id)){
value.modify(1.3);
}
}
if(this.battle.hasPseudoWeather('Swamp Field')){
if(['Bug','Water','Grass'].includes(move.type)){
value.modify(1.3);
};
if(move.type==='Fire'){
value.modify(0.8);
};
if(['smackdown','thousandarrows','brine','gunkshot','hydrovortex','mudbarrage','mudbomb','mudshot','mudslap','muddywater','savagespinout','sludgewave'].includes(move.id)){
value.modify(1.5);
};
if(['bulldoze','earthquake','magnitude'].includes(move.id)){
value.modify(0.25);
}
}
if(this.battle.hasPseudoWeather('Corrosive Field')){
value.abilityModify(1.5,'Corrosion');
if(['acid','acidspray','grassknot','snaptrap'].includes(move.id)){
value.modify(2);
};
if(['appleacid','mudbomb','mudslap','mudshot','muddywater','smackdown','thousandarrows','whirlpool'].includes(move.id)){
value.modify(1.5);
};
if(['seedflare'].includes(move.id)){
value.modify(1.3);
};
}
if(this.battle.hasPseudoWeather('Desert Field')){var _target$isGrounded5;
if(move.type==='Water'&&!['scald','steameruption'].includes(move.id)&&pokemon.isGrounded(serverPokemon)||
move.type==='Electric'&&((_target$isGrounded5=target==null?void 0:target.isGrounded())!=null?_target$isGrounded5:true)){
value.modify(0.5);
};
if(['burnup','dig','needlearm','heatwave','pinmissile','sandtomb','sandsearstorm','scald','scorchingsands','searingsunrazesmash','solarbeam','solarblade','steameruption','thousandwaves','bonemerang','boneclub','bonerush','shadowbone'].includes(move.id)){
value.modify(1.5);
};
}
if(this.battle.hasPseudoWeather('Rocky Field')){
if(move.type==='Rock'){
value.modify(1.5);
};
if(move.id==='rocksmah'){
value.modify(2);
};
if(['accelerock','bulldoze','earthquake','magnitude','rockclimb','strength'].includes(move.id)){
value.modify(1.5);
}
}
if(this.battle.hasPseudoWeather('Forest Field')){
if(move.id==='galestrike')value.modify(1.5,'Gale Strike');
var flooding=this.battle.fieldCounter('flooding');
if(move.id==='surf'&&flooding>=2||move.id==='muddywater'&&flooding>=1){
value.modify(1.3,'Forest Field');
}
if(move.type==='Grass'){
value.modify(1.5);
};
if(move.type==='Bug'&&move.category==='Special'){
value.modify(1.5);
};
if(move.id==='cut'){
value.modify(2);
};
if(['aircutter','attackorder','electroweb','gravapple','airslash','breakingswipe','furycutter','galestrike','psychocut','slash'].includes(move.id)){
value.modify(1.5);
};
if(['surf','muddywater'].includes(move.id)){
value.modify(0.5);
};
}
if(this.battle.hasPseudoWeather('Volcanic Top Field')){
if(move.type==='Fire'){
value.modify(1.2);
};
if(move.type==='Flying'){
value.modify(1.3);
};
if(move.type==='Ice'){
value.modify(0.5);
};
if(move.type==='Water'&&!['scald','steameruption'].includes(move.id)){
value.modify(0.9);
};
if(['clearsmog','thunder','infernalparade','scald','steameruption','gust','icywind','ominouswind','precipiceblades','razorwind','silverwind','smog','twister'].includes(move.id)){
value.modify(1.5);
};
if(['eruption','heatwave','lavaplume','magmadrift','magmastorm','bounce','fly','blizzard','glaciate','subzeroslammer'].includes(move.id)){
value.modify(1.3);
};
if(['hydropump','hydrovortex','muddywater','oceanicoperetta','sparklingaria','surf','waterpledge','waterspout','watersport'].includes(move.id)){
value.modify(0.625);
};
}
if(this.battle.hasPseudoWeather('Wasteland Field')){
if(move.id==='spitup'){
value.modify(2);
};
if(['mudbomb','mudshot','mudslap','powerwhip','vinewhip'].includes(move.id)){
value.modify(1.5);
};
if(['gunkshot','octazooka','sludge','sludgebomb','sludgewave'].includes(move.id)){
value.modify(1.2);
};
if(['bulldoze','earthquake','magnitude'].includes(move.id)){
value.modify(0.25);
};
}
if(this.battle.hasPseudoWeather('Beach Field')){
if(['mudbomb','mudshot','mudslap','sandtomb'].includes(move.id)){
value.modify(2);
};
if(['strength','brine','clangoroussoulblaze','crabhammer','hiddenpower','landswrath','muddywater','razorshell','sandsearstorm','scorchingsands','shellsidearm','shelltrap','smellingsalts','surf','thousandwaves','wavecrash'].includes(move.id)){
value.modify(1.5);
};
if(['aurasphere','focusblast','focuspunch','storedpower','zenehadbutt'].includes(move.id)){
value.modify(1.3);
};
if(move.id==='psychic'){
value.modify(1.2);
}
}
if(this.battle.hasPseudoWeather('Cave Field')){
if(move.id==='dragonpulse'&&this.battle.fieldCounter('dragonden')===1||
this.battle.fieldCounter('volcanic')===1&&[
'eruption','feverpitch','fusionflare','heatwave','lavaplume','magmadrift','overheat'].
includes(move.id)){
value.modify(1.3,'Cave Field');
}
if(move.type==='Rock'){
value.modify(1.5);
};
if(move.flags.sound){
value.modify(1.5);
};
if(move.type==='Flying'&&!move.flags.contact){
value.modify(0.5);
};
if(move.id==='rocktomb'){
value.modify(1.5);
};
if(['diamondstorm','powergem','aciddownpour','sludgewave','blizzard','subzeroslammer','devastatingdrake','dracometeor'].includes(move.id)){
value.modify(1.3);
}
}
if(['Mountain Field','Snowy Mountain Field'].includes(field)&&value.tryWeather('Delta Stream')){
if(move.type==='Flying'&&move.category==='Special')value.modify(1.5,'Strong winds');
if(['fairywind','gust','icywind','ominouswind','razorwind','silverwind','twister'].includes(move.id)){
value.modify(1.5,'Strong winds');
}
}
if(this.battle.hasPseudoWeather('Mountain Field')){
if(move.type==='Rock'){
value.modify(1.5);
};
if(move.type==='Flying'){
value.modify(1.5);
};
value.abilityModify(1.5,'Long Reach');
if(['hypervoice','circlethrow','stormthrow','avalanche','thunder','eruption','vitalthrow','fairywind','icywind','mountaingale','ominouswind','razorwind','silverwind','twister'].includes(move.id)){
value.modify(1.5);
};
if(['bounce','fly','blizzard','glaciate','mountaingale','subzeroslammer','eruption','infernooverdrive','lavaplume','magmadrift'].includes(move.id)){
value.modify(1.3);
}
}
if(this.battle.hasPseudoWeather('Snowy Mountain Field')){
if(['Rock','Ice','Flying'].includes(move.type)){
value.modify(1.5);
};
if(move.type==='Fire'){
value.modify(0.5);
};
value.abilityModify(1.5,'Long Reach');
if(move.id==='icywind'){
value.modify(2);
};
if(['fairywind','avalanche','bittermalice','glaciate','powdersnow','circlethrow','stormthrow','vitalthrow','hypervoice','mountaingale','ominouswind','razorwind','silverwind','twister'].includes(move.id)){
value.modify(1.5);
};
if(['scald','steameruption'].includes(move.id)){
value.modify(0.5);
};
if(['firepledge','flameburst','heatwave','incinerate','infernooverdrive','lavaplume','mindblown','ragingfury','searingshot','bounce','fly','eruption','magmadrift'].includes(move.id)){
value.modify(1.3);
};
}
if(this.battle.hasPseudoWeather('Deep Earth Field')){
if(move.type==='Ground'&&target){
value.modify(this.pokemonHasType(target,'Ground')?0.5:1.5,'Deep Earth Field');
}
if(move.type==='Rock'){
value.modify(1.3);
};
if(move.type==='Psychic'){
value.modify(1.3);
};
if(move.priority<0||move.id==='coreenforcer'){
value.modify(1.3);
};
if(move.priority>0){
value.modify(0.7);
};
if(['landswrath','precipiceblades','tectonicrage','smackdown','magnetbomb','coreenforcer','crushgrip'].includes(move.id)){
value.modify(2);
};
if(['ancientpower','bodypress','lowkick','spacialrend','thousandarrows','thousandwaves','grassknot','crabhammer','hammerarm','icehammer','circlethrow','stormthrow','vitalthrow','bodyslam','dragonrush','fling','gravapple','heatcrash','heavyslam','iciclecrash','steamroller','stomp'].includes(move.id)){
value.modify(1.5);
};
}
}
if(rejuv)applyTeraAndStatus();
return value;
};_proto2.





















































getItemBoost=function getItemBoost(move,value,moveType){var _value$pokemon$volati,_BattleTooltips$orbUs,_BattleTooltips$orbTy;
var item=this.battle.dex.items.get(value.serverPokemon.item);
var itemName=item.name;
var moveName=move.name;
var species=this.battle.dex.species.get(value.serverPokemon.speciesForme);
var isTransform=value.pokemon.volatiles.transform;
var speciesName=isTransform&&(_value$pokemon$volati=value.pokemon.volatiles.formechange)!=null&&_value$pokemon$volati[1]&&this.battle.gen<=4?
this.battle.dex.species.get(value.pokemon.volatiles.formechange[1]).baseSpecies:species.baseSpecies;


if(item.onPlate===moveType&&!item.zMove){
value.itemModify(1.2);
return value;
}


if(BattleTooltips.incenseTypes[item.name]===moveType){
value.itemModify(1.2);
return value;
}


if(BattleTooltips.itemTypes[item.name]===moveType){
value.itemModify(this.battle.gen<4?1.1:1.2);
return value;
}


if(item.name==='Light Ball'&&this.battle.gen===4&&speciesName==='Pikachu'){
value.itemModify(2);
return value;
}


if(item.name==='Soul Dew'&&this.battle.gen<7)return value;
if((_BattleTooltips$orbUs=BattleTooltips.orbUsers[speciesName])!=null&&_BattleTooltips$orbUs.includes(item.name)&&(_BattleTooltips$orbTy=
BattleTooltips.orbTypes[item.name])!=null&&_BattleTooltips$orbTy.includes(moveType)){
value.itemModify(1.2);
return value;
}
if(speciesName==='Ogerpon'){
var speciesForme=value.pokemon.getSpeciesForme();
if(
speciesForme.startsWith('Ogerpon-Wellspring')&&itemName==='Wellspring Mask'||
speciesForme.startsWith('Ogerpon-Hearthflame')&&itemName==='Hearthflame Mask'||
speciesForme.startsWith('Ogerpon-Cornerstone')&&itemName==='Cornerstone Mask')
{
value.itemModify(1.2);
return value;
}
}


if(BattleTooltips.noGemMoves.includes(moveName))return value;
if(itemName===moveType+' Gem'){
value.itemModify(this.battle.gen<6?1.5:1.3);
return value;
}

if(itemName==='Muscle Band'&&move.category==='Physical'||
itemName==='Wise Glasses'&&move.category==='Special'||
itemName==='Punching Glove'&&move.flags['punch']){
value.itemModify(1.1);
}


if(item.onMemory&&speciesName==='Silvally'&&move.type===item.onMemory&&value.serverPokemon.ability==='silvallycrest'){
value.itemModify(1.2);
}
return value;
};_proto2.
getPokemonTypes=function getPokemonTypes(pokemon){var preterastallized=arguments.length>1&&arguments[1]!==undefined?arguments[1]:false;
if(!pokemon.getTypes){
if(pokemon.fusion){
return Dex.getFusionTypes(this.battle.dex.species.get(pokemon.speciesForme).types,this.battle.dex.species.get(pokemon.fusion).types);
}
return this.battle.dex.species.get(pokemon.speciesForme).types;
}

return pokemon.getTypeList(undefined,preterastallized);
};_proto2.
pokemonHasType=function pokemonHasType(pokemon,type,types){
if(!types)types=this.getPokemonTypes(pokemon);for(var _i76=0,_types2=
types;_i76<_types2.length;_i76++){var curType=_types2[_i76];
if(curType===type)return true;
}
return false;
};_proto2.
getAllyAbility=function getAllyAbility(ally){
var serverPokemon;
if(this.battle.myAllyPokemon){
serverPokemon=this.battle.myAllyPokemon[ally.slot];
}else if(this.battle.myPokemon){
serverPokemon=this.battle.myPokemon[ally.slot];
}
return ally.effectiveAbility(serverPokemon);
};_proto2.
getPokemonAbilityData=function getPokemonAbilityData(clientPokemon,serverPokemon){
var abilityData=

{
ability:'',baseAbility:'',possibilities:[],abilities:[],baseAbilities:[]
};
if(clientPokemon){
if(clientPokemon.ability){
abilityData.ability=clientPokemon.ability||clientPokemon.baseAbility;
abilityData.abilities=[abilityData.ability].concat(clientPokemon.innates||[]);
if(clientPokemon.baseAbility){
abilityData.baseAbility=clientPokemon.baseAbility;
abilityData.baseAbilities=[clientPokemon.baseAbility].concat(clientPokemon.baseInnates||[]);
}
}else{
var speciesForme=clientPokemon.getSpeciesForme()||(serverPokemon==null?void 0:serverPokemon.speciesForme)||'';
var species=this.battle.dex.species.get(speciesForme);
if(species.exists&&species.abilities){
abilityData.possibilities=Object.values(species.abilities);
var isFranticFusions=this.battle.rules['Frantic Fusions Mod'];
if(isFranticFusions||this.battle.rules['Infinite Fusion Mod']&&clientPokemon.fusion){
var fusionSpecies=this.battle.dex.species.get(isFranticFusions?clientPokemon.name:clientPokemon.fusion);
if(fusionSpecies.exists&&fusionSpecies.name!==species.name){for(var _i78=0,_Object$values8=
Object.values(fusionSpecies.abilities);_i78<_Object$values8.length;_i78++){var newAbility=_Object$values8[_i78];
if(abilityData.possibilities.includes(newAbility))continue;
abilityData.possibilities.push(newAbility);
}
}
}
}
}
}
if(serverPokemon){
if(!abilityData.ability)abilityData.ability=serverPokemon.ability||serverPokemon.baseAbility;
if(!abilityData.baseAbility&&serverPokemon.baseAbility){
abilityData.baseAbility=serverPokemon.baseAbility;
}
if(!abilityData.abilities.length){
abilityData.abilities=[abilityData.ability].concat(serverPokemon.innates||[]);
}
if(!abilityData.baseAbilities.length){
abilityData.baseAbilities=[abilityData.baseAbility].concat(serverPokemon.baseInnates||[]);
}
}
if(abilityData.abilities.length===0)abilityData.abilities=[abilityData.ability];
return abilityData;
};_proto2.
getPokemonAbilityText=function getPokemonAbilityText(
clientPokemon,
serverPokemon,
isActive,
hidePossible)
{var _this5=this;
var text='';
var abilityData=this.getPokemonAbilityData(clientPokemon,serverPokemon);
if(!isActive){

var ability=abilityData.baseAbility||abilityData.ability;
var abilities=abilityData.baseAbility?abilityData.baseAbilities:abilityData.abilities;
if(ability)text="<small>"+TL.label(TL(["Ability"]))+"</small>"+TL(this.battle.dex.abilities.get(ability));
if(ability&&abilities.length>1){
text='<small>Abilities:</small> '+abilities.map(function(name){return TL(_this5.battle.dex.abilities.get(name));}).join(' / ');
}
}else{
if(abilityData.ability){
var abilityName=abilityData.abilities.map(function(ability){return TL(_this5.battle.dex.abilities.get(ability));}).join(' / ');
var label=abilityData.abilities.length>1?'<small>Abilities:</small> ':"<small>"+TL.label(TL(["Ability"]))+"</small>";
text=label+abilityName;
var baseAbilityName=abilityData.baseAbilities.map(function(ability){return TL(_this5.battle.dex.abilities.get(ability));}).join(' / ');
if(baseAbilityName&&baseAbilityName!==abilityName){
text+=' '+TL(["(base: ",")"],baseAbilityName);
}
}
}
var tier=this.battle.tier;
if(!text&&abilityData.possibilities.length&&!hidePossible&&
!(tier.includes('Almost Any Ability')||tier.includes('Hackmons')||
tier.includes('Inheritance')||tier.includes('Metronome'))){
var parenthetical='';for(var _i80=0,_abilityData$possibil2=
abilityData.possibilities.map(function(ability){return TL(_this5.battle.dex.abilities.get(ability));});_i80<_abilityData$possibil2.length;_i80++){var next=_abilityData$possibil2[_i80];
parenthetical=parenthetical?parenthetical+TL([", ",""],next):next;
}
text='<small>'+TL.label(TL(["Ability"]))+'</small>'+TL(["?"])+TL([" (",")"],parenthetical);
}
return text;
};return BattleTooltips;}();BattleTooltips.LONG_TAP_DELAY=500;BattleTooltips.LONG_CLICK_DELAY=700;BattleTooltips.longTapTimeout=null;BattleTooltips.elem=null;BattleTooltips.parentElem=null;BattleTooltips.isLocked=false;BattleTooltips.isPressed=false;BattleTooltips.outsideClickListenerAdded=false;BattleTooltips.zMoveEffects={'clearnegativeboost':'zEffectClearNegativeBoost','crit2':'zEffectCrit2','heal':'zEffectHeal','curse':'zEffectCurse','redirect':'zEffectRedirect','healreplacement':'zEffectHealReplacement'};BattleTooltips.fieldMoves={'Electric Terrain':['Thunderbolt','Electric'],'Grassy Terrain':['Energy Ball','Grass'],'Misty Terrain':['Mist Ball','Fairy'],'Psychic Terrain':['Psychic','Psychic'],'Volcanic Field':['Flamethrower','Fire'],'Corrosive Mist Field':['Venoshock','Poison'],'Icy Field':['Tri Attack','Ice'],'Water Surface Field':['Whirlpool','Water'],'Underwater Field':['Whirlpool','Water'],'Murkwater Surface Field':['Sludge Wave','Poison'],'Dragons Den Field':['Dragon Pulse','Dragon'],'Frozen Dimensional Field':['Ice Beam','Ice'],'Sky Field':['Sky Attack','Flying'],'Infernal Field':['Punishment','Fire'],'Dark Crystal Cavern Field':['Dark Pulse','Dark'],'Rainbow Field':['Aurora Beam','Dragon'],'Blessed Field':['Judgment','Normal'],'Fairy Tale Field':['Secret Sword','Fairy'],'Starlight Arena Field':['Moonblast','Dark'],'New World Field':['Spacial Rend','???'],'Inverse Field':['Trick Room','Normal'],'Dimensional Field':['Dark Pulse','Dark'],'Haunted Field':['Phantom Force','Ghost'],'Bewitched Woods Field':['Dazzling Gleam','Fairy'],'Chess Board Field':['Ancient Power','Psychic'],'Big Top Arena Field':['Acrobatics','Fighting'],'Factory Field':['Gear Grind','Steel'],'Short-Circuit Field':['Discharge','Electric'],'Glitch Field':['Metronome','???'],'Mirror Arena Field':['Mirror Shot','Normal'],'Flower Garden Field':['Growth','Grass'],'Corrupted Cave Field':['Gunk Shot','Poison'],'Colosseum Field':['Beat Up','Steel'],'Concert Venue Field':['Hyper Voice','Normal'],'Back Alley Field':['Beat Up','Steel'],'City Field':['Smog','Normal'],'Swamp Field':['Muddy Water','Water'],'Corrosive Field':['Acid','Poison'],'Desert Field':['Sand Tomb','Ground'],'Rocky Field':['Rock Smash','Rock'],'Forest Field':['Wood Hammer','Bug'],'Wasteland Field':['Gunk Shot','Poison'],'Beach Field':['Meditate','Ground'],'Cave Field':['Rock Tomb','Rock'],'Mountain Field':['Rock Slide','Rock'],'Snowy Mountain Field':['Avalanche','Ice'],'Deep Earth Field':['Gravity','Ground']};BattleTooltips.zMoveTable={Poison:"Acid Downpour",Fighting:"All-Out Pummeling",Dark:"Black Hole Eclipse",Grass:"Bloom Doom",Normal:"Breakneck Blitz",Rock:"Continental Crush",Steel:"Corkscrew Crash",Dragon:"Devastating Drake",Electric:"Gigavolt Havoc",Water:"Hydro Vortex",Fire:"Inferno Overdrive",Ghost:"Never-Ending Nightmare",Bug:"Savage Spin-Out",Psychic:"Shattered Psyche",Ice:"Subzero Slammer",Flying:"Supersonic Skystrike",Ground:"Tectonic Rage",Fairy:"Twinkle Tackle",Stellar:"","???":"",Crystal:"",Nuclear:"",Cosmic:"",Light:"",Sound:""};BattleTooltips.maxMoveTable={Poison:"Max Ooze",Fighting:"Max Knuckle",Dark:"Max Darkness",Grass:"Max Overgrowth",Normal:"Max Strike",Rock:"Max Rockfall",Steel:"Max Steelspike",Dragon:"Max Wyrmwind",Electric:"Max Lightning",Water:"Max Geyser",Fire:"Max Flare",Ghost:"Max Phantasm",Bug:"Max Flutterby",Psychic:"Max Mindstorm",Ice:"Max Hailstorm",Flying:"Max Airstream",Ground:"Max Quake",Fairy:"Max Starfall",Stellar:"","???":"",Crystal:"",Nuclear:"",Cosmic:"",Light:"",Sound:""};BattleTooltips.incenseTypes={'Odd Incense':'Psychic','Rock Incense':'Rock','Rose Incense':'Grass','Sea Incense':'Water','Wave Incense':'Water'};BattleTooltips.itemTypes={'Black Belt':'Fighting','Black Glasses':'Dark','Charcoal':'Fire','Dragon Fang':'Dragon','Fairy Feather':'Fairy','Hard Stone':'Rock','Magnet':'Electric','Metal Coat':'Steel','Miracle Seed':'Grass','Mystic Water':'Water','Never-Melt Ice':'Ice','Poison Barb':'Poison','Sharp Beak':'Flying','Silk Scarf':'Normal','Silver Powder':'Bug','Soft Sand':'Ground','Spell Tag':'Ghost','Twisted Spoon':'Psychic'};BattleTooltips.orbUsers={'Latias':['Soul Dew'],'Latios':['Soul Dew'],'Dialga':['Adamant Crystal','Adamant Orb'],'Palkia':['Lustrous Globe','Lustrous Orb'],'Giratina':['Griseous Core','Griseous Orb'],'Venomicon':['Vile Vial']};BattleTooltips.orbTypes={'Soul Dew':['Psychic','Dragon'],'Adamant Crystal':['Steel','Dragon'],'Adamant Orb':['Steel','Dragon'],'Lustrous Globe':['Water','Dragon'],'Lustrous Orb':['Water','Dragon'],'Griseous Core':['Ghost','Dragon'],'Griseous Orb':['Ghost','Dragon'],'Vile Vial':['Poison','Flying']};BattleTooltips.noGemMoves=['Fire Pledge','Fling','Grass Pledge','Struggle','Water Pledge'];var


BattleStatGuesser=function(){










function BattleStatGuesser(formatid){this.formatid=void 0;this.dex=void 0;this.moveCount=null;this.hasMove=null;this.ignoreEVLimits=void 0;this.useStatPoints=void 0;this.supportsEVs=void 0;this.supportsAVs=void 0;
this.formatid=formatid;
this.dex=formatid?Dex.mod(formatid.slice(0,4)):Dex;
this.ignoreEVLimits=
this.dex.gen<3||
(this.formatid.endsWith('hackmons')||this.formatid.endsWith('bh'))&&this.dex.gen!==6||
this.formatid.includes('metronomebattle')||
this.formatid.endsWith('norestrictions');

this.useStatPoints=this.formatid.includes('champions');
this.supportsEVs=!this.formatid.includes('letsgo')&&!this.useStatPoints;
this.supportsAVs=!this.supportsEVs&&this.formatid.endsWith('norestrictions');
}var _proto3=BattleStatGuesser.prototype;_proto3.
guess=function guess(set){
var role=this.guessRole(set);
var comboEVs=this.guessEVs(set,role);
var evs={hp:0,atk:0,def:0,spa:0,spd:0,spe:0};
for(var stat in evs){
evs[stat]=comboEVs[stat]||0;
}
var plusStat=comboEVs.plusStat||'';
var minusStat=comboEVs.minusStat||'';
return{role:role,evs:evs,plusStat:plusStat,minusStat:minusStat,moveCount:this.moveCount,hasMove:this.hasMove};
};_proto3.
guessRole=function guessRole(set){var _item$megaStone;
if(!set)return'?';
if(!set.moves)return'?';

var moveCount={
'Physical':0,
'Special':0,
'PhysicalAttack':0,
'SpecialAttack':0,
'PhysicalSetup':0,
'SpecialSetup':0,
'Support':0,
'Setup':0,
'Restoration':0,
'Offense':0,
'Stall':0,
'SpecialStall':0,
'PhysicalStall':0,
'Fast':0,
'Ultrafast':0,
'bulk':0,
'specialBulk':0,
'physicalBulk':0
};
var hasMove={};
var itemid=toID(set.item);
var item=this.dex.items.get(itemid);
var abilityid=toID(set.ability);

var species=this.dex.species.get(set.species||set.name);
if((_item$megaStone=item.megaStone)!=null&&_item$megaStone[species.name])species=this.dex.species.get(item.megaStone[species.name]);
if(!species.exists)return'?';
var stats=this.getStats(species,set.fusion);

if(set.moves.length<1)return'?';
var needsFourMoves=!['Unown','Ditto'].includes(species.baseSpecies);
var hasFourValidMoves=set.moves.length>=4&&!set.moves.includes('');
var moveids=set.moves.map(toID);
if(moveids.includes('lastresort'))needsFourMoves=false;
if(!hasFourValidMoves&&needsFourMoves&&!this.formatid.includes('metronomebattle')){
return'?';
}

for(var i=0,len=set.moves.length;i<len;i++){
var move=this.dex.moves.get(set.moves[i]);
if(!move.exists)continue;
hasMove[move.id]=1;
if(move.category==='Status'){
if(['batonpass','healingwish','lunardance'].includes(move.id)){
moveCount['Support']++;
}else if(['metronome','assist','copycat','mefirst','photongeyser','shellsidearm'].includes(move.id)){
moveCount['Physical']+=0.5;
moveCount['Special']+=0.5;
}else if(move.id==='naturepower'){
moveCount['Special']++;
}else if(['protect','detect','spikyshield','kingsshield'].includes(move.id)){
moveCount['Stall']++;
}else if(move.id==='wish'){
moveCount['Restoration']++;
moveCount['Stall']++;
moveCount['Support']++;
}else if(move.heal){
moveCount['Restoration']++;
moveCount['Stall']++;
}else if(move.target==='self'){
if(['agility','rockpolish','shellsmash','growth','workup'].includes(move.id)){
moveCount['PhysicalSetup']++;
moveCount['SpecialSetup']++;
}else if(['dragondance','swordsdance','coil','bulkup','curse','bellydrum'].includes(move.id)){
moveCount['PhysicalSetup']++;
}else if(['nastyplot','tailglow','quiverdance','calmmind','geomancy'].includes(move.id)){
moveCount['SpecialSetup']++;
}
if(move.id==='substitute')moveCount['Stall']++;
moveCount['Setup']++;
}else{
if(['toxic','leechseed','willowisp'].includes(move.id)){
moveCount['Stall']++;
}
moveCount['Support']++;
}
}else if(['counter','endeavor','metalburst','mirrorcoat','rapidspin'].includes(move.id)){
moveCount['Support']++;
}else if([
'nightshade','seismictoss','psywave','superfang','naturesmadness','foulplay','endeavor','finalgambit','bodypress'].
includes(move.id)){
moveCount['Offense']++;
}else if(move.id==='fellstinger'){
moveCount['PhysicalSetup']++;
moveCount['Setup']++;
}else{
moveCount[move.category]++;
moveCount['Offense']++;
if(move.id==='knockoff'){
moveCount['Support']++;
}
if(['scald','voltswitch','uturn','flipturn'].includes(move.id)){
moveCount[move.category]-=0.2;
}
}
}
if(hasMove['batonpass'])moveCount['Support']+=moveCount['Setup'];
moveCount['PhysicalAttack']=moveCount['Physical'];
moveCount['Physical']+=moveCount['PhysicalSetup'];
moveCount['SpecialAttack']=moveCount['Special'];
moveCount['Special']+=moveCount['SpecialSetup'];

if(hasMove['dragondance']||hasMove['quiverdance'])moveCount['Ultrafast']=1;

var isFast=stats.spe>=80;
var physicalBulk=(stats.hp+75)*(stats.def+87);
var specialBulk=(stats.hp+75)*(stats.spd+87);

if(hasMove['willowisp']||hasMove['acidarmor']||hasMove['irondefense']||hasMove['cottonguard']){
physicalBulk*=1.6;
moveCount['PhysicalStall']++;
}else if(hasMove['scald']||hasMove['bulkup']||hasMove['coil']||hasMove['cosmicpower']){
physicalBulk*=1.3;
if(hasMove['scald']){
moveCount['SpecialStall']++;
}else{
moveCount['PhysicalStall']++;
}
}
if(abilityid==='flamebody')physicalBulk*=1.1;

if(hasMove['calmmind']||hasMove['quiverdance']||hasMove['geomancy']){
specialBulk*=1.3;
moveCount['SpecialStall']++;
}
if(abilityid==='sandstream'&&species.types.includes('Rock')){
specialBulk*=1.5;
}

if(hasMove['bellydrum']){
physicalBulk*=0.6;
specialBulk*=0.6;
}
if(moveCount['Restoration']){
physicalBulk*=1.5;
specialBulk*=1.5;
}else if(hasMove['painsplit']&&hasMove['substitute']){

moveCount['Stall']--;
}else if(hasMove['painsplit']||hasMove['rest']){
physicalBulk*=1.4;
specialBulk*=1.4;
}
if((hasMove['bodyslam']||hasMove['thunder'])&&abilityid==='serenegrace'||hasMove['thunderwave']){
physicalBulk*=1.1;
specialBulk*=1.1;
}
if((hasMove['ironhead']||hasMove['airslash'])&&abilityid==='serenegrace'){
physicalBulk*=1.1;
specialBulk*=1.1;
}
if(hasMove['gigadrain']||hasMove['drainpunch']||hasMove['hornleech']){
physicalBulk*=1.15;
specialBulk*=1.15;
}
if(itemid==='leftovers'||itemid==='blacksludge'){
physicalBulk*=1+0.1*(1+moveCount['Stall']/1.5);
specialBulk*=1+0.1*(1+moveCount['Stall']/1.5);
}
if(hasMove['leechseed']){
physicalBulk*=1+0.1*(1+moveCount['Stall']/1.5);
specialBulk*=1+0.1*(1+moveCount['Stall']/1.5);
}
if((itemid==='flameorb'||itemid==='toxicorb')&&abilityid!=='magicguard'){
if(itemid==='toxicorb'&&abilityid==='poisonheal'){
physicalBulk*=1+0.1*(2+moveCount['Stall']);
specialBulk*=1+0.1*(2+moveCount['Stall']);
}else{
physicalBulk*=0.8;
specialBulk*=0.8;
}
}
if(itemid==='lifeorb'){
physicalBulk*=0.7;
specialBulk*=0.7;
}
if(abilityid==='multiscale'||abilityid==='magicguard'||abilityid==='regenerator'){
physicalBulk*=1.4;
specialBulk*=1.4;
}
if(itemid==='eviolite'){
physicalBulk*=1.5;
specialBulk*=1.5;
}
if(itemid==='assaultvest'){
specialBulk*=1.5;
}

var bulk=physicalBulk+specialBulk;
if(bulk<46000&&stats.spe>=70)isFast=true;
if(hasMove['trickroom'])isFast=false;
moveCount['bulk']=bulk;
moveCount['physicalBulk']=physicalBulk;
moveCount['specialBulk']=specialBulk;

if(
hasMove['agility']||hasMove['dragondance']||hasMove['quiverdance']||
hasMove['rockpolish']||hasMove['shellsmash']||hasMove['flamecharge'])
{
isFast=true;
}else if(abilityid==='unburden'||abilityid==='speedboost'||abilityid==='motordrive'){
isFast=true;
moveCount['Ultrafast']=1;
}else if(abilityid==='chlorophyll'||abilityid==='swiftswim'||abilityid==='sandrush'){
isFast=true;
moveCount['Ultrafast']=2;
}else if(itemid==='salacberry'){
isFast=true;
}
var ultrafast=hasMove['agility']||hasMove['shellsmash']||
hasMove['autotomize']||hasMove['shiftgear']||hasMove['rockpolish'];
if(ultrafast){
moveCount['Ultrafast']=2;
}
moveCount['Fast']=isFast?1:0;

this.moveCount=moveCount;
this.hasMove=hasMove;

if(species.id==='ditto')return abilityid==='imposter'?'Physically Defensive':'Fast Bulky Support';
if(species.id==='shedinja')return'Fast Physical Sweeper';

if(itemid==='choiceband'&&moveCount['PhysicalAttack']>=2){
if(!isFast)return'Bulky Band';
return'Fast Band';
}else if(itemid==='choicespecs'&&moveCount['SpecialAttack']>=2){
if(!isFast)return'Bulky Specs';
return'Fast Specs';
}else if(itemid==='choicescarf'){
if(moveCount['PhysicalAttack']===0)return'Special Scarf';
if(moveCount['SpecialAttack']===0)return'Physical Scarf';
if(moveCount['PhysicalAttack']>moveCount['SpecialAttack'])return'Physical Biased Mixed Scarf';
if(moveCount['PhysicalAttack']<moveCount['SpecialAttack'])return'Special Biased Mixed Scarf';
if(stats.atk<stats.spa)return'Special Biased Mixed Scarf';
return'Physical Biased Mixed Scarf';
}

if(species.id==='unown')return'Fast Special Sweeper';

if(moveCount['PhysicalStall']&&moveCount['Restoration']){
if(stats.spe>110&&abilityid!=='prankster')return'Fast Bulky Support';
return'Specially Defensive';
}
if(moveCount['SpecialStall']&&moveCount['Restoration']&&itemid!=='lifeorb'){
if(stats.spe>110&&abilityid!=='prankster')return'Fast Bulky Support';
return'Physically Defensive';
}

var offenseBias='Physical';
if(stats.spa>stats.atk&&moveCount['Special']>1)offenseBias='Special';else
if(stats.atk>stats.spa&&moveCount['Physical']>1)offenseBias='Physical';else
if(moveCount['Special']>moveCount['Physical'])offenseBias='Special';

if(moveCount['Stall']+moveCount['Support']/2<=2&&bulk<135000&&moveCount[offenseBias]>=1.5){
if(isFast){
if(bulk>80000&&!moveCount['Ultrafast'])return'Bulky '+offenseBias+' Sweeper';
return'Fast '+offenseBias+' Sweeper';
}else{
if(moveCount[offenseBias]>=3||moveCount['Stall']<=0){
return'Bulky '+offenseBias+' Sweeper';
}
}
}

if(isFast&&abilityid!=='prankster'){
if(stats.spe>100||bulk<55000||moveCount['Ultrafast']){
return'Fast Bulky Support';
}
}
if(moveCount['SpecialStall'])return'Physically Defensive';
if(moveCount['PhysicalStall'])return'Specially Defensive';
if(species.id==='blissey'||species.id==='chansey')return'Physically Defensive';
if(specialBulk>=physicalBulk)return'Specially Defensive';
return'Physically Defensive';
};_proto3.
ensureMinEVs=function ensureMinEVs(evs,stat,min,evTotal){
if(!evs[stat])evs[stat]=0;
var diff=min-evs[stat];
if(diff<=0)return evTotal;
if(evTotal<=504){
var change=Math.min(508-evTotal,diff);
evTotal+=change;
evs[stat]+=change;
diff-=change;
}
if(diff<=0)return evTotal;
var evPriority={def:1,spd:1,hp:1,atk:1,spa:1,spe:1};
var prioStat;
for(prioStat in evPriority){
if(prioStat===stat)continue;
if(evs[prioStat]&&evs[prioStat]>128){
evs[prioStat]-=diff;
evs[stat]+=diff;
return evTotal;
}
}
return evTotal;
};_proto3.
ensureMaxEVs=function ensureMaxEVs(evs,stat,min,evTotal){
if(!evs[stat])evs[stat]=0;
var diff=evs[stat]-min;
if(diff<=0)return evTotal;
evs[stat]-=diff;
evTotal-=diff;
return evTotal;
};_proto3.
guessEVs=function guessEVs(
set,role)
{var _this6=this;
if(!set)return{};
if(role==='?')return{};
var species=this.dex.species.get(set.species||set.name);
var stats=this.getStats(species,set.fusion);

var hasMove=this.hasMove;
var moveCount=this.moveCount;

var evs={
hp:0,atk:0,def:0,spa:0,spd:0,spe:0
};
var plusStat;
var minusStat=undefined;

var statChart={
'Bulky Band':['atk','hp'],
'Fast Band':['spe','atk'],
'Bulky Specs':['spa','hp'],
'Fast Specs':['spe','spa'],
'Physical Scarf':['spe','atk'],
'Special Scarf':['spe','spa'],
'Physical Biased Mixed Scarf':['spe','atk'],
'Special Biased Mixed Scarf':['spe','spa'],
'Fast Physical Sweeper':['spe','atk'],
'Fast Special Sweeper':['spe','spa'],
'Bulky Physical Sweeper':['atk','hp'],
'Bulky Special Sweeper':['spa','hp'],
'Fast Bulky Support':['spe','hp'],
'Physically Defensive':['def','hp'],
'Specially Defensive':['spd','hp']
};

plusStat=statChart[role][0];
if(role==='Fast Bulky Support')moveCount['Ultrafast']=0;
if(plusStat==='spe'&&moveCount['Ultrafast']){
if(statChart[role][1]==='atk'||statChart[role][1]==='spa'){
plusStat=statChart[role][1];
}else if(moveCount['Physical']>=3){
plusStat='atk';
}else if(stats.spd>stats.def){
plusStat='spd';
}else{
plusStat='def';
}
}

if(this.supportsAVs){

evs={hp:200,atk:200,def:200,spa:200,spd:200,spe:200};
if(!moveCount['PhysicalAttack'])evs.atk=0;
if(!moveCount['SpecialAttack'])evs.spa=0;
if(hasMove['gyroball']||hasMove['trickroom'])evs.spe=0;
}else if(!this.supportsEVs&&!this.useStatPoints){


}else if(this.ignoreEVLimits){

evs={hp:252,atk:252,def:252,spa:252,spd:252,spe:252};
if(!moveCount['PhysicalAttack'])evs.atk=0;
if(!moveCount['SpecialAttack']&&this.dex.gen>1)evs.spa=0;
if(hasMove['gyroball']||hasMove['trickroom'])evs.spe=0;
if(this.dex.gen===1)evs.spd=0;
if(this.dex.gen<3)return evs;
}else{

if(!statChart[role])return{};

var evTotal=0;

var maxPoints=!this.useStatPoints?252:32;
var totalPoints=!this.useStatPoints?508:66;
var primaryStat=statChart[role][0];
var stat=this.getStat(primaryStat,set,maxPoints,plusStat===primaryStat?1.1:1.0);
var ev=!this.useStatPoints?252:32;
var step=!this.useStatPoints?4:1;
while(ev>0&&stat<=this.getStat(primaryStat,set,ev-step,plusStat===primaryStat?1.1:1.0))ev-=step;

evs[primaryStat]=ev;
evTotal+=ev;

var secondaryStat=statChart[role][1];
if(secondaryStat==='hp'&&set.level&&set.level<20)secondaryStat='spd';
stat=this.getStat(secondaryStat,set,maxPoints,plusStat===secondaryStat?1.1:1.0);
ev=!this.useStatPoints?252:32;
while(ev>0&&stat<=this.getStat(secondaryStat,set,ev-step,plusStat===secondaryStat?1.1:1.0)){
ev-=step;
}
evs[secondaryStat]=ev;
evTotal+=ev;

if(this.supportsEVs){
if(species.id==='tentacruel'){
evTotal=this.ensureMinEVs(evs,'spe',16,evTotal);
}else if(species.id==='skarmory'){
evTotal=this.ensureMinEVs(evs,'spe',24,evTotal);
}else if(species.id==='jirachi'){
evTotal=this.ensureMinEVs(evs,'spe',32,evTotal);
}else if(species.id==='celebi'){
evTotal=this.ensureMinEVs(evs,'spe',36,evTotal);
}else if(species.id==='volcarona'){
evTotal=this.ensureMinEVs(evs,'spe',52,evTotal);
}else if(species.id==='gliscor'){
evTotal=this.ensureMinEVs(evs,'spe',72,evTotal);
}else if(species.id==='dragonite'&&evs['hp']){
evTotal=this.ensureMaxEVs(evs,'spe',220,evTotal);
}
}

var SRweaknesses=['Fire','Flying','Bug','Ice'];
var SRresistances=['Ground','Steel','Fighting'];
var SRweak=0;
if(set.ability!=='Magic Guard'&&set.ability!=='Mountaineer'){
if(SRweaknesses.includes(species.types[0])){
SRweak++;
}else if(SRresistances.includes(species.types[0])){
SRweak--;
}
if(SRweaknesses.includes(species.types[1])){
SRweak++;
}else if(SRresistances.includes(species.types[1])){
SRweak--;
}
}
var ensureHPDivisibility=function(currentEVTotal){
var hpDivisibility=0;
var hpShouldBeDivisible=false;
var hp=evs['hp']||0;
var hpStat=_this6.getStat('hp',set,hp,1);
if((set.item==='Leftovers'||set.item==='Black Sludge')&&hasMove['substitute']&&hpStat!==404){
hpDivisibility=4;
}else if(set.item==='Leftovers'||set.item==='Black Sludge'){
hpDivisibility=0;
}else if(hasMove['bellydrum']&&(set.item||'').endsWith('Berry')){
hpDivisibility=2;
hpShouldBeDivisible=true;
}else if(hasMove['substitute']&&(set.item||'').endsWith('Berry')){
hpDivisibility=4;
hpShouldBeDivisible=true;
}else if(SRweak>=2||hasMove['bellydrum']){
hpDivisibility=2;
}else if(SRweak>=1||hasMove['substitute']||hasMove['transform']){
hpDivisibility=4;
}else if(set.ability!=='Magic Guard'){
hpDivisibility=8;
}

if(hpDivisibility){
while(hp<maxPoints&&currentEVTotal<totalPoints&&!(hpStat%hpDivisibility)!==hpShouldBeDivisible){
hp+=step;
hpStat=_this6.getStat('hp',set,hp,1);
currentEVTotal+=step;
}
while(hp>0&&!(hpStat%hpDivisibility)!==hpShouldBeDivisible){
hp-=step;
hpStat=_this6.getStat('hp',set,hp,1);
currentEVTotal-=step;
}
while(hp>0&&hpStat===_this6.getStat('hp',set,hp-step,1)){
hp-=step;
currentEVTotal-=step;
}
if(hp||evs['hp'])evs['hp']=hp;
}
return currentEVTotal;
};
evTotal=ensureHPDivisibility(evTotal);
var hpSelected=false;
while(evTotal<totalPoints){
var evTotalBefore=evTotal;
secondaryStat=null;
if(!evs['atk']&&moveCount['PhysicalAttack']>=1){
secondaryStat='atk';
}else if(!evs['spa']&&moveCount['SpecialAttack']>=1){
secondaryStat='spa';
}else if(!evs['hp']&&stats.hp>1&&!hpSelected){
secondaryStat='hp';
}else if(!evs['spd']&&stats.hp>1){
secondaryStat='spd';
}else if(!evs['def']&&stats.hp>1){
secondaryStat='def';
}else if(!evs['spe']){
secondaryStat='spe';
}
if(!secondaryStat)break;

ev=Math.min(totalPoints-evTotal,maxPoints);
stat=this.getStat(secondaryStat,set,ev);
while(ev>0&&stat===this.getStat(secondaryStat,set,ev-step))ev-=step;
if(ev)evs[secondaryStat]=ev;
evTotal+=ev;

if(secondaryStat==='hp'){
hpSelected=true;
evTotal=ensureHPDivisibility(evTotal);
continue;
}
if(evTotal===evTotalBefore)break;
}
}

if(hasMove['gyroball']||hasMove['trickroom']){
minusStat='spe';
}else if(!moveCount['PhysicalAttack']){
minusStat='atk';
}else if(moveCount['SpecialAttack']<1&&!evs['spa']){
if(moveCount['SpecialAttack']<moveCount['PhysicalAttack']){
minusStat='spa';
}else if(!evs['atk']){
minusStat='atk';
}
}else if(moveCount['PhysicalAttack']<1&&!evs['atk']){
minusStat='atk';
}else if(stats.def>stats.spe&&stats.spd>stats.spe&&!evs['spe']){
minusStat='spe';
}else if(plusStat==='def'||plusStat==='spd'){


minusStat=evs['atk']&&!evs['spe']?'spe':'atk';
}else if(stats.def>stats.spd){
minusStat='spd';
}else{
minusStat='def';
}

if(!minusStat||plusStat===minusStat){
minusStat=plusStat==='spe'?'spd':'spe';
}

evs.plusStat=plusStat;
evs.minusStat=minusStat;

return evs;
};_proto3.

getStat=function getStat(stat,set,evOverride,natureOverride){var _set$ivs,_set$evs,_BattleNatures,_BattleNatures2;
var species=this.dex.species.get(set.species);
if(!species.exists)return 0;

var level=set.level||100;

var baseStat=this.getStats(species,set.fusion)[stat];

var iv=(_set$ivs=set.ivs)==null?void 0:_set$ivs[stat];
if(typeof iv!=='number')iv=31;
if(this.dex.gen<=2)iv&=30;

var ev=(_set$evs=set.evs)==null?void 0:_set$evs[stat];
if(typeof ev!=='number')ev=this.dex.gen>2?0:252;
if(evOverride!==undefined)ev=evOverride;

if(stat==='hp'){
if(baseStat===1)return 1;
if(this.useStatPoints)return baseStat+ev+75;
if(this.supportsAVs)return~~(~~(2*baseStat+iv+100)*level/100+10)+(ev||0);
return~~(~~(2*baseStat+iv+~~(ev/4)+100)*level/100+10);
}
var val=~~(~~(2*baseStat+iv+~~(ev/4))*level/100+5);
if(this.useStatPoints){
val=baseStat+ev+20;
}else if(!this.supportsEVs){
val=~~(~~(2*baseStat+iv)*level/100+5);
}
if(natureOverride){
val*=natureOverride;
}else if(((_BattleNatures=BattleNatures[set.nature])==null?void 0:_BattleNatures.plus)===stat){
val*=1.1;
}else if(((_BattleNatures2=BattleNatures[set.nature])==null?void 0:_BattleNatures2.minus)===stat){
val*=0.9;
}
if(this.supportsAVs){
var friendshipValue=~~((70/255/10+1)*100);
val=~~val*friendshipValue/100+(ev||0);
}
return~~val;
};_proto3.

getStats=function getStats(species,fusion){
var stats=Object.assign({},species.baseStats);

var fusionSpecies=this.dex.species.get(fusion||'');
if(fusionSpecies.exists){
for(var stat in stats){
if(stat==='hp'||stat==='spa'||stat==='spd')stats[stat]=Math.floor(species.baseStats[stat]*2/3+fusionSpecies.baseStats[stat]*1/3);
if(stat==='atk'||stat==='def'||stat==='spe')stats[stat]=Math.floor(species.baseStats[stat]*1/3+fusionSpecies.baseStats[stat]*2/3);
}
}

return stats;
};return BattleStatGuesser;}();


function BattleStatOptimizer(set,formatid){var _BattleNatures3,_origSpread$evs2;
if(!set.evs)return null;

var dex=Dex.mod(formatid.slice(0,4));
var ignoreEVLimits=
dex.gen<3||
(formatid.endsWith('hackmons')||formatid.endsWith('bh'))&&dex.gen!==6||
formatid.includes('metronomebattle')||formatid.endsWith('norestrictions');

var useStatPoints=formatid.includes('champions');
var supportsEVs=!formatid.includes('letsgo')&&!useStatPoints;
if(!(useStatPoints||supportsEVs)||ignoreEVLimits)return null;

var species=dex.species.get(set.species);
var stats=new BattleStatGuesser(formatid).getStats(species,set.fusion);
var level=set.level||100;
var getStat=function(stat,ev,nature,statPoints){var _set$ivs2;
var baseStat=stats[stat];
var iv=((_set$ivs2=set.ivs)==null?void 0:_set$ivs2[stat])||31;
var val=~~(~~(2*baseStat+iv+~~(ev/4))*level/100+5);
if(statPoints)val=baseStat+ev+20;
if(nature.plus===stat){
val*=1.1;
}else if(nature.minus===stat){
val*=0.9;
}
return~~val;
};

var origNature=(_BattleNatures3=BattleNatures[set.nature])!=null?_BattleNatures3:BattleNatures['Serious'];
var origStats={

atk:getStat('atk',set.evs.atk||0,origNature,useStatPoints),
def:getStat('def',set.evs.def||0,origNature,useStatPoints),
spa:getStat('spa',set.evs.spa||0,origNature,useStatPoints),
spd:getStat('spd',set.evs.spd||0,origNature,useStatPoints),
spe:getStat('spe',set.evs.spe||0,origNature,useStatPoints)
};
var getMinEVs=function(stat,nature,statPoints){
var ev=0;
var step=statPoints?1:4;
while(getStat(stat,ev,nature,statPoints)<origStats[stat]){
ev+=step;
}
return ev;
};

var origSpread=Object.assign({evs:set.evs},origNature);
var origLeftoverEVs=useStatPoints?66:508;for(var _i82=0,_Dex$statNames2=
Dex.statNames;_i82<_Dex$statNames2.length;_i82++){var _origSpread$evs;var stat=_Dex$statNames2[_i82];
origLeftoverEVs-=((_origSpread$evs=origSpread.evs)==null?void 0:_origSpread$evs[stat])||0;
}

if(origLeftoverEVs>(useStatPoints?2:4))return null;


var plusTooHigh=origNature.plus&&
getStat(origNature.plus,useStatPoints?32:252,{},useStatPoints)<origStats[origNature.plus];

var minusTooLow=origNature.minus&&!((_origSpread$evs2=origSpread.evs)!=null&&_origSpread$evs2[origNature.minus]);

if(plusTooHigh&&minusTooLow)return null;

var bestPlus=origNature.plus;
var bestPlusMinEVs=bestPlus&&origSpread.evs[bestPlus];
var bestMinus=origNature.minus||'atk';
var bestMinusMinEVs=origSpread.evs[bestMinus];
var savedEVs=0;


if(!minusTooLow){for(var _i84=0,_Dex$statNamesExceptH14=
Dex.statNamesExceptHP;_i84<_Dex$statNamesExceptH14.length;_i84++){var _stat=_Dex$statNamesExceptH14[_i84];
if(origStats[_stat]<origStats[bestMinus]){
var minEVs=getMinEVs(_stat,{minus:_stat},useStatPoints);
if(minEVs>(useStatPoints?32:252))continue;

savedEVs=(origSpread.evs[_stat]||0)-minEVs;
if(origNature.minus){
savedEVs+=(origSpread.evs[origNature.minus]||0)-getMinEVs(origNature.minus,{minus:_stat},useStatPoints);
}
bestMinus=_stat;
bestMinusMinEVs=minEVs;
}
}
}
if(!plusTooHigh){for(var _i86=0,_Dex$statNamesExceptH16=
Dex.statNamesExceptHP;_i86<_Dex$statNamesExceptH16.length;_i86++){var _stat2=_Dex$statNamesExceptH16[_i86];

if(_stat2!==origNature.plus&&origSpread.evs[_stat2]&&_stat2!==bestMinus){
var _minEVs=getMinEVs(_stat2,{plus:_stat2},useStatPoints);
var plusEVsSaved=(origNature.minus===_stat2?
getMinEVs(_stat2,{},useStatPoints):origSpread.evs[_stat2]||0)-_minEVs;
if(bestPlus&&bestPlus!==bestMinus){
plusEVsSaved+=bestPlusMinEVs-getMinEVs(bestPlus,{plus:_stat2,minus:bestMinus},useStatPoints);
}
if(plusEVsSaved>0&&savedEVs+plusEVsSaved>0){
savedEVs+=plusEVsSaved;
bestPlus=_stat2;
bestPlusMinEVs=_minEVs;
}else if(plusEVsSaved===0&&(bestPlus||savedEVs>0)||plusEVsSaved>0&&savedEVs+plusEVsSaved===0){
if(!bestPlus||
getStat(
_stat2,getMinEVs(_stat2,{plus:_stat2},useStatPoints),{plus:_stat2},useStatPoints
)>origStats[_stat2]){
savedEVs+=plusEVsSaved;
bestPlus=_stat2;
bestPlusMinEVs=_minEVs;
}
}
}
}
}

if(bestPlus&&savedEVs>=0){
var newSpread=



{evs:Object.assign({},origSpread.evs),plus:bestPlus,minus:bestMinus};
if(bestPlus!==origNature.plus||bestMinus!==origNature.minus){
newSpread.evs[bestPlus]=bestPlusMinEVs;
newSpread.evs[bestMinus]=bestMinusMinEVs;
if(origNature.plus&&origNature.plus!==bestPlus&&origNature.plus!==bestMinus){
newSpread.evs[origNature.plus]=getMinEVs(origNature.plus,newSpread,useStatPoints);
}
if(origNature.minus&&origNature.minus!==bestPlus&&origNature.minus!==bestMinus){
newSpread.evs[origNature.minus]=getMinEVs(origNature.minus,newSpread,useStatPoints);
}for(var _i88=0,_Dex$statNames4=
Dex.statNames;_i88<_Dex$statNames4.length;_i88++){var _stat3=_Dex$statNames4[_i88];
if(!newSpread.evs[_stat3])delete newSpread.evs[_stat3];
}
return Object.assign({},newSpread,{savedEVs:savedEVs});
}else if(!plusTooHigh&&!minusTooLow){
if(Math.floor(
getStat(bestPlus,bestMinusMinEVs,newSpread,useStatPoints)/11
)<=Math.ceil(origStats[bestMinus]/9)){


delete newSpread.plus;
delete newSpread.minus;
newSpread.evs[origNature.plus]=getMinEVs(origNature.plus,newSpread,useStatPoints);
newSpread.evs[origNature.minus]=getMinEVs(origNature.minus,newSpread,useStatPoints);
savedEVs+=(origSpread.evs[origNature.plus]||0)-newSpread.evs[origNature.plus];
savedEVs+=(origSpread.evs[origNature.minus]||0)-newSpread.evs[origNature.minus];
if(savedEVs<0)return null;for(var _i90=0,_Dex$statNames6=
Dex.statNames;_i90<_Dex$statNames6.length;_i90++){var _stat4=_Dex$statNames6[_i90];
if(!newSpread.evs[_stat4])delete newSpread.evs[_stat4];
}
return Object.assign({},newSpread,{savedEVs:savedEVs});
}
}
}

return null;
}



if(typeof require==='function'){

global.BattleStatGuesser=BattleStatGuesser;
global.BattleStatOptimizer=BattleStatOptimizer;
}
//# sourceMappingURL=battle-tooltips.js.map